package du.cfs.service;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import du.cfs.model.Account;
import du.cfs.model.RememberToken;
import du.cfs.model.Role;
import du.cfs.repository.AccountRepository;
import du.cfs.repository.RememberTokenRepository;
import du.cfs.repository.RoleRepository;
import du.cfs.repository.AccountRepository.MenuPermission;

@Service
public class CommerceService {
	@Autowired
    private AccountRepository commerceRepository;
	
	@Autowired
    private RoleRepository roleRepository;
	
	@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
    private RememberTokenRepository rememberTokenRepository;
	
//	public Commerce GetUserByName(String name) {
//		return commerceRepository.findByUsername(name);
//	}
	/**
	 * 	建立TOKEN
	 * @param token
	 */
	public void save(RememberToken token) {
//		return rememberTokenRepository.insert(token.getToken(),token.getLast_used(),token.getSeries());
		 rememberTokenRepository.save(token);
	}
	/**
	 * 	更新TOKEN
	 * @param tokenValue
	 * @param lastUsed
	 * @param series
	 * @return
	 */
	public int updateByPK(String tokenValue, Date lastUsed, String series) {
		return rememberTokenRepository.updateByPK(tokenValue,lastUsed,series);
	}
	
	public RememberToken findBySeries(String series) {
		return rememberTokenRepository.findBySeries(series);
	}
	
	public Account save(Account user){
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		user.setCreated_at(LocalDateTime.now());
		return commerceRepository.save(user);
	}
	/**
	 * 查詢用戶
	 * @param name
	 * @return
	 */
	public Optional<Account> findByUsername(String name) {
		return commerceRepository.findByUsername(name);
	}
	
	/**
	 * 測試事務操作方法
	 * @param id
	 * @param role_id
	 * @param uid
	 * @return
	 */
//	@Transactional
//	public int deleteAndUpdate(int id,int role_id,int uid) {
//		int dcount =  commerceRepository.deleteByJPQL(id);
//
//		int ucount = commerceRepository.updateByJPQL(role_id, uid);
//		
//		return dcount+ucount;
//	}
//	
//	public int updateInfo(String password,int role_id,String com04,int id) {
//		password = bCryptPasswordEncoder.encode(password);
//		return commerceRepository.updateInfoByJPQL(password, role_id, com04, id);
//	}
	

	public Collection<MenuPermission> findMenuByUsername(String username) {
		// TODO Auto-generated method stub
		return commerceRepository.findMenuByUsername(username);
	}
	
	/**
	 * 查詢角色
	 * @param name
	 * @return
	 */
	public Optional<Role> findByName(String name) {
		return roleRepository.findByName(name);
	}
	
	public Role saveRole(Role role) {
		return roleRepository.save(role);
	}
	
	
}
