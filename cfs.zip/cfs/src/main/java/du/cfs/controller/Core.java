package du.cfs.controller;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.*;

import du.cfs.controller.action.BaseCore;
import du.cfs.controller.action.index.Index;
import du.cfs.security.UserPrinciple;
import du.cfs.service.CommerceService;

@Slf4j
@Controller
@RequestMapping("/cm")
public class Core extends BaseCore{

	@Autowired
	CommerceService commerceService;
	
	@RequestMapping("/{sub}/{action}")
	public String runCore(@PathVariable String sub,
						@PathVariable String action,
						HttpServletRequest request, 
						HttpServletResponse response,
						Model model){
			
		 	Map<String,Object> data = new HashMap<>();
		 	request.setAttribute("sub", sub);
		 	data.put("model", model);
		 	data.put("request", request);
		 	initView(model,sub,action);
			return (String) runModel(sub, action, data);
	}
	
	@RequestMapping()
	public String runCoreHome(
						HttpServletRequest request, 
						HttpServletResponse response,
						Model model){
			
			String sub = "index";
			String action = "Index";
		 	Map<String,Object> data = new HashMap<>();
		 	request.setAttribute("sub", sub);
		 	data.put("model", model);
		 	data.put("request", request);

			initView(model,sub,action);
			return (String) runModel(sub, action, data);
	}
	
	
//	@GetMapping("/{action}/test")
//	@PreAuthorize("hasRole('ROLE_USER')")
//	public String TEST() {
//		System.out.println("IN TEST FUNCTION");
//		return "index";
//	}
//	
//	@GetMapping("/test")
//	public String TEST2(Model model) {
//		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//		System.out.println(SecurityContextHolder.getContext().getAuthentication() == null);
//		System.out.println("IN TEST2  "+userPrincipal.getAuthorities().toString());
//		System.out.println("IN TEST2 FUNCTION");
//		Index a = new Index();
//		Map<String,Object> data = new HashMap<>();
//		data.put("model", model);
//		a.init(data);
//		return "test";
//	}

}
