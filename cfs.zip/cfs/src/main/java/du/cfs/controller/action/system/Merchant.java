package du.cfs.controller.action.system;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import du.cfs.controller.action.BaseAction;
import du.cfs.controller.action.BaseCore;
import du.cfs.security.UserPrinciple;


public class Merchant extends BaseAction{
	
	@Override
	public String execute() {
		
		UserPrinciple userInfo = getUserInfo();
		System.out.println("-------------in Account Class-------------");

		assign("username", userInfo.getName());
		assign("page", "Merchant");
//		System.out.println("-------------使用者名稱-------------"+userInfo.getUsername());
//		System.out.println("-------------使用者暱稱-------------"+userInfo.getName());
//		System.out.println("-------------使用者權限-------------"+userInfo.getAuthorities().toString());
		return getView("merchant");
	}
}
