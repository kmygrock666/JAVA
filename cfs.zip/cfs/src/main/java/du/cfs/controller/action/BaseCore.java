package du.cfs.controller.action;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import du.cfs.controller.Core;
import du.cfs.security.UserPrinciple;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BaseCore {
	
	@Autowired
	private ConfigurableApplicationContext applicationContext;
	
	@Autowired
	MenuOperate menu;
	
	@Autowired
    BeanFactory beanFactory;
	
	public Object runModel(String sub,String action,Map<String,Object> data) {
		try {
			//實體class
			Class model_class = Class.forName("du.cfs.controller.action." + sub + "." + action);
			Object classObj2;
			//取得bean
			if (beanFactory.containsBean(action)) {
				classObj2 = beanFactory.getBean(model_class);
			}else {
				classObj2 = registerBean(action, model_class);
			}
			 
			log.info("=============In Core Class============");
			
			//產生method，並呼叫
			Method setInit = model_class.getMethod("init", new Class[]{Map.class});
			Object getInit = setInit.invoke(classObj2, new Object[]{data});
			//產生method，並呼叫 
			Method setInfo = model_class.getMethod("execute", null);
			Object getReturn = setInfo.invoke(classObj2, null);
			
			//移除bean
//			baseCore.deleteBean(action);
			return getReturn;
		} catch( ClassNotFoundException e ) {
			//my class isn't there!
			log.error("Not Path : {}", e.getMessage());
			throw new RuntimeException("Not Path : " + e.getMessage());
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 B " + e.getMessage());
			throw new RuntimeException("初始化錯誤 B " + e.getMessage());
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 C " + e.getMessage());
			throw new RuntimeException("初始化錯誤 C " + e.getMessage());
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 D " + e.getMessage());
			throw new RuntimeException("初始化錯誤 D " + e.getMessage());
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 E " + e.getMessage());
			throw new RuntimeException("初始化錯誤 E " + e.getMessage());
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 F " + e.getMessage());
			throw new RuntimeException("初始化錯誤 F " + e.getMessage());
		}
		
	}
	
	/**
	 * 設置VIEW
	 */
	public void initView(Model model,String sub,String action) {
		UserPrinciple userInfo = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Map<String,String> dirTitle = menu.getMainTitle(sub,action);
		model.addAttribute("menuTitle", dirTitle.get("dir"));
		model.addAttribute("subTitle", dirTitle.get("sub"));
		model.addAttribute("user", userInfo);
	}

	public void name() {
		System.out.println("asczcsqwea");
	}
	
	//動態註冊bean
	public <T> T registerBean(String name, Class<T> clazz, Object... args) {
		//建構bean定義
	    BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(clazz);
	    //設置依賴
	    if (args.length > 0) {
	        for (Object arg : args) {
	            beanDefinitionBuilder.addConstructorArgValue(arg);
	        }
	    }
	      
	    BeanDefinition beanDefinition = beanDefinitionBuilder.getRawBeanDefinition();
	    //註冊bean定義
	    BeanDefinitionRegistry beanFactory = (BeanDefinitionRegistry) applicationContext.getBeanFactory();
	    beanFactory.registerBeanDefinition(name, beanDefinition);
	    return applicationContext.getBean(name, clazz);
	}
	//刪除bean
	public void deleteBean(String beanName) {
		BeanDefinitionRegistry beanFactory = (BeanDefinitionRegistry) applicationContext.getBeanFactory();
		beanFactory.removeBeanDefinition(beanName);
	}
	

}
