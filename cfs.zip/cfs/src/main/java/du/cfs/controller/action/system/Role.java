package du.cfs.controller.action.system;

import org.springframework.beans.factory.annotation.Autowired;

import du.cfs.controller.action.BaseAction;
import du.cfs.service.CommerceService;

public class Role extends BaseAction{
	
	@Autowired
	CommerceService commerceService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		
		return getView("role");
	}
	
}
