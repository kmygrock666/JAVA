package du.cfs.controller.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import du.cfs.security.UserPrinciple;
import lombok.Data;

@Component
public abstract class BaseAction{
	
	private Model model;
	private HttpServletRequest request;
	private Map<String, Object> viewParam;
	protected abstract String execute(); 

	/**
	 * get params
	 * @param data
	 */
	public void init(Map<String,Object> data) {
		model = (Model) data.get("model");
		request = (HttpServletRequest) data.get("request");
	}
	
	public UserPrinciple getUserInfo() {
		return (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	}
	
	public String getView(String path) {
		String sub = (String) request.getAttribute("sub");
		String paths = "view/"+sub+"/"+path;
		model.addAttribute("path", paths);
		return "main/subMakeUp";
	}
	
	public void assign(String key,Object value) {
		model.addAttribute(key, value);
	}
	
	public Object getParam(String key) {
		return request.getParameter(key);
//		return request.getAttribute(key);
	}
	
	
	
	

}
