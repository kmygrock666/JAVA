package du.cfs.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import du.cfs.model.Account;
import du.cfs.model.Menu;
import du.cfs.model.Permission;
import du.cfs.model.Role;
import du.cfs.service.CommerceService;
import du.cfs.service.MenuService;
import du.cfs.service.PermissionService;

@Component
public class BackStateSeed {
	@Autowired
    private CommerceService commerceService;
	
	@Autowired
    private PermissionService permissionService;
	
	@Autowired
    private MenuService menuService;
	
	public void AddAccount(){
		System.out.println("---------------新增帳號----------------------");
		Account user1 = new Account();
		user1.setUsername("rdian");
		user1.setPassword("123");
		user1.setNickname("rdian");
		user1.setStatus("ACCESS");
		Role WhatRole1 = commerceService.findByName("ROLE_ADMIN")
                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
		
//		System.out.println(JSON.toJSONString(WhatRole,true));
		user1.addRole(WhatRole1);
		commerceService.save(user1);
		
		Account user = new Account();
		user.setUsername("ian");
		user.setPassword("123");
		user.setNickname("ian");
		user.setStatus("ACCESS");
		Role WhatRole = commerceService.findByName("ROLE_USER")
                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
		
//		System.out.println(JSON.toJSONString(WhatRole,true));
		user.addRole(WhatRole);
		commerceService.save(user);
	}
	
	//建立sub
	public void addMenu() {
		System.out.println("---------------建立目錄----------------------");
		Menu menu = new Menu();
		menu.setIcon("fa fa-gear");
		menu.setName("系統管理");
		menu.setSort(1);
		menuService.save(menu);
		
		Menu menu1 = new Menu();
		menu1.setIcon("fa fa-align-left");
		menu1.setName("代收管理");
		menu1.setSort(2);
		menuService.save(menu1);
		
		Menu menu3 = new Menu();
		menu3.setIcon("fa fa-align-left");
		menu3.setName("未分類");
		menu3.setSort(3);
		menuService.save(menu3);
	}
	
	//權限
	public void addPermission() {
		System.out.println("---------------權限----------------------");
		List<Menu> menus = menuService.findAll();
//		System.out.println(JSON.toJSONString(menus,true));
		
		Permission p = new Permission();
		p.setMenu_show(0);
		p.setName("首頁");
		p.setPermission("Index");
		p.setUrl("/cm/index/Index");
		p.setMenu(menus.get(2));
		permissionService.save(p);
		
		Permission p1 = new Permission();
		p1.setMenu_show(1);
		p1.setName("商戶管理");
		p1.setPermission("Merchant");
		p1.setUrl("/cm/system/Merchant");
		p1.setMenu(menus.get(0));
		permissionService.save(p1);
		
		Permission p2 = new Permission();
		p2.setMenu_show(1);
		p2.setName("控端管理");
		p2.setPermission("Account");
		p2.setUrl("/cm/system/Account");
		p2.setMenu(menus.get(0));
		permissionService.save(p2);
		
		Permission p21 = new Permission();
		p21.setMenu_show(1);
		p21.setName("權限管理");
		p21.setPermission("Permission");
		p21.setUrl("/cm/system/Permission");
		p21.setMenu(menus.get(0));
		permissionService.save(p21);
		
		Permission p22 = new Permission();
		p22.setMenu_show(1);
		p22.setName("角色管理");
		p22.setPermission("Role");
		p22.setUrl("/cm/system/Role");
		p22.setMenu(menus.get(0));
		permissionService.save(p22);
		
		Permission p23 = new Permission();
		p23.setMenu_show(1);
		p23.setName("Menu管理");
		p23.setPermission("Menu");
		p23.setUrl("/cm/system/Menu");
		p23.setMenu(menus.get(0));
		permissionService.save(p23);
		
		Permission p3 = new Permission();
		p3.setMenu_show(1);
		p3.setName("代收查詢");
		p3.setPermission("OrderList");
		p3.setMenu(menus.get(1));
		p3.setUrl("/cm/order/OrderList");
		permissionService.save(p3);
	}
	//角色
	public void AddRole() {
		System.out.println("---------------新增角色----------------------");
		List<Permission> permissions = permissionService.findAll();
		Role role = new Role();
		role.setName("ROLE_ADMIN");
		role.setDescription("管理者");
		role.setPermissions(permissions);
		commerceService.saveRole(role);
		
		List<Permission> permissions2 = new ArrayList();
		permissions2.add(permissions.get(3));
		Role role2 = new Role();
		role2.setName("ROLE_USER");
		role2.setDescription("使用者");
		role.setPermissions(permissions2);
		commerceService.saveRole(role2);
	}
	
}
