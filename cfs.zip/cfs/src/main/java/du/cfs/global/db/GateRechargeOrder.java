package du.cfs.global.db;

import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Enums.PayType;
import du.cfs.global.Enums.StatusType;


@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "kern_id", "cfsOrderNumber" }) })
public class GateRechargeOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@ManyToOne
	private Kern kern;
	@Column(updatable = false, nullable = false)
	private PayType merPayType = PayType.UNSET;
	@Column(length = 50, updatable = false, nullable = false)
	private String merCode;
	@Column(length = 50, updatable = false, nullable = false)
	private String merOrderNumber;
	@Column(updatable = false, nullable = false)
	private int merAmount;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(updatable = false, nullable = false)
	private Date merTransDate;
	@Column(length = 200, updatable = false, nullable = false)
	private String merSyncNotifyUrl;
	@Column(length = 200, updatable = false, nullable = false)
	private String merUnsyncNotifyUrl;
	@Column(length = 200, updatable = false, nullable = false)
	private String merDesc;
	@Column(length = 50)
	private String cfsOrderNumber;
	@OneToOne(cascade = { CascadeType.PERSIST, CascadeType.REMOVE }, optional = true, fetch = FetchType.EAGER)
	GateRechargeOrderSubInfo rechargeOrderSubInfo;
	
	@Column(length = 50)
	private String gateOrderNumber;
	@Column(columnDefinition = "TINYINT(1)")
	private StatusType gateStatus;

	public GateRechargeOrder() {
	}

	// ----------------------------------------------------------

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
	
	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
		this.gateStatus = StatusType.UNPAY;
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------
	// ----------------------------------------------------------

	public GateRechargeOrderSubInfo getRechargeOrderSubInfo() {
		return rechargeOrderSubInfo;
	}

	public void setRechargeOrderSubInfo(GateRechargeOrderSubInfo rechargeOrderSubInfo) {
		this.rechargeOrderSubInfo = rechargeOrderSubInfo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getMerOrderNumber() {
		return merOrderNumber;
	}

	public void setMerOrderNumber(String merOrderNumber) {
		this.merOrderNumber = merOrderNumber;
	}

	public int getMerAmount() {
		return merAmount;
	}

	public void setMerAmount(int merAmount) {
		this.merAmount = merAmount;
	}

	public String getCfsOrderNumber() {
		return cfsOrderNumber;
	}

	public void setCfsOrderNumber(String cfsOrderNumber) {
		this.cfsOrderNumber = cfsOrderNumber;
	}

	public String getGateOrderNumber() {
		return gateOrderNumber;
	}

	public void setGateOrderNumber(String gateOrderNumber) {
		this.gateOrderNumber = gateOrderNumber;
	}



	public PayType getMerPayType() {
		return merPayType;
	}

	public void setMerPayType(PayType merPayType) {
		this.merPayType = merPayType;
	}

	public String getMerCode() {
		return merCode;
	}

	public void setMerCode(String merCode) {
		this.merCode = merCode;
	}

	public StatusType getGateStatus() {
		return gateStatus;
	}

	public void setGateStatus(StatusType gateStatus) {
		this.gateStatus = gateStatus;
	}

	public Date getMerTransDate() {
		return merTransDate;
	}

	public void setMerTransDate(Date merTransDate) {
		this.merTransDate = merTransDate;
	}

	public String getMerSyncNotifyUrl() {
		return merSyncNotifyUrl;
	}

	public void setMerSyncNotifyUrl(String merSyncNotifyUrl) {
		this.merSyncNotifyUrl = merSyncNotifyUrl;
	}

	public String getMerUnsyncNotifyUrl() {
		return merUnsyncNotifyUrl;
	}

	public void setMerUnsyncNotifyUrl(String merUnsyncNotifyUrl) {
		this.merUnsyncNotifyUrl = merUnsyncNotifyUrl;
	}

	public String getMerDesc() {
		return merDesc;
	}

	public void setMerDesc(String merDesc) {
		this.merDesc = merDesc;
	}

	public Kern getKern() {
		return kern;
	}

	public void setKern(Kern kern) {
		this.kern = kern;
	}






	

}
