package du.cfs.global.Unit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class OrderCode {

	

	public static int  StringCodeToInt(String mapString,String keyChar,String CodeString) {
		int unit = mapString.length();
		
		String[] arrstr = CodeString.split(keyChar);
		if(arrstr.length!=2)
			return -1;
		CodeString = arrstr[1];
		
		ArrayList<Integer> arr = new ArrayList<Integer>();
		
		for (char ch: CodeString.toCharArray()) {
			arr.add(mapString.indexOf(ch));
		}
		Collections.reverse(arr);
		int i = 0 ,out = 0;
		for (Integer value : arr) {
			out +=  value * Math.pow(unit,i) ;
			i++; 
		}
		return out;
	}
	
	public static String IntToCodeString(String mapString,String keyChar,int number,int bit) {
		int unit = mapString.length();
		int c = (number-(number%unit))/unit;
		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(number%unit);
		int b = 0;
		while(c>0){
			b = c%unit;
			c = (c - b) / unit;
			arr.add(b);
		}
		arr.add(-1);
		while(arr.size() < bit)
			arr.add(-2);
		Random ran = new Random();
		Collections.reverse(arr);
		String outString = "";
		for (Integer value : arr) {
			if(value==-1){
				outString += keyChar;
			}
			else if(value==-2){
				int r = ran.nextInt(mapString.length());
				outString += mapString.substring(r, r+1);
			}
			else{
				outString += mapString.substring(value, value+1);
			}
		}
		return outString;
	}
	

	
	
}
