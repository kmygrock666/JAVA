package du.cfs.global.Enums;

public enum StatusType {
	UNPAY(0), ALREADY_PAY(1), PAY_FAIL(2), KEEP(3);
	private final int id;

	StatusType(int id) {
		this.id = id;
	}

	public int getValue() {
		return id;
	}
}
