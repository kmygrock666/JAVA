package du.cfs.global.Service;


import du.cfs.global.db.Kern;

public interface KernService {
	Kern GetKernInfo(String kernCode);
	Kern save(Kern kern);
}
