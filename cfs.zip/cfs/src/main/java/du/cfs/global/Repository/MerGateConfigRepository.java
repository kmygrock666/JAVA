package du.cfs.global.Repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.global.Enums.PayType;
import du.cfs.global.db.MerGateConfig;



public interface MerGateConfigRepository extends JpaRepository<MerGateConfig, Integer> {

	Page<MerGateConfig> findAll(Pageable pageable);

	Optional<MerGateConfig> findById(int id);


	Optional<MerGateConfig> findByMerchant_merCode(String merCode);

	//Optional<MerGateConfig> findBymerCodeAndGateList_enableAndGateList_gatePayType(String merCode,Boolean gateEnable,PayType gatePayType);
	//Optional<MerGateConfig> findBymerCodeAnd_enableAnd_payType(String merCode,Boolean enable,PayType payType);
	Optional<MerGateConfig> findByMerchant_merCodeAndEnable(String merCode,Boolean enable);
	Optional<MerGateConfig> findByMerchant_merCodeAndEnableAndPayType(String merCode,Boolean enable,PayType payType);
	Optional<MerGateConfig> findByMerchant_merCodeAndEnableAndPayTypeAndMerGateList_enable(String merCode,Boolean enable,PayType payType,Boolean GateListEnable);
	Optional<MerGateConfig> findByMerchant_merCodeAndEnableAndPayTypeAndMerGateList_enableAndMerGateList_gatePayType(String merCode,Boolean enable,PayType payType,Boolean GateListEnable,PayType GateListPayType);
}
