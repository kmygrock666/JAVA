package du.cfs.global.Service;

import du.cfs.global.db.MerGateList;

public interface GateListService {
	MerGateList getGateList(int id);
	MerGateList save(MerGateList merGateList);
}
