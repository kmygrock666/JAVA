package du.cfs.global.Service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Enums.PayType;
import du.cfs.global.Repository.MerGateConfigRepository;
import du.cfs.global.db.MerGateConfig;

@Service
public class MerGateConfigServiceImpl implements MerGateConfigService {

	@Autowired
	MerGateConfigRepository repository;

	public MerGateConfig save(MerGateConfig merGateConfig) {
		return repository.save(merGateConfig);
	}

	public MerGateConfig getMerGateConfig(String merCode) {
		Optional<MerGateConfig> optional = repository.findByMerchant_merCode(merCode);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public MerGateConfig getMerGateConfigByPayType(String merCode, PayType payType) {

		Optional<MerGateConfig> optional = repository.findByMerchant_merCodeAndEnableAndPayTypeAndMerGateList_enable(merCode, true, payType, true);
		if (optional.isPresent()) {
			return optional.get();
		}

		return null;
	}
}
