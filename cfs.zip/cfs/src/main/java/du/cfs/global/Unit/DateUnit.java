package du.cfs.global.Unit;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;


public class DateUnit {

	public static Date StrToDateTime(String dateStr) {
		Date date = new Date();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			date = sdf.parse(dateStr);
			return date;
		} catch (Exception e) {

		}
		return null;
	}

	public static String DateTimeToStr(Date date) {
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			String dateStr = sdf.format(date);
			return dateStr;
		} catch (Exception e) {
		}
		return "";
	}
	
	public static Timestamp StrToTimestamp(String dateStr) {
		Timestamp ts = new Timestamp(System.currentTimeMillis());  
		try {
			  ts = Timestamp.valueOf(dateStr);  
			return ts;
		} catch (Exception e) {

		}
		return null;
	}
	public static String TimestampToStr(Timestamp ts) {
		return TimestampToStr(ts,"yyyy-MM-dd HH:mm:ss");
	}
	public static String TimestampToStr(Timestamp ts,String dateFormat) {
		DateFormat sdf = new SimpleDateFormat(dateFormat);
		try {
			String dateStr = sdf.format(ts);  
			return dateStr;
		} catch (Exception e) {
		}
		return "";
	}

	public static Date GetDate(int addSec) {
		Date date = new Date();
		LocalDateTime.from(date.toInstant()).plusSeconds(addSec);
		return date;
	}
	
	public static Timestamp GetTimestamp(int addSec) {
		Timestamp ts = new Timestamp(System.currentTimeMillis());  
		ts.setTime(ts.getTime() + (addSec* 1000));
		return ts;
	}
	
}
