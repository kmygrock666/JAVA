package du.cfs.global.Repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.global.db.Kern;

public interface KernRepository extends JpaRepository<Kern, Integer> {

	Page<Kern> findAll(Pageable pageable);

	Optional<Kern> findById(int id);

	Optional<Kern> findByKernCode(String kernCode);
}
