package du.cfs.global.Service;

import du.cfs.global.Enums.StatusType;
import du.cfs.global.db.MerGateList;
import du.cfs.global.db.RechargeOrder;

public interface RechargeService {

	RechargeOrder GetRechargeOrder(int id);

	RechargeOrder save(RechargeOrder r);

	RechargeOrder InsertOrder(MerGateList merGateList, RechargeOrder rechargeOrder);

	int UndateRechareOrderGateStatus(int id, StatusType status);
}
