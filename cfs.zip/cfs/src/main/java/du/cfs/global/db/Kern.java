package du.cfs.global.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Enums.PayType;

@Entity
public class Kern {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	// 商戶編號
	@Column( length = 50, nullable = false)
	private String kernCode;
	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	@Column(nullable = false)
	private String md5Key;
	private String rsaKey;
	private String apiIp;
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKernCode() {
		return kernCode;
	}

	public void setKernCode(String kernCode) {
		this.kernCode = kernCode;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	public String getMd5Key() {
		return md5Key;
	}

	public void setMd5Key(String md5Key) {
		this.md5Key = md5Key;
	}

	public String getRsaKey() {
		return rsaKey;
	}

	public void setRsaKey(String rsaKey) {
		this.rsaKey = rsaKey;
	}

	public String getApiIp() {
		return apiIp;
	}

	public void setApiIp(String apiIp) {
		this.apiIp = apiIp;
	}



	

}
