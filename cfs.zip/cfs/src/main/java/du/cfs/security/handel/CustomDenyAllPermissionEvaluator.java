package du.cfs.security.handel;

import java.util.Collection;

import org.springframework.security.access.expression.DenyAllPermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import du.cfs.security.UserPrinciple;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomDenyAllPermissionEvaluator extends DenyAllPermissionEvaluator{
	@Override
    public boolean hasPermission(Authentication authentication, Object target, Object permission) {
		UserPrinciple user = (UserPrinciple)authentication.getPrincipal();
        log.info("用户名是："+user.getUsername());
        Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) user.getAuthorities();
        for(GrantedAuthority authority : authorities) {
            String roleName = authority.getAuthority();
            log.info(user.getUsername()+"的权限有："+roleName);
        }
        log.info(authentication.getName()+"访问了"+target.toString()+"路径的"+permission.toString()+"权限");
        return true;
    }
}
