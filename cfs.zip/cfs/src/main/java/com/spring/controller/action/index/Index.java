package com.spring.controller.action.index;

import com.spring.controller.action.BaseAction;
import com.spring.security.UserPrinciple;

public class Index extends BaseAction{
	public String execute() {
		
		UserPrinciple userInfo = getUserInfo();
		System.out.println("-------------in Index Class-------------");
//		System.out.println("-------------使用者名稱-------------"+userInfo.getUsername());
//		System.out.println("-------------使用者暱稱-------------"+userInfo.getName());
//		System.out.println("-------------使用者權限-------------"+userInfo.getAuthorities().toString());
		return getView("index");
	}
}
