package com.spring.controller.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import com.spring.model.Commerce;
import com.spring.model.Menu;
import com.spring.model.Permission;
import com.spring.repository.CommerceRepository;
import com.spring.repository.CommerceRepository.MenuPermission;
import com.spring.security.UserPrinciple;
import com.spring.security.response.FieldResource;
import com.spring.service.CommerceService;
import com.spring.service.MenuService;

@Component
public class MenuOperate {
	
	@Autowired
    private CommerceService commerceService;
	
	@Autowired
    private MenuService menuService;
	
	private List<Map<String,Object>> menus = new ArrayList<>();
	
	public List<Map<String,Object>> getMenu(UserPrinciple userinfo) {
		
		if(menus.size() == 0) {
			System.out.println("menu == null");
			Collection<MenuPermission> permissions = commerceService.findMenuByUsername(userinfo.getUsername());
			List<Menu> menu = menuService.findAll();
			for(Menu m : menu) {
				List<MenuPermission> fieldpermission = new ArrayList<>();
				for(MenuPermission permission : permissions) {
					if( permission.getMenu_show().equals("1") && m.getId() == permission.getMenu()) {
						fieldpermission.add(permission);
					}
				}
				if(fieldpermission.size() > 0) {
					Map<String,Object> Mapp = new HashMap<>();
					Mapp.put("sub", m.getName());
					Mapp.put("icon", m.getIcon());
					Mapp.put("dir", fieldpermission);
					menus.add(Mapp);
				}
			}
		}
		
			
		return menus;
		
	}
}
