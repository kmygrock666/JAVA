package com.spring.controller.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.spring.security.UserPrinciple;

import lombok.Data;

@Data
@Controller
public abstract class BaseAction {
	
	private Model model;
	private HttpServletRequest request;
	private UserPrinciple user;
	
	public void init(Map<String,String> data) {
//		model = (Model) data.get("mode");
//		request = (HttpServletRequest) data.get("request");
//		user = (UserPrinciple) data.get("user");
	}
	
	public UserPrinciple getUserInfo() {
		return (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	}
	
	public String getView(String path) {

		return path;
	}

}
