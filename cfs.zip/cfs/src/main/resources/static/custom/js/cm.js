function logout(){
	parent.location.href = "/logout";
}