function logout(){
	parent.location.href = "/logout";
}

function getLoad(url){
	$("#container").load(url);
}