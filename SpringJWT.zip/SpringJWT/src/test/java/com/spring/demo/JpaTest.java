package com.spring.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.spring.Application;
import com.spring.database.DBContextHolder;
import com.spring.model.Account;
import com.spring.model.User;
import com.spring.repository.AccountRepository;
import com.spring.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class JpaTest {
	@Autowired
    private UserService commerceService;
	
	@Autowired
    private AccountRepository accountRepository;
	
	@Test
	public void TestFindByUsername() throws Exception{
		DBContextHolder.setDbType(DBContextHolder.DB_TYPE_PRIMARY);
		Optional<User> user = commerceService.GetUserByName("AAA");
		System.out.println("FIND SUCCESS");
		assertThat(user).isNotNull();
		System.out.println("IS NOT NULL");
		assertThat(user.get().getUsername()).isEqualTo("AAA");
		System.out.println("IS USERNAME");
		assertThat(user.get().getId()).isEqualTo(2);
		System.out.println("======================ONE");
		System.out.println(user.get().getUsername());
		
		DBContextHolder.setDbType(DBContextHolder.DB_TYPE_SECONDARY);
		List<Account> user2 = accountRepository.findAll();
		assertThat(user2).isNotNull();
		assertThat(user2.get(0).getName()).isEqualTo("BBB");
		System.out.println("======================TWO");
		System.out.println(user2.get(0).getName());
		System.out.println(user2.size());
	}
	
//	@Test
//	public void TestDataSourceTwo() throws Exception{
//		DBContextHolder.setDbType(DBContextHolder.DB_TYPE_SECONDARY);
//		List<Account> user = accountRepository.findAll();
//		assertThat(user).isNotNull();
//		assertThat(user.get(0).getName()).isEqualTo("BBB");
//		System.out.println("======================TWO");
//		System.out.println(user.get(0).getName());
//		System.out.println(user.size());
//		
//	}
}
