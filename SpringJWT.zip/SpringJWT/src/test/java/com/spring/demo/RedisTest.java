package com.spring.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.spring.Application;
import com.spring.model.User;
import com.spring.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class RedisTest {
	@Autowired
    private RedisTemplate redisTemplate;
	
	@Autowired
	private UserService commerceService;
	
	@Resource(name = "redisTemplate")
	private ValueOperations<String,Object> valueOperations;
	
	@Test
	public void redisString() {
//		redisTemplate.opsForValue();//操作字符串
//		redisTemplate.opsForHash();//操作hash
//		redisTemplate.opsForList();//操作list
//		redisTemplate.opsForSet();//操作set
//		redisTemplate.opsForZSet();//操作有序set
		String key = "name";
		redisTemplate.opsForValue().set(key, "yukong");
		System.out.println("設置緩存中key為" + key + "的值為 :yukong");
		String value = (String) redisTemplate.opsForValue().get(key);
        System.out.println("獲取緩存中key為" + key + "的值為：" + value);
        Optional<User> user = commerceService.GetUserByName("AAA");
        assertThat(redisTemplate.hasKey(key)).isTrue();
        redisTemplate.delete(key);
	}
	@Test
	public void redisList() {
		String key = "ListTest";
		String value = "List";
		redisTemplate.opsForList().rightPush(key, value);
        redisTemplate.opsForList().rightPush(key, value+"a");
        redisTemplate.opsForList().rightPush(key, value+"b");
        assertThat(redisTemplate.hasKey(key)).isTrue();
        redisTemplate.delete(key);
        
        redisTemplate.opsForList().leftPush("list","java");
        redisTemplate.opsForList().leftPush("list","python");
        redisTemplate.opsForList().leftPush("list","c++");
        assertThat(redisTemplate.hasKey("list")).isTrue();
        redisTemplate.delete("list");
	}
	
	@Test
	public void redisHash() {
		Map<String,Object> testMap = new HashMap();
        testMap.put("name","jack");
        testMap.put("age","27");
        testMap.put("class","1");
        redisTemplate.opsForHash().putAll("redisHash1",testMap);
        
        System.out.println(redisTemplate.opsForHash().entries("redisHash1"));
        System.out.println(redisTemplate.opsForHash().get("redisHash","age"));
        assertThat(redisTemplate.hasKey("redisHash1")).isTrue();
        redisTemplate.delete("redisHash1");
	}
}
