package com.spring.config;

import javax.servlet.Filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.spring.security.JwtAuthEntryPoint;
import com.spring.security.JwtAuthTokenFilter;
import com.spring.security.UserDetailsServiceImpl;
import com.spring.security.handel.CustomAccessDeniedHandler;
import com.spring.service.UserService;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true) 
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	@Autowired
    UserDetailsServiceImpl userDetailsService;
 
    @Autowired
    private JwtAuthEntryPoint unauthorizedHandler;
    
    @Autowired
    private CustomAccessDeniedHandler myAccessDeniedHandler;
 
    @Bean
    public JwtAuthTokenFilter authenticationJwtTokenFilter() {
        return new JwtAuthTokenFilter();
    }
 
    @Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        authenticationManagerBuilder
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());   //使用BCrypt進行密碼的hash
    }
 
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
 
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors().and().csrf().disable()
                .authorizeRequests()
                .antMatchers("/api/auth/**").permitAll()
//                .antMatchers("/cm/auth/**").permitAll()
                .antMatchers("/api/**").authenticated()
                .and()
                //當前用戶請求資源，但是未通過認證，拋出異常
                .exceptionHandling().authenticationEntryPoint(unauthorizedHandler)
                //認證用戶請求時無權限，拋出異常
                .accessDeniedHandler(myAccessDeniedHandler)
                .and()
                // don't create session
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        
        http.addFilterBefore((Filter) authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
        // disable page caching
        http.headers().cacheControl();
    }
    

    
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//			http
//		    	.exceptionHandling()
//					.accessDeniedPage("/403") //存取被拒時導往的URL
//		.and()
//			.authorizeRequests() //表示以下都是授权的配置 
//	        .antMatchers("/bootstraps/**","/", "/favicon.ico").permitAll() //允许所有用户访问
//	        .antMatchers("/cm/**").hasAuthority("USER")
//	        .antMatchers("/signup").hasAuthority("ADMIN")
//	        .anyRequest().authenticated() //其他请求需要登录认证
//	    .and()
//	        .formLogin()
//	        .loginPage("/login")
//	
//	        .defaultSuccessUrl("/cm/index")
//	        .permitAll()
//	    .and()
//	    	.csrf().disable();// 禁用跨站攻击
//	}
	
    @Override
    public void configure(WebSecurity web) throws Exception {
    	
        web.ignoring().antMatchers("/bootstraps/**", "/swagger-resources/**", "/swagger-ui.html**", "/webjars/**");
    }
	
}
