package com.spring.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.User;
import com.spring.repository.UserRepository;

@Service
public class UserService {
	@Autowired
    private UserRepository commerceRepository;
	
	public Optional<User> GetUserByName(String name) {
		return commerceRepository.findByUsername(name);
	}
}
