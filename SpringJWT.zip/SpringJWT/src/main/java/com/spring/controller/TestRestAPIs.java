package com.spring.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.security.UserPrinciple;

@RestController
public class TestRestAPIs {
	@GetMapping("/api/test/user")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public String userAccess() {
		return ">>> User Contents!";
	}
	
	@GetMapping("/api/test/pm")
	@PreAuthorize("hasRole('PM') or hasRole('ADMIN')")
	public String projectManagementAccess() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserPrinciple userPrincipal = (UserPrinciple) authentication.getPrincipal();
		if (!(authentication instanceof AnonymousAuthenticationToken)) {
		    String currentUserName = authentication.getName();
		    System.out.println(currentUserName);
		    System.out.println(authentication.getDetails());
		    System.out.println(authentication.getAuthorities());
		    System.out.println(userPrincipal.getName());
		    System.out.println(userPrincipal.getEmail());
		    System.out.println(userPrincipal.getPassword());
		    System.out.println(userPrincipal.getAuthorities().toString());
		}
		return ">>> Board Management Project";
	}
	
	@GetMapping("/api/test/admin")
	@PreAuthorize("hasRole('ADMIN')")
	public String adminAccess() {
		return ">>> Admin Contents";
	}
}
