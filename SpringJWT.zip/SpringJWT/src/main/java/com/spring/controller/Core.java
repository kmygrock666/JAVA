package com.spring.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.*;
@Controller
@RequestMapping("/cm")
public class Core {

	@GetMapping("/{action}")
	public String home() {
		return "index";
	}
	
	@GetMapping("/auth/login")
	public String login() {
		
		System.out.println("Login");
		return "login";
	}
}
