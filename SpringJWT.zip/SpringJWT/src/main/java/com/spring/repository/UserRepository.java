package com.spring.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.model.User;

public interface UserRepository extends JpaRepository<User, Long>{
	Optional<User> findByUsername(String username);
	Boolean existsByUsername(String username);
	
	
	/**
	 * 45689798
	 * @param email 123123123
	 * @return 12313
	 */
    Boolean existsByEmail(String email);

}
