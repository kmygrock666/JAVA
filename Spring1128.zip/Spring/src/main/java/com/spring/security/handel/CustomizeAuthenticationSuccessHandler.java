package com.spring.security.handel;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.spring.config.SysConfig;
import com.spring.security.UserPrinciple;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomizeAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler  {
	
	@Autowired
    private RedisTemplate redisTemplate;
	
	@Autowired
	SysConfig conf;
	
	public static HashMap<String, HttpSession> sessionMap = new HashMap<String, HttpSession>();
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		// TODO Auto-generated method stub
//		Cookie[] cookies = request.getCookies();
//    	String token = "";
//
//    	for(Cookie cookiel : cookies){
//    		System.out.println("cookies 的 key 為 "+cookiel.getName()+"  值為 "+cookiel.getValue());
//    		if(cookiel.getName().equals(conf.getCookies())) {
//    			token = cookiel.getValue();
//    			break;
//    		}
//        }
		
		
		
//		SecurityContext sc = SecurityContextHolder.getContext();
//		String  currentuser =  ((UserPrinciple) sc.getAuthentication().getPrincipal()).getUsername();
//		System.out.println("當前用戶"+currentuser);
//		
//		Iterator<Entry<String, HttpSession>> iterator = sessionMap.entrySet().iterator();
//		while(iterator.hasNext()) {
//			Map.Entry<String, HttpSession> entry = iterator.next();
//			HttpSession session = entry.getValue();
//			// 2.1 判断session中所包含的用户名称是否有当前登录用户
//			SecurityContext attribute = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
//			UserPrinciple principal = (UserPrinciple) attribute.getAuthentication().getPrincipal();
//
//			String username = principal.getUsername();
//			if (currentuser.equals(username)) {
//				logger.info("用户：" + currentuser + "已经在其它地方登录过，将踢除！");
////				SessionUtil.expireSession(session);
//				logger.info("删除的会话："+entry.getKey());
//				// 2.2 从sessionMap中踢除会话
//				iterator.remove();
//				// 2.3 从sessionRegistry中踢除会话
////				sessionRegistry.removeSessionInformation(session.getId());
//			}
//		}
//		long loginTime = System.currentTimeMillis();
//		Map<String,Object> userAll = redisTemplate.opsForHash().keys("user");
//		Cursor<Map.Entry<Object, Object>> curosr = redisTemplate.opsForHash().scan("redisHash", ScanOptions.ScanOptions.NONE);
//	      while(curosr.hasNext()){
//	          Map.Entry<Object, Object> entry = curosr.next();
//	          System.out.println(entry.getKey()+":"+entry.getValue());
//	      }

		HttpSession session = request.getSession();
		String token = session.getId();
		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//		
		Map<String,Object> testMap = new HashMap();
        testMap.put("account",userPrincipal.getUsername());
        testMap.put("username",userPrincipal.getName());
        testMap.put("role",userPrincipal.getRole().toString());
//        testMap.put("loginTime",loginTime);
        redisTemplate.opsForHash().putAll("user:"+token,testMap);
		log.info("登入成功------------------------- "+token);
		response.sendRedirect("/cm/Index");
	}

}
