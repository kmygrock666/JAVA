package com.spring.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="persistent_logins")
public class RememberToken {
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String series;
	
	private String username;
	
	private String token;
	
	private Date  last_used;
}
