package com.spring.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Data;

@Data
@Configuration
@PropertySource("classpath:/config/sysConfig.properties")
@ConfigurationProperties(prefix = "config")
public class SysConfig {
	private String cookies;
}
