package du.cfs.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.setMaxElementsForPrinting;
import static org.junit.Assume.assumeTrue;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import du.cfs.Application;
import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.RememberTokenService;
import du.cfs.common.service.RoleService;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.config.database.DBContextHolder;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountRepository;
import du.cfs.db.ADM.AccountService;
import du.cfs.global.Unit.CURL;
import du.cfs.global.Unit.HttpCurl;

@RunWith(SpringRunner.class)
@ActiveProfiles(profiles = "dev")
@SpringBootTest(classes = Application.class)
public class systemTest {
	@Autowired
    private RememberTokenService commerceService;
	
	@Autowired
    private PermissionService permissionService;
	
	@Autowired
    private MenuService menuService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	AccountService accountService;
	
	@Test
	public void URLEncoderTest() throws UnsupportedEncodingException {
		 System.out.println(URLEncoder.encode("測試類", "UTF-8"));
		 System.out.println(URLEncoder.encode("/test/testtttt", "UTF-8"));
		 System.out.println(URLEncoder.encode("tesctes", "UTF-8"));
		 System.out.println(URLEncoder.encode("ab/測試", "UTF-8"));
	}
	
	@Test
	public void RoleSave() {
		String code =  "rolecode";
		String name =  "roledes";
//		Role role = roleService.findById(3L);
		Role role = roleService.findByName("rolecode");
		System.out.println(role.getCreatedAt());
//		if(role == null)
//			role = new Role();
//		role.setId(3L);
		role.setName("ROLE_"+code.toUpperCase());
		role.setDescription(name);
//		System.out.println(JSON.toJSONString(role));
		roleService.saveRole(role);
//		roleService.updateRole(code, name, 3L);
		System.out.println("success");
	}
	
	
	
	
}
