package du.cfs.global.db.KERN;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Data;

//Merchant
//商戶通道設定
@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merCode" }) })
public class Merchant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	@Column(nullable = false)
	private String md5Key;
	private String rsaKey;

	private String apiIp;
	private String backstageIp;

	@Column(length = 50, nullable = false)
	private String gmIp;

	@OneToMany(mappedBy = "merchant", cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	private List<MerRechargeOrder> RechargeOrder = new ArrayList<MerRechargeOrder>();

	@Column(length = 50, nullable = true, updatable = false)
	private String merCode;
}
