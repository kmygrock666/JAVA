package du.cfs.global.db.GATE;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Gen.cfsEnum.ProcResultState;
import du.cfs.global.Unit.OrderCode;

@Service
public class GateAgentPayOrderServiceImpl implements GateAgentPayOrderService {

	@Autowired
	private GateAgentPayOrderRepository repository;

	public GateAgentPayOrder GetRechargeOrder(int id) {
		Optional<GateAgentPayOrder> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public GateAgentPayOrder GetRechargeOrder(String kernOrderNumber) {
		int id = OrderCode.StringCodeToInt(codeMap, codeKey, kernOrderNumber);
		return GetRechargeOrder(id);
	}

	private static String codeMap = "vwA0xyBzWXDZQbUcMOd7Eqrst1SunH2PoL6eTY4i3GkIfgRJKjChlmNVa5p"; // form config
	private static String codeKey = "F"; // from config

	public GateAgentPayOrder InsertOrder(GateAgentPayOrder rechargeOrder) {
		try {
			rechargeOrder = repository.save(rechargeOrder);
			String orderCode = OrderCode.IntToCodeString(codeMap, codeKey, (int) rechargeOrder.getId(), 20);
			rechargeOrder.setGateOrderNumber(orderCode);
			rechargeOrder = repository.save(rechargeOrder);
			return rechargeOrder;
		} catch (Exception e) {
			return null;
		}
	}

	public GateAgentPayOrder save(GateAgentPayOrder r) {
		return repository.save(r);
	}

	public List<GateAgentPayOrder> findBygateCodeAndProcResultState(String gateCode, ProcResultState procResultState) {
		return repository.findBygateCodeAndProcResultStateGate(gateCode, procResultState);
	}
}
