package du.cfs.global.Unit;

import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.gson.Gson;
import com.google.gson.Gson;



public class HttpCurl {


	public static JSONObject  post (final Object  data, final String URL) {

		ObjectMapper objectMapper = new ObjectMapper();
		String requestJson = null;
		try {
			requestJson = objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			//e.printStackTrace();
			return null;
		}

        HttpEntity<String> entity = setParam(requestJson);
        RestTemplate restTemplate = curlSetting();
        ResponseEntity<String> response = restTemplate.exchange(URL, HttpMethod.POST, entity, String.class);
//        Integer code = response.getStatusCode().value();
        JSONObject body = JSONObject.parseObject(response.getBody());
        return body;
	}

	public static JSONObject get(final String URL) {
        RestTemplate restTemplate = curlSetting();
        ResponseEntity<String> response = restTemplate.getForEntity(URL, String.class);
        System.out.println(JSON.toJSONString(response,true));
        JSONObject body = JSONObject.parseObject(response.getBody());
        return body;
	 
	}
	
	public static JSONObject  delete (Map<String, Object> map, final String URL) {
        HttpEntity<String> entity = setParam(null);
        RestTemplate restTemplate = curlSetting();
        ResponseEntity<String> response = restTemplate.exchange(URL, HttpMethod.DELETE, entity, String.class,map);
//        Integer code = response.getStatusCode().value();
		JSONObject body = JSONObject.parseObject(response.getBody());
        return body;
	}
	
	//設定
	public static RestTemplate curlSetting() {
        SimpleClientHttpRequestFactory requestFactory = new  SimpleClientHttpRequestFactory();
        //設置客戶端和服務端建立連接的超時時間
        requestFactory.setConnectTimeout(180000);
        //設置客戶端從服務端讀取數據的超時時間
        requestFactory.setReadTimeout(180000);
        //緩衝請求數據，默認為true。通過POST或者PUT大量發送數據時，建議將此更改為false，以免耗盡內存
        requestFactory.setBufferRequestBody(false);
        
		return new RestTemplate(requestFactory);
	}
	
	public static HttpEntity<String> setParam(String  param) {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        return new HttpEntity<String>(param, headers);

	}

	static int connectTimeout = 105000;
	static int readTimeout = 105000;
	public static <T> T postToObject(final Object data, final String URL, Class<T> clazz) {

		ObjectMapper objectMapper = new ObjectMapper();
//		 objectMapper.setSerializationInclusion(Inclusion.NON_EMPTY);
		String requestJson = null;
		try {
			requestJson = objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			// e.printStackTrace();
			return null;
		}
		// 設定表頭
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);

		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		// 設置客戶端和服務端建立連接的超時時間
		requestFactory.setConnectTimeout(connectTimeout);
		// 設置客戶端從服務端讀取數據的超時時間
		requestFactory.setReadTimeout(readTimeout);
		// 緩衝請求數據，默認為true。通過POST或者PUT大量發送數據時，建議將此更改為false，以免耗盡內存
		requestFactory.setBufferRequestBody(false);

		RestTemplate restTemplate = new RestTemplate(requestFactory);
		ResponseEntity<String> response = restTemplate.exchange(URL, HttpMethod.POST, entity, String.class);

		Gson gson = new Gson();

		return gson.fromJson(response.getBody(), clazz);
	}

	public static String postToString(final Object data, final String URL) {

		ObjectMapper objectMapper = new ObjectMapper();
//		 objectMapper.setSerializationInclusion(Inclusion.NON_EMPTY);
		String requestJson = null;
		try {
			requestJson = objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			// e.printStackTrace();
			return null;
		}
		// 設定表頭
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);

		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		// 設置客戶端和服務端建立連接的超時時間
		requestFactory.setConnectTimeout(connectTimeout);
		// 設置客戶端從服務端讀取數據的超時時間
		requestFactory.setReadTimeout(readTimeout);
		// 緩衝請求數據，默認為true。通過POST或者PUT大量發送數據時，建議將此更改為false，以免耗盡內存
		requestFactory.setBufferRequestBody(false);

		RestTemplate restTemplate = new RestTemplate(requestFactory);
		ResponseEntity<String> response = restTemplate.exchange(URL, HttpMethod.POST, entity, String.class);
//        Integer code = response.getStatusCode().value();

		return response.getBody();
	}

	public static ResponseEntity<String> postToResponseEntity(final Object data, final String URL) {

		ObjectMapper objectMapper = new ObjectMapper();
//		 objectMapper.setSerializationInclusion(Inclusion.NON_EMPTY);
		String requestJson = null;
		try {
			requestJson = objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			// e.printStackTrace();
			return null;
		}
		// 設定表頭
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);

		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		// 設置客戶端和服務端建立連接的超時時間
		requestFactory.setConnectTimeout(connectTimeout);
		// 設置客戶端從服務端讀取數據的超時時間
		requestFactory.setReadTimeout(readTimeout);
		// 緩衝請求數據，默認為true。通過POST或者PUT大量發送數據時，建議將此更改為false，以免耗盡內存
		requestFactory.setBufferRequestBody(false);

		RestTemplate restTemplate = new RestTemplate(requestFactory);
		ResponseEntity<String> response = restTemplate.exchange(URL, HttpMethod.POST, entity, String.class);
//        Integer code = response.getStatusCode().value();

		return response;
	}

	public static ResponseEntity<String> getToResponseEntity(final String URL) {
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setConnectTimeout(connectTimeout);// 设置超时
		requestFactory.setReadTimeout(readTimeout);
		RestTemplate restTemplate = new RestTemplate(requestFactory);
		ResponseEntity<String> response = restTemplate.getForEntity(URL, String.class);
		return response;

	}

}
