package du.cfs.controller.action.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;
import du.cfs.controller.action.system.vo.AuthPermissionVO;
import du.cfs.controller.action.system.vo.AuthRoleVO;
import du.cfs.controller.action.system.vo.MenuVO;

public class AuthPermission extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	MenuService menuService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
//		String code =  getParam("code");
		List<Menu> menus = menuService.findAll();
//		Role roles = roleService.findByName(code).orElse(null);
//		List<Permission> permissions = permissionService.findAll();

//		Map<String, String> permissions = roles.getPermissions().stream().collect(Collectors.toMap(Permission::getPermission, Permission::getPermission));
		List<Object> parents = new ArrayList<>();
		List<MenuVO> menuList = new ArrayList<>();
		for(Menu m: menus) {
			MenuVO menuVO = new MenuVO();
			BeanUtils.copyProperties(m, menuVO);
			
			List<Permission> permission = m.getPermissions();
			List<AuthPermissionVO> authPermissionVOList = permission.stream().map(item->{
				AuthPermissionVO authPermissionVO = new AuthPermissionVO();
				BeanUtils.copyProperties(item, authPermissionVO);
	            return authPermissionVO;
			}).collect(Collectors.toList());
			
			menuVO.setPermissions(authPermissionVOList);
			menuList.add(menuVO);
			
			Map<String, String> parent = new HashMap<>();
			parent.put("code", m.getCode());
			parent.put("name", m.getName());
			parents.add(parent);
		}
		assign("menus",menuList);
		assign("parents",parents);
//		assign("perAll",permissions);
//		System.out.println(JSON.toJSONString(permissions,true));
//		System.out.println(JSON.toJSONString(menuList));
//		System.out.println(JSON.toJSONString(parents));
		System.out.println("Success");
		return getView("authPermission");
	}
	
}
