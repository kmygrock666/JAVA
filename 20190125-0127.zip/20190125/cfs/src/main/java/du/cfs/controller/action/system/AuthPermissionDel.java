package du.cfs.controller.action.system;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class AuthPermissionDel extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	MenuService menuService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		String id =  getParam("id");
		
		permissionService.deletePermission(Long.parseLong(id));
		System.out.println("Delete Success");
		return redirect("system/AuthPermission");
	}
	
}
