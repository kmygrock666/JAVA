package du.cfs.global.Gen;

public class ApiPathMenu {


	public static class CONFIG_KERN {
		public static final String Domain = "/v2";
		public static final String path_Mer_Recharge = "/api/Recharge";
		public static final String Mer_Recharge = Domain + path_Mer_Recharge;

		public static final String path_Mer_AgentPay = "/api/AgentPay";
		public static final String Mer_AgentPay = Domain + path_Mer_AgentPay;

		public static final String path_Gm_RechargeFeebback = "/gm/RechargeFeebback";
		public static final String Gm_RechargeFeebback = Domain + path_Gm_RechargeFeebback;

		public static final String path_Gm_AgentPayFeebback = "/gm/AgentPayFeebback";
		public static final String Gm_AgentPayFeebback = Domain + path_Gm_AgentPayFeebback;
	}

	public static class CONFIG_GM {
		public static final String Domain = "/gm";

		public static final String path_Kern_AgentPay = "/kern/AgentPay";
		public static final String Kern_AgentPay = Domain + path_Kern_AgentPay;

		public static final String path_Kern_Recharge = "/kern/Recharge";
		public static final String Kern_Recharge = Domain + path_Kern_Recharge;


		public static final String path_Gate_RechargeFeebback = "/gate/RechargeFeebback";
		public static final String Gate_RechargeFeebback = Domain + path_Gate_RechargeFeebback;
		
		public static final String path_Gate_AgentPayFeebback = "/gate/AgentPayFeebback";
		public static final String Gate_AgentPayFeebback = Domain + path_Gate_AgentPayFeebback;

		public static final String path_Gate_GateConfig = "/gate/GateConfig";
		public static final String Gate_GateConfig = Domain + path_Gate_GateConfig;
		
		

		public static final String path_Jump_GateConfigAll = "/jump/GateConfigAll";
		public static final String Jump_GateConfigAll = Domain + path_Jump_GateConfigAll;
	}

	public static class CONFIG_GATE {
		public static final String Domain = "/gate";

		public static final String ptah_Sys_Config = "/sys/config";
		public static final String Sys_Config = Domain + ptah_Sys_Config;

		public static final String ptah_Gm_Recharge = "/gm/Recharge";
		public static final String Gm_Recharge = Domain + ptah_Gm_Recharge;

		public static final String ptah_Gm_AgentPay = "/gm/AgentPay";
		public static final String Gm_AgentPay = Domain + ptah_Gm_AgentPay;

		public static final String path_Jump_Feedback = "/jump/Feedback";
		public static final String path_Jump_Return = "/jump/Return";
		public static final String path_Jump_Jumper = "/jump/Jump";
		public static final String Jump_Feedback = Domain + path_Jump_Feedback;
		public static final String Jump_Return = Domain + path_Jump_Return;
		public static final String Jump_Jumper = Domain + path_Jump_Jumper;

	}

	public static class CONFIG_JUMP {
		public static final String Domain = "/jump";

		public static final String path_Gate_Proxy = "/gate/jump";
		public static final String Gate_Proxy = Domain + path_Gate_Proxy;

		public static final String path_Gate_AddRechargeResult = "/gate/jump";
		public static final String Gate_AddRechargeResult = Domain + path_Gate_AddRechargeResult;

		public static final String path_Third_Feed = "/thrid/feedback";
		public static final String Third_Feed = Domain + path_Third_Feed;
		public static final String path_Third_Return = "/thrid/return";
		public static final String Third_Return = Domain + path_Third_Return;

		public static final String path_User_Jump = "/user/jump";
		public static final String User_Jump = Domain + path_User_Jump;
	}
}
