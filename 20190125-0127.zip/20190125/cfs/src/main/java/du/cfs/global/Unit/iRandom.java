package du.cfs.global.Unit;

import java.util.Random;
import java.util.UUID;

public class iRandom {
	public static int GetRand(int Max, int min) {
		Random ran = new Random();
		return ran.nextInt(Max) + min;
	}
	public static String GetUUID() {
		return UUID.randomUUID().toString();
	}
}
