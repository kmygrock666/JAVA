package du.cfs.global.db.KERN;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantRepository extends JpaRepository<Merchant, Integer> {

	Page<Merchant> findAll(Pageable pageable);
	Optional<Merchant> findById(int id);
	Optional<Merchant> findBymerCode(String merCode);
}
