package du.cfs.global.Gen;

import java.util.Date;

import du.cfs.global.Gen.cfsEnum.AgentPayOrderStatus;
import du.cfs.global.Gen.cfsEnum.ProcResultState;
import du.cfs.global.Gen.cfsEnum.ServiceType;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
public class Struce_Input_AgentPayFeedback extends converBase {
	private String merCode = "";
	private String gateCode;
	private String gateBN;
	private String gateOrderNumber = "";
	private String kernOrderNumber = "";
	private String merOrderNumber = "";
	private int merAmount;
	private AgentPayOrderStatus orderStatus;
	private ProcResultState procResultStateGate = ProcResultState.UNSET;
	private ProcResultState procResultStateGm = ProcResultState.UNSET;
	private ProcResultState procResultStateKern = ProcResultState.UNSET;
	private Date thirdTranDate;
	protected String thirdMsg;
	private ServiceType serviceType;
}

