package du.cfs.common.service;


import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import du.cfs.common.model.Role;
import du.cfs.common.repository.RoleRepository;
import du.cfs.db.ADM.AccountRepository;

@Service
public class RoleService {
	@Autowired
    private RoleRepository roleRepository;
	
	@Autowired
    private AccountRepository accountRepository;
	
	/**
	 * 查詢角色
	 * @param name
	 * @return
	 */
	public Role findByName(String name) {
		return roleRepository.findByName(name).orElse(null);
	}
	
	public Role findById(Long id) {
		return roleRepository.findById(id).orElse(null);
	}
	
	public void updateRole(String description,Long id) {
		roleRepository.updateRole(description, id);
	}
	
	public Role saveRole(Role role) {
		System.out.println("run save");

		return roleRepository.save(role);
	}
	
	public List<Role> findAll() {
		return roleRepository.findAll();
	}
	
	@Transactional
	public void deleteRole(long id) {
		Role role = roleRepository.findById(id).orElse(null);
//		System.out.println(JSON.toJSONString(role,true));
//		for(Account account : role.getAccount()) {
//			account.getRoles().remove(role);
//		}
		
		roleRepository.delete(role);
//		roleRepository.deleteRole(id);
	}
	
	public  Role findAll(Long id) {
		return roleRepository.findById(id).orElse(null);
	}
	
	
	

	
	
}
