package du.cfs.global.db.KERN;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.validator.constraints.Length;

import du.cfs.global.Gen.cfsEnum.AgentPayOrderStatus;
import du.cfs.global.Gen.cfsEnum.BankType;
import du.cfs.global.Gen.converBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merchant_id", "merOrderNumber" }) })
@Entity
public class MerAgentPayOrder extends converBase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
	@ManyToOne
	private Merchant merchant;
	// ---------------------------------------------------

	@Column(length = 50, updatable = false, nullable = false)
	private String merOrderNumber;
	@Column(updatable = false, nullable = false)
	protected int merAmount;
	@Column(nullable = false)
	protected BankType merBankId;
	@Length(max = 20)
	protected String merAccount;
	@Length(max = 20)
	protected String merAccountName;
	@Length(max = 20)
	protected String province;
	@Length(max = 20)
	protected String city;

	// ---------------------------------------------------
	@Column(columnDefinition = "TINYINT(1)")
	private AgentPayOrderStatus orderStatus;
	// ---------------------------------------------------
	// ---------------------------------------------------
	@Length(max = 20)
	protected String thirdMsg;
	// ---------------------------------------------------
	// ---------------------------------------------------
	// ---------------------------------------------------
	@Column(length = 50)
	private String kernOrderNumber;
	@Column(length = 50)
	private String gateOrderNumber;
	@Column(length = 50)
	private String gateBN;
	// ---------------------------------------------------

	public MerAgentPayOrder() {
	}

	// ----------------------------------------------------------

	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
		this.orderStatus = AgentPayOrderStatus.UNPAY;
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------

	// ----------------------------------------------------------

}
