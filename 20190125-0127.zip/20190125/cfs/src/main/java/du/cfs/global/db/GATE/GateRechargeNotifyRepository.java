package du.cfs.global.db.GATE;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.global.Gen.cfsEnum.NotifyStatus;

public interface GateRechargeNotifyRepository extends JpaRepository<GateRechargeNotify, Integer> {

	Page<GateRechargeNotify> findAll(Pageable pageable);

	List<GateRechargeNotify> findByhidenCreatedAtGreaterThanAndHidenNotifyStatus(Date date, NotifyStatus notifyStatus);
}
