package du.cfs.common.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import du.cfs.common.model.Permission;

public interface PermissionRepository extends JpaRepository<Permission, Long>{
	
	@Transactional
	@Modifying
	@Query("delete from Permission p where p.id = ?1")
	void deleteBy(Long id);
	
	Permission findByPermission(String psermission);

	List<Permission> findAllByOrderByListorderAsc();
}
