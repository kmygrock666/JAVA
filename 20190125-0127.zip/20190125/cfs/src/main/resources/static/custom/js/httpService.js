axios.defaults.timeout = 5000;
axios.defaults.baseURL = '/cm'; // 域名

//http request 欄截
axios.interceptors.request.use(
  config => {
    config.data = JSON.stringify(config.data);
//    config.headers = { // 如果沒有cors的問題則可以都不加
//      "Access-Control-Allow-Origin": process.env.API_ROOT,
//      "Access-Control-Allow-Methods": "GET, PUT, POST, DELETE, OPTIONS",
//      "Access-Control-Max-Age": "86400"
//    };
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

//異常處理
axios.interceptors.response.use(
  response => {
    return response;
  },
  err => {
    if (err && err.response) {
      switch (err.response.status) {
        case 404:
          console.log("找不到該頁面");
          break;
        case 500:
          console.log("伺服器出錯");
          break;
        case 503:
          console.log("服務失效");
          break;
        default:
          console.log(`連接錯誤${err.response.status}`);
      }
    } else {
      console.log("連接到服務器失敗");
    }
    return Promise.resolve(err.response);
  }
);

function getUrl(url){
	axios.get(url).then(response => {
//		console.log(response);
		refreshView(response.data);
	},error =>{
		if(!error.body.success)
			parent.location.href = '';
		refreshView(error.body);
	})
}

//API
var instanceApi = axios.create({
    baseURL: '/api',
    timeout: 1000,
}) 

instanceApi.interceptors.response.use(
  response => {
    return response;
  },
  err => {
    if (err && err.response) {
      switch (err.response.status) {
        case 404:
          console.log("找不到該頁面");
          break;
        case 500:
          console.log("伺服器出錯");
          break;
        case 503:
          console.log("服務失效");
          break;
        default:
          console.log(`連接錯誤${err.response.status}`);
      }
    } else {
      console.log("連接到服務器失敗");
    }
    return Promise.resolve(err.response);
  }
);
//instanceApi.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
//http request 欄截
instanceApi.interceptors.request.use(
  config => {
    config.data = JSON.stringify(config.data);
//    config.headers = { // 如果沒有cors的問題則可以都不加
////      "Access-Control-Allow-Origin": process.env.API_ROOT,
////      "Access-Control-Allow-Methods": "GET, PUT, POST, DELETE, OPTIONS",
////      "Access-Control-Max-Age": "86400"
//      'Content-Type': 'application/x-www-form-urlencoded'
//    };
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);