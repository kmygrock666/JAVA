import os
import plistlib

def w():
   pl = {
   "aString" : "Doodah",
   "aList" : ["A", "B", 12, 32.1, [1, 2, 3]],
   "aFloat" : 0.1,
   "anInt" : 730
   }

   fileName=os.path.expanduser('~/Desktop/example.plist')

   plistlib.writePlist(pl, fileName)


def r():
    #fileName = os.path.expanduser('~/Desktop/example.plist')
    fileName = 'plist/180103_Datang_Shengshi.plist' #改這裡的路徑

    if os.path.exists(fileName):

        pl = plistlib.readPlist(fileName)
        print('\nThe plist full contents is %s\n' % pl)

        for p in pl['frames']:
            if 'frame' in pl['frames'][p]:
                print('The frame %s is %s\n' %(p, pl['frames'][p]['frame']))
            else:
                print('There is no frame in the plist\n')

    else:
        print('%s does not exist, so can\'t be read' % fileName)


if __name__ == '__main__':
   #w() #寫plist黨
   r()  #解析plist黨