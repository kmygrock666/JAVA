import cv2

#圖像比對
class Match():

    def classify_gray_hist(self,image1,image2,size):
        # 先计算直方图
        # 几个参数必须用方括号括起来
        # 这里直接用灰度图计算直方图，所以是使用第一个通道，
        # 也可以进行通道分离后，得到多个通道的直方图
        # bins 取为16

        image1 = cv2.resize(image1,size)
        image2 = cv2.resize(image2,size)
        hist1 = cv2.calcHist([image1],[0],None,[256],[0.0,255.0])
        hist2 = cv2.calcHist([image2],[0],None,[256],[0.0,255.0])

        # 可以比较下直方图
        # plt.plot(range(256),hist1,'r')
        # plt.plot(range(256),hist2,'b')
        # plt.show()

        # 计算直方图的重合度
        degree = 0
        for i in range(len(hist1)):

            if hist1[i] != hist2[i]:

                degree = degree + (1 - abs(hist1[i]-hist2[i])/max(hist1[i],hist2[i]))

            else:

                degree = degree + 1

                degree = degree/len(hist1)
        return degree

# image = cv2.imread("/Users/Cheng-YU/Desktop/螢幕快照 2018-10-08 23.47.49.png")  #读取图像中獎
# m2 = image[430:680,380:705]#读取像素块
# degree = classify_gray_hist(m2,m2,size = (256,256))
# print(degree)