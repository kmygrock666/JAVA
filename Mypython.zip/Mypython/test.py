#
#
# class Auto():
#     def __init__(self):
#         print("abc")
#
#
#
# Auto();

# from selenium import webdriver
# from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
# # enable browser logging
# path = "//Users/Cheng-YU/PycharmProjects/chromedriver"
# url = "http://35.229.139.121:3001/game/rd/180709/"
# # driver = webdriver.Chrome(path)
# # driver.get(url)
#
# d = DesiredCapabilities.CHROME
# d['loggingPrefs'] = { 'browser':'ALL' }
# driver = webdriver.Chrome(desired_capabilities=d)
# # load some site
# driver.get('http://35.229.139.121:3001/game/rd/180709/')
# # print messages
# for entry in driver.get_log('browser'):
#     print(entry)
