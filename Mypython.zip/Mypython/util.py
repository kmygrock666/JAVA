# import base64
# import numpy as np
# import cv2

class Tool():
    #螢幕截圖
    def get_screenshot(driver):
        img_base64 = driver.get_screenshot_as_base64()
        img_decode = base64.b64decode(img_base64)
        img_array = np.fromstring(img_decode, np.uint8)
        img = cv2.imdecode(img_array, cv2.COLOR_BGR2GRAY)
        return img

    # 抓取 canvas base64
    def get_canvas(driver):
        #執行javascript腳本
        get_base64_script = '''
        var canvas = document.getElementsByTagName("canvas")[0];
        return canvas.toDataURL().substring(22);'''
        img_base64 = driver.execute_script(get_base64_script)
        img_decode = base64.b64decode(img_base64)
        img_array = np.fromstring(img_decode, np.uint8)
        img = cv2.imdecode(img_array, cv2.COLOR_BGR2GRAY)
        return img

    def count_adaptive_pixels(img):
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img_blur = cv2.medianBlur(img_gray, 5)
        thresh = cv2.adaptiveThreshold(img_gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        rows, _ = np.where(thresh != 255)
        return rows.shape[0]

    def predict_item_in_image(img):
        pixels = count_adaptive_pixels(img[y_range[0]:y_range[1],x_range[0]:x_range[1]])
        return pixels
        # return predict_item


    def getClippedImageFromCanvas(browser, canvas, x, y, w, h):
        # '''Get a clipped image from canvas using context.getImageData.'''
        data = browser.execute_script("\
            var canvas= arguments[0];\
            var x=arguments[1];\
            var y=arguments[2];\
            var w=arguments[3];\
            var h=arguments[4];\
            var context = canvas.getContext('webgl');\
            var dataObj= context.getImageData(x, y, w, h);\
            var data = dataObj.data;\
            return data;"
            ,canvas, x, y, w, h)
        data_bytes = array.array('B', data).tostring()
        im = Image.fromstring("RGBA", (w, h), data_bytes)
        return im