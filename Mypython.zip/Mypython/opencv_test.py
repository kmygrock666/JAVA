import cv2
from matplotlib import pyplot as plt
import numpy as np


def count_adaptive_pixels(img):
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_blur = cv2.medianBlur(img_gray, 5)
    thresh = cv2.adaptiveThreshold(img_gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    rows, _ = np.where(thresh != 255)
    return rows.shape[0]
def count_adaptive_pixels(img):
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_blur = cv2.medianBlur(img_gray, 5)
    thresh = cv2.adaptiveThreshold(img_gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    rows, _ = np.where(thresh != 255)
    return rows.shape[0]

# image = cv2.imread("/Users/Cheng-YU/Desktop/螢幕快照 2018-10-02 22.46.25.png")  #读取图像
# img = cv2.imread("/Users/Cheng-YU/Desktop/螢幕快照 2018-10-08 23.47.49.png")  #读取图像中獎
image = cv2.imread("/Users/Cheng-YU/Desktop/螢幕快照 2018-10-08 23.47.49.png")  #读取图像中獎
(b,g,r) = image[0,0]  #读取(0,0)像素，Python中图像像素是按B,G,R顺序存储的
print("位置(0,0)处的像素 - 红:%d,绿:%d,蓝:%d" %(r,g,b))#显示像素值

image[0,0] = (100,150,200)#更改位置(0,0)处的像素
m2 = image[430:680,380:705]#读取像素块
(b,g,r) = image[0,0]#再次读取(0,0)像素
print("位置(0,0)处的像素 - 红:%d,绿:%d,蓝:%d" %(r,g,b))#显示更改后的像素值

# cv2.namedWindow('Corner', cv2.WINDOW_NORMAL)
# cv2.namedWindow('Updated', cv2.WINDOW_NORMAL)
button_x = {1870,2180}
button_y = {490,750}
corner = image[490:750,1870:2180]#读取像素块
# cv2.imshow("Corner",corner)#显示读取的像素块
print(count_adaptive_pixels(corner))
# image[300:300,0:350] = (0,255,0);#更改读取的像素块

# item = count_adaptive_pixels(image[0:100,0:100])
item = count_adaptive_pixels(image)
print(item)

cv2.rectangle(image,(380,140),(700,410),(0,255,0),10)

# cv2.namedWindow('image',cv2.WINDOW_NORMAL)
# cv2.resizeWindow('image',800,600)#定义frame的大小
# cv2.imshow('image',image)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
# cv2.imshow("Updated",m2)#显示图像
# img_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
# plt.imshow(img_rgb)
# plt.show()
# cv2.waitKey(0)#程序暂停
