from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import base64
import numpy as np
import cv2
import  time
from matplotlib import pyplot as plt


class AutoTesting(object):
    def __init__(self,element,path,url):
        self.path = path
        self.url = url
        self.BrowserInit(60,element);


    def Execuse(self,x,y):
        xCanvas = 1000
        yCanvas = 300
        self.action.move_to_element_with_offset(self.canvas, xCanvas, yCanvas).click().perform()
        # 取得螢幕截圖
        # img = self.get_screenshot()
        # img = img[y[0]:y[1], x[0]:x[1]]  # 读取像素块
        # cv2.imshow('My Image', img)
        # cv2.waitKey(0)
        # pix = self.count_adaptive_pixels(img)
        # print(pix)

        while(True):
            time.sleep(10)
            img = self.get_screenshot()
            corner = img[y[0]:y[1], x[0]:x[1]]  # 读取像素块

            if(self.predict_item_in_image(corner)):
                break
            else:
                self.action.move_to_element(self.canvas).click().perform()
                # self.action.context_click(self.canvas).perform()
        print('end')

        # print(self.driver.get_log("browser"))
        # print(self.driver.get_log('driver'))
        # print(self.driver.get_log('client'))
        # print(self.driver.get_log('server'))
        # return True
        # img = self.get_screenshot()
        # img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        # item = predict_item_in_image(img)
        # img2 = catch.getClippedImageFromCanvas(driver, canvas, 0, 0, 1920, 1000)
        # 讓視窗可以自由縮放大小Ｒ
        # cv2.namedWindow('My Image', cv2.WINDOW_NORMAL)
        # 顯示圖片
        # cv2.imshow('My Image', img)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        # plt.imshow(img_rgb)
        # plt.show()

    def printMyLogs(self):
        sampleLogsArray = []

        for entry in self.driver.get_log('browser'):
            print(entry)
        sampleLogsArray.append(entry)
        return sampleLogsArray


    def BrowserInit(self,time,element):
        self.driver = webdriver.Chrome(self.path)
        self.driver.get(self.url)
        wait = WebDriverWait(self.driver,time)
        self.action = ActionChains(self.driver)

        try:
            box = wait.until(EC.presence_of_element_located((By.ID, element)))
            self.canvas = box.find_elements_by_tag_name('canvas')[0]
            print(self.driver.current_url)
            print(self.driver.title)
        except:
            print('Time out')
            self.driver.close()

    # 螢幕截圖
    def get_screenshot(self):
        img_base64 = self.driver.get_screenshot_as_base64()
        img_decode = base64.b64decode(img_base64)
        img_array = np.fromstring(img_decode, np.uint8)
        img = cv2.imdecode(img_array, cv2.COLOR_BGR2GRAY)
        return img

    # 抓取 canvas base64
    def get_canvas(self,driver):
        # 執行javascript腳本
        get_base64_script = '''
        var canvas = document.getElementsByTagName("canvas")[0];
        return canvas.toDataURL().substring(22);'''
        img_base64 = self.driver.execute_script(get_base64_script)
        img_decode = base64.b64decode(img_base64)
        img_array = np.fromstring(img_decode, np.uint8)
        img = cv2.imdecode(img_array, cv2.COLOR_BGR2GRAY)
        return img
    # 自適應國值二值化
    def count_adaptive_pixels(self,img):
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img_blur = cv2.medianBlur(img_gray, 5)
        thresh = cv2.adaptiveThreshold(img_gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        rows, _ = np.where(thresh != 255)
        return rows.shape[0]
    #判斷開始按鈕
    def predict_item_in_image(self,img):
        pixels = self.count_adaptive_pixels(img)
        print(pixels)
        if pixels >= 17000 and pixels <= 17500:
            return True;
        else:
            return False;
        # return predict_item

#瀏覽器路徑
path = "//Users/Cheng-YU/PycharmProjects/chromedriver"
#目標網址
# url = "https://h5c.cqgame.games/80/?&language=zh-cn&token=guest"
url = "http://35.229.139.121:3001/game/rd/180709/"
#按鈕位置
button_x = [2090,2265]
button_y = [1320,1410]

auto = AutoTesting('Cocos2dGameContainer',path,url)
time.sleep(20)
print(auto.printMyLogs())
n = 5
for i in range(1):
    auto.Execuse(button_x,button_y)
    print(i)
    print(auto.printMyLogs())