package com.spring.security.handel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;

import com.spring.security.UserPrinciple;
import com.spring.util.RemoveUser;

@Component
public class CustomLogoutHandler extends SimpleUrlLogoutSuccessHandler implements LogoutSuccessHandler{
	
    @Autowired
    RemoveUser session;
    
	@Override
    public void onLogoutSuccess(
      HttpServletRequest request, 
      HttpServletResponse response, 
      Authentication authentication) 
      throws IOException, ServletException {
  
//        String refererUrl = request.getHeader("Referer");
//        auditService.track("Logout from: " + refererUrl);
		HttpSession sessionId = request.getSession();
		String token = sessionId.getId();
		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		String indexName = userPrincipal.getUsername();
		System.out.println("用戶名:"+indexName);
		session.removeUser(indexName,token);
		response.sendRedirect("/login");
//        super.onLogoutSuccess(request, response, authentication);
    }
}
