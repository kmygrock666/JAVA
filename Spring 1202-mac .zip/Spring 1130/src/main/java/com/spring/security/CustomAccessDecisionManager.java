package com.spring.security;

import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Service;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CustomAccessDecisionManager implements AccessDecisionManager{
	
	/**
	 * 	判斷用戶對於此葉面是否有權限
	 *	authentication 是由 UserPrinciple 添加到 GrantedAuthority 對象中的權限
	 *	object 包含客戶端發起請求的request訊息，可轉換為 HttpServletRequest request = ((FilterInvocation) object).getHttpRequest();
	 *	configAttributes 為 CustomFilterInvocationSecurityMetadataSource 的  getAttributes(Object object) 方法返回結果，
	 *	判斷用戶請求URL 是否在權限表中，存在返回給decide方法，decide用來判斷用戶是否有此權限，如果不再權限表中則通過。
	 *	@throws AccessDeniedException 如果認證對象不具有所需的權限則拋出此異常
	 *	@throws InsufficientAuthenticationException 如果身份驗證請求因為憑據信任不足而被拒絕，則會拋出此錯誤。
	 */
	@Override
	public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes)
			throws AccessDeniedException, InsufficientAuthenticationException {
		// TODO Auto-generated method stub
//		if (null == configAttributes || configAttributes.size() <= 0) {
//            return;
//        }
		log.info("進入 decide 權限檢查------->");
        String needRole;
        for (Iterator<ConfigAttribute> iter = configAttributes.iterator(); iter.hasNext(); ) {
            ConfigAttribute c = iter.next();
            //取得訪問介面需要的权限
            needRole = c.getAttribute();
            log.info("decide 訪問需要的權限------->"+needRole);
            //authentication 为在CustomUserService中循环添加到 GrantedAuthority 对象中的权限信息集合
            for (GrantedAuthority ga : authentication.getAuthorities()) {
            	log.info("decide 用戶的權限------->"+ga.getAuthority());
                if (needRole.trim().equals(ga.getAuthority())) {
                    return;
                } else if (ga.getAuthority().equals("ROLE_ANONYMOUS")) {
                	AntPathRequestMatcher matcher = new AntPathRequestMatcher("/login");
                	HttpServletRequest request = ((FilterInvocation) object).getHttpRequest();
                	log.info("decide權限 未登入------------"+request);
                    if (matcher.matches(request)) {
                        return;
                    }
                }
                
            	
            }
            log.info("【权限管理决断器】需要role:" + needRole);
        }
        throw new AccessDeniedException("---------------------Access is denied---------------------");
	}

	@Override
	public boolean supports(ConfigAttribute attribute) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return true;
	}

}
