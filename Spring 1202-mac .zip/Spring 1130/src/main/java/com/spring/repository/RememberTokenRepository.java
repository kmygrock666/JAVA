package com.spring.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.spring.model.RememberToken;


public interface RememberTokenRepository extends JpaRepository<RememberToken, Long>{

	@Modifying
	@Query("update RememberToken r set r.token = ?1, r.last_used = ?2 where r.series = ?3")
	int updateByPK(String tokenValue, Date lastUsed, String series);
	
//	@Modifying
//	@Query(value="insert into persistent_logins(username, series, token, last_used) values(?1,?2,?3,?4)",nativeQuery = true)
//	int insert(String tokenValue, Date lastUsed, String series);
	
	RememberToken findBySeries(String Series);
//	@Modifying
//	@Query("update RememberToken r set r.token = ?1, r.last_used = ?2 where r.series = ?3")
//	RememberToken updateByPK(String tokenValue, Date lastUsed, String series);
}
