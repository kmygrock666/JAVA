package du.cfs.global.db.GM;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Unit.OrderCode;
@Service
public class GmMerchantServiceImpl implements GmMerchantService {

	@Autowired
	GmMerchantRepository repository;
	
	private static String codeMap = "vwA0xyBtFcMOd7EqrUGkIfgRJKjChlmSunH2PoL6eTY4i3zWXDZQbNVa5p";
	private static String codeKey = "s";
	
	public GmMerchant getMerchant(String merCode) {
		int idx = OrderCode.StringCodeToInt(codeMap, codeKey, merCode);
		Optional<GmMerchant> optional = repository.findById(idx);
		if (optional.isPresent()) {
			if(optional.get().getMerCode().equals(merCode))
				return optional.get();
		}
		return null;
	}

	
	@Override
	public GmMerchant update(GmMerchant merConfig) {
		return repository.save(merConfig);
	}

	@Override
	public GmMerchant create(GmMerchant merConfig) {
		merConfig = repository.save(merConfig);
		String merCode = OrderCode.IntToCodeString(codeMap, codeKey, (int) merConfig.getId(), 20);
		merConfig.setMerCode(merCode);
		return repository.save(merConfig);
	}
}
