package du.cfs.security.handel;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import du.cfs.common.util.AjaxUtils;
import du.cfs.common.util.JsonUtils;
import du.cfs.security.CustomAccessDecisionManager;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomAccessDeniedHandler implements AccessDeniedHandler{

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		// TODO Auto-generated method stub
		
//		  	StringBuffer msg = new StringBuffer("请求: ");
//          msg.append(request.getRequestURI()).append(" 权限不足，无法访问系统资源.");
//          response.sendError(403, msg.toString());
//          response.sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
//          response.sendError(HttpStatus.FORBIDDEN.value(), accessDeniedException.getMessage());
//          response.sendRedirect(request.getContextPath());
//          System.out.println(request.getContextPath());
//          System.out.println(HttpStatus.FORBIDDEN.value());
//          System.out.println(HttpStatus.FORBIDDEN.getReasonPhrase());
//		  Authentication auth  = SecurityContextHolder.getContext().getAuthentication();
//		  if (auth != null) {
//		      log.warn("User: " + auth.getName() + " attempted to access the protected URL: " + request.getRequestURI());
//		  }
		  
			if (AjaxUtils.isAjax(request) || AjaxUtils.isApi(request) || AjaxUtils.isApiRoute(request)) {
	            Map<String, Object> map = new HashMap<>();
	            map.put("success", false);
	            map.put("error", accessDeniedException.getMessage());
	
	            response.setStatus(HttpStatus.FORBIDDEN.value());
	            response.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
	            response.getWriter().write(JsonUtils.toJson(map));
	            response.getWriter().flush();
	        } else {
	        	response.sendRedirect(request.getContextPath() + "/login");
	        }
//			傳key-valueue json
//		    ObjectMapper mapper = new ObjectMapper();
//		    ObjectNode objNode1 = mapper.createObjectNode();
//		    objNode1.put("error", "403");
//		    
//		    
//		    response.setStatus(HttpServletResponse.SC_OK);
//		    response.getWriter().write(objNode1.toString());
//		    response.getWriter().flush();
//		    response.getWriter().close();
		
	}

}
