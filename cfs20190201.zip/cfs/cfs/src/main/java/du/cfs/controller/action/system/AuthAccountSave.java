package du.cfs.controller.action.system;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;


import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;

public class AuthAccountSave extends BaseAction{
	

	
	@Autowired
	AccountService accountService;
	
	@Autowired
	RoleService roleService;
	

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		
		String username =  getParam("username");
		String nickname =  getParam("nickname");
		String password =  getParam("password");
		String status =  getParam("status");
		String[] rolesId =  getParam("roles[]");

		Account account = accountService.findByUsername(username);
		
		Set<Role> foo = new HashSet<>();
		if(rolesId != null) {
			List<Long> ids = Arrays.asList(rolesId).stream().map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());
			List<Role> roles = roleService.findByIdIn(ids);
			foo = new HashSet<Role>(roles);
		}
		
		
		if(account == null)
			account = new Account();
		account.setUsername(username);
		account.setNickname(nickname);
		account.setPassword(password);
		account.setStatus(Boolean.parseBoolean(status));
		account.setRoles(foo);
		accountService.save(account);
	
		
		System.out.println("Save Success");
		return redirect("/system/AuthAccount");
	}
	
}
