package du.cfs.api.action.text;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import du.cfs.global.Unit.IpUtil;
import du.cfs.security.AdmUserPrinciple;

@Component
public abstract class ApiBaseAction{
	
	private HttpServletRequest request;
	ThreadLocal<Long> startTime = new ThreadLocal<>();
	protected abstract ResultVO execute(); 

	/**
	 * get params
	 * @param data
	 */
	public void init(Map<String,Object> data) {
		startTime.set(System.currentTimeMillis());
		request = (HttpServletRequest) data.get("request");
	}
	
	public AdmUserPrinciple getUserInfo() {
		return (AdmUserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	}
	
	//TODO
	public ResponseEntity<?> returnJson() {
		return ResponseEntity.ok().body("success");
	}
	
	public  <T> T getParam(String key) {
		String[] param = request.getParameterValues(key);
		if(param == null || param.length == 1) {
//			System.out.println(key+ " param null=> " +request.getParameter(key));
			return (T) request.getParameter(key);
		}

		return (T) param;

	}
	
//	public void initSetting() {
//		model.addAttribute("exeTime", System.currentTimeMillis()-startTime.get());
//		model.addAttribute("nowTime", System.currentTimeMillis());
//		model.addAttribute("IP", IpUtil.getIpAddr(request));
//	}
	
	
	
	

}
