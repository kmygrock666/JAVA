package du.cfs.controller.action.system;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;
import du.cfs.controller.action.system.vo.AuthRoleVO;

public class AuthRole extends BaseAction{
	
	@Autowired
	RoleService roleService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		List<Role> roles = roleService.findAll();
		List<AuthRoleVO> authRoleVOList = roles.stream().map(item->{
			AuthRoleVO authRoleVO = new AuthRoleVO();
			BeanUtils.copyProperties(item, authRoleVO);
			authRoleVO.setName(StringUtils.substringAfter(authRoleVO.getName(), "_"));
            return authRoleVO;
		}).collect(Collectors.toList());
		
		assign("roleList",authRoleVOList);
		System.out.println(JSON.toJSONString(authRoleVOList,true));
//		System.out.println(roles.size());
		return getView("authRole");
		

	}
	
}
