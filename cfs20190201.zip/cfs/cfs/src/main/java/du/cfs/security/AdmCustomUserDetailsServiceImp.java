package du.cfs.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Profile("dev")
public class AdmCustomUserDetailsServiceImp implements UserDetailsService {
 
    @Autowired
    AccountService accountService;
    
    @Override
    @Transactional
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        Account user = accountService.findOptionalByUsername(username)
                	.orElseThrow(() -> 
                        new UsernameNotFoundException("User Not Found with -> username or email : " + username)
        );
        
        user.getRoles();
        log.info("come in UserDetailsService");
        
        return AdmUserPrinciple.build(user);
    }
}
