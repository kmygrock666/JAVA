package du.cfs.common.enums;

import lombok.Getter;

@Getter
public enum ResultEnum {
	SUCCESS(0, "success"),
	ERROR(1,"failure"),
	PARAM_VERIFY_FALL(3, "Param verification error"),
	DATA_NOT(5, "Not data"),
	;
	
	private Integer code;
	
	private String message;
	
	ResultEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
}
