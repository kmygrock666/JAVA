package du.cfs.controller.action.system;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;
import du.cfs.controller.action.BaseCore;
import du.cfs.controller.action.system.vo.AuthAccountVO;
import du.cfs.controller.action.system.vo.AuthRoleVO;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;
import du.cfs.security.AdmUserPrinciple;


public class AuthAccount extends BaseAction{
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	RoleService roleService;
	
	@Override
	public String execute() {
		
//		AdmUserPrinciple userInfo = getUserInfo();
		List<Account> accounts = accountService.findAll();
		List<AuthAccountVO> authAccountVOs = accounts.stream().map(item->{
			AuthAccountVO authAccountVO = new AuthAccountVO();
			BeanUtils.copyProperties(item, authAccountVO);
			
			List<String> authRoleVOList = item.getRoles().stream().map(role->{
	            return String.valueOf(role.getId());
			}).collect(Collectors.toList());
			
			authAccountVO.setRoles(authRoleVOList);
			return authAccountVO;
		}).collect(Collectors.toList());
		
		List<Role> roles = roleService.findAll();

		Map<Long, String> roleList = roles.stream().collect(Collectors.toMap(Role::getId, Role::getDescription));
		
		
//		List<Object> roleList = roles.stream().map(r->{
//		Map<String, String> key = new HashMap<>();
//		key.put("id", String.valueOf(r.getId()));
//		key.put("title", r.getDescription());
//		return key;
//	}).collect(Collectors.toList());
		System.out.println("-------------in Account Class-------------");
		assign("account", authAccountVOs);
		assign("roleList", roleList);
		System.out.println(JSON.toJSONString(authAccountVOs,true));
//		System.out.println("-------------使用者名稱-------------"+userInfo.getUsername());
//		System.out.println("-------------使用者暱稱-------------"+userInfo.getName());
//		System.out.println("-------------使用者權限-------------"+userInfo.getAuthorities().toString());
		return getView("authAccount");
	}
}
