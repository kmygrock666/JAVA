package du.cfs.global.db.GM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "apiIp", "apiPort" }) })
public class GmKern {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	@Column(nullable = false)
	private String md5Key;
	private String rsaKey;
	private String apiIp;
	private String apiPort;

}