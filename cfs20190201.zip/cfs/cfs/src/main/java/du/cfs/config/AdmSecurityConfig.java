package du.cfs.config;

import javax.servlet.Filter;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

import du.cfs.security.AdmCustomAuthenticationProvider;
import du.cfs.security.CustomFilterSecurityInterceptor;
import du.cfs.security.AdmCustomUserDetailsServiceImp;
import du.cfs.security.PersistentTokenService;
import du.cfs.security.handel.CustomAccessDeniedHandler;
import du.cfs.security.handel.CustomLogoutSuccessHandler;
import du.cfs.security.handel.CustomizeAuthenticationSuccessHandler;
import du.cfs.security.handel.JwtAuthEntryPoint;
import du.cfs.security.jwt.AdmCustomAuthTokenFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true) 
@Profile("dev")
public class AdmSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private AdmCustomUserDetailsServiceImp customUserDetailsServiceImp;
	
	@Autowired
	private AdmCustomAuthenticationProvider provider;
	
	@Autowired
    private CustomFilterSecurityInterceptor customFilterSecurityInterceptor;
	
	@Autowired
	private PersistentTokenService persistentTokenService;
	
    @Autowired
    private CustomAccessDeniedHandler myAccessDeniedHandler;
    
    @Autowired
    private JwtAuthEntryPoint unauthorizedHandler;
    
    @Autowired
    private CustomizeAuthenticationSuccessHandler customizeAuthenticationSuccessHandler;
    
    @Autowired
    private CustomLogoutSuccessHandler customLogoutSuccessHandler;
    
	@Autowired
	SystemConfig conf;
	
    @Autowired
    private DataSource dataSource;
 
	@Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
//        authenticationManagerBuilder
//                .userDetailsService(customUserDetailsServiceImpl)
//                .passwordEncoder(bCryptPasswordEncoder());   //使用BCrypt進行密碼的hash
		authenticationManagerBuilder.authenticationProvider(provider);
    }
	
    @Bean
    public AdmCustomAuthTokenFilter authenticationJwtTokenFilter() {
        return new AdmCustomAuthTokenFilter();
    }
	
	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}
 
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
    
    @Override
    public void configure(WebSecurity web) throws Exception {
    	//允许所有用户访问
    	web.ignoring().antMatchers("/custom/**","/bootstraps/**","/favicon.ico");
        web.ignoring().antMatchers("/api/signin");
        web.ignoring().antMatchers("/signing");
        web.ignoring().antMatchers("/api/**");
        web.ignoring().antMatchers("/ap/**");

    }
   
	@Override
    protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().ignoringAntMatchers("/api/*");  // Api use token authentication.
		
		http
	    	.exceptionHandling()
	    		//認證過的用戶，存取被拒時，拋出異常
	    		.accessDeniedHandler(myAccessDeniedHandler) 
	    		//當前用戶請求資源，但是未通過認證，拋出異常
                .authenticationEntryPoint(unauthorizedHandler)
			.and()
				.authorizeRequests() //表示以下都是授权的配置 
//		        .antMatchers("/cm/**").hasAuthority("USER")
		        .antMatchers("/login","/error").permitAll()
		        .anyRequest().authenticated() //其他请求需要登录认证
		    .and()
		        .formLogin()
		        .loginPage("/login")
		        .failureUrl("/login?error=true")
//		        .failureForwardUrl("/login/error")
		        .successHandler(customizeAuthenticationSuccessHandler)
		    .and()
		    	.logout()
		    	.logoutSuccessUrl("/login")
		    	.addLogoutHandler(customLogoutSuccessHandler)
		    	.deleteCookies("JSESSIONID")//删除当前的JSESSIONID
		    	.permitAll()
		    .and()
			    .rememberMe()
			    .rememberMeParameter(conf.getCookies())
			    .key("remember-me")
			    .rememberMeServices(persistentTokenBasedRememberMeServices())
	            .tokenValiditySeconds(60*60)
//	            .rememberMeCookieName(conf.getCookies())
//	        .and()
		    	// don't create session
//            	.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		    .and()
		    	.csrf().disable();// 禁用跨站攻击
//		http.sessionManagement().maximumSessions(1).maxSessionsPreventsLogin(false).expiredUrl("/login")
//		.sessionRegistry(sessionRegistry());
		http.addFilterBefore((Filter) authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
//		http.addFilterAfter(customFilterSecurityInterceptor, FilterSecurityInterceptor.class);
//		http.addFilterBefore(customFilterSecurityInterceptor, FilterSecurityInterceptor.class);
//		http.addFilterBefore(myGenericFilterBean, UsernamePasswordAuthenticationFilter.class);

	}
	
	public PersistentTokenRepository persistentTokenRepository(){
	     JdbcTokenRepositoryImpl tokenRepositoryImpl = new JdbcTokenRepositoryImpl();
	     tokenRepositoryImpl.setDataSource(dataSource);
	     return tokenRepositoryImpl;
	}
	
	@Bean
	public PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices() {
		PersistentTokenBasedRememberMeServices persistenceTokenBasedservice = new PersistentTokenBasedRememberMeServices(
				"remember-me", customUserDetailsServiceImp, persistentTokenService);
		persistenceTokenBasedservice.setCookieName(conf.getCookies());
		return persistenceTokenBasedservice;
	}

	@Bean
	public SessionRegistry sessionRegistry() {
	    return new SessionRegistryImpl();
	}
	//============語系設定
	@Bean
    public LocaleResolver localeResolver() {
        CookieLocaleResolver slr = new CookieLocaleResolver();
        slr.setCookieMaxAge(3600);
        slr.setCookieName("Language");//设置存储的Cookie的name为Language
        return slr;
    }
	 
//	@Bean
//    public LocaleChangeInterceptor localeChangeInterceptor() {
//        LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
//        // 自訂参数名
//        lci.setParamName("lang");
//        return lci;
//    }
	 
    @Bean
    public WebMvcConfigurer webMvcConfigurer() {
        return new WebMvcConfigurer() {
            //拦截器
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(new LocaleChangeInterceptor()).addPathPatterns("/**");
            }
        };
    }
    
    
}
