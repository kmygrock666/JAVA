package du.cfs.global.db.GM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;

import lombok.Data;

@Data
@Entity
public class GmMerchant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(length = 50)
	private String merCode;
	//@Column(length = 50, updatable = false, nullable = false)
	//private String md5Key;
	
	// private int totalAmount;
	private int sttledAmount;
    
	private Boolean agentPayLock;
    
    @ManyToOne
    GmKern gmKern;

	@PrePersist
	void createdAt() {
		agentPayLock = false;
	}
}
