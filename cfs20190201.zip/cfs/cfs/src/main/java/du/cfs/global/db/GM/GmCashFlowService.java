package du.cfs.global.db.GM;

import java.util.List;

import du.cfs.global.Gen.Struce_Input_AgentPayFeedback;
import du.cfs.global.Gen.Struce_Response_AgentPay;
import du.cfs.global.Gen.cfsEnum.ServiceType;
import du.cfs.global.Gen.cfsEnum.SttleStatus;

public interface GmCashFlowService {
	GmCashFlow GetGmCashFlow(int id);

	List<GmCashFlow> GetAllGmCashFlow();

	GmCashFlow update(GmCashFlow gmCashFlow);

	GmCashFlow create(GmCashFlow gmCashFlow);

	List<GmCashFlow> IdGreaterThan(int id);

	public int lestUnDoneId();

	List<GmCashFlow> findBymer_merCodeAndServiceTypeAndSttleStatus(String merCode, ServiceType serviceType, SttleStatus sttleStatus);

	GmCashFlow TransactionalSuccess(GmGate gmGate, GmMerchant gmMerchant, Struce_Response_AgentPay input_AgentPay);

	GmCashFlow TransactionalFail(GmGate gmGate, GmMerchant gmMerchant, Struce_Response_AgentPay input_AgentPay);

	GmCashFlow TransactionalFail(GmGate gmGate, GmMerchant gmMerchant, Struce_Input_AgentPayFeedback input_AgentPay);
}
