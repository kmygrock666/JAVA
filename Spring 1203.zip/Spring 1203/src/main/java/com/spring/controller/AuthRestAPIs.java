package com.spring.controller;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.exception.InvalidRequestException;
import com.spring.exception.NotFoundException;
import com.spring.model.Role;
import com.spring.repository.CommerceRepository;
import com.spring.repository.RoleRepository;

import com.spring.security.UserPrinciple;
import com.spring.security.jwt.JwtProvider;
import com.spring.security.request.LoginForm;
import com.spring.security.request.SignUpForm;
import com.spring.security.response.JwtResponse;
import com.spring.util.RemoveUser;



@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class AuthRestAPIs {

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    CommerceRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    PasswordEncoder encoder;
    
    @Autowired
    JwtProvider jwtProvider;
    
    @Autowired
    RemoveUser session;
    
    /**
     * 身分驗證
     * @param loginRequest
     * @param bindingResult
     * @return
     */
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginForm loginRequest,BindingResult bindingResult) {
    	//驗證用戶帳密
    	if(bindingResult.hasErrors()) {
    		System.out.println(bindingResult);
    		throw new InvalidRequestException("Invliad parameter ",bindingResult);
    	}
    	System.out.println("api 進入登入程序");
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );
        System.out.println("api 登入成功");
        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtProvider.generateJwtToken(authentication);
        return ResponseEntity.ok(new JwtResponse(jwt));
    }
    
    @PostMapping("/{sub}/{action}")
    public ResponseEntity<?> test(@PathVariable String sub,	
    								@PathVariable() String action,
    								HttpServletRequest request, 
    								HttpServletResponse response) {
    	//驗證用戶帳密
    	if(sub.equals("") || action.equals("")) {
    		System.out.println("找不到檔案comin null---------");
    		throw new NotFoundException(String.format("It params is %s and &s not found",sub,action ));
    	}
    	HttpSession sessionId = request.getSession();
		String token = sessionId.getId();
    	try {
			//實體class
			 Class model = Class.forName("com.spring.api.action." + sub + "." + action);
			 Object classObj = model.newInstance();
			 //產生method，並呼叫
			 Method setInfo = model.getMethod("execute", new Class[]{"".getClass(),"".getClass()});
			 Object getReturn = setInfo.invoke(classObj, new Object[]{token,token} );
			 //移除用戶session
			 String indexName = ((UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();

			 
			 session.removeFrontUser(indexName,token);
			 return (ResponseEntity<?>) getReturn;
		} catch( ClassNotFoundException e ) {
			//my class isn't there!
			System.out.println("找不到檔案---------");
			throw new NotFoundException("找不到檔案 : "+e.getMessage());
			
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			throw new NotFoundException("Init errors A: "+e.getMessage());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			throw new NotFoundException("Init errors B: "+e.getMessage());
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			throw new NotFoundException("Init errors C: "+e.getMessage());
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			throw new NotFoundException("Init errors D: "+e.getMessage());
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			throw new NotFoundException("Init errors E: "+e.getMessage());
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			throw new NotFoundException("Init errors F: "+e.getMessage());
		}
    	
//    	return new ResponseEntity<Object>(true,HttpStatus.OK);
    }

//    @PostMapping("/signup")
//    public ResponseEntity<String> registerUser(@Valid @RequestBody SignUpForm signUpRequest) {
//        if(userRepository.existsByUsername(signUpRequest.getUsername())) {
//            return new ResponseEntity<String>("Fail -> Username is already taken!",
//                    HttpStatus.BAD_REQUEST);
//        }
//
//        if(userRepository.existsByEmail(signUpRequest.getEmail())) {
//            return new ResponseEntity<String>("Fail -> Email is already in use!",
//                    HttpStatus.BAD_REQUEST);
//        }
//
//        // Creating user's account
//        User user = new User(signUpRequest.getName(), signUpRequest.getUsername(),
//                signUpRequest.getEmail(), encoder.encode(signUpRequest.getPassword()));
//
//        Set<String> strRoles = signUpRequest.getRole();
//        Set<Role> roles = new HashSet<>();
//
//        strRoles.forEach(role -> {
//        	switch(role) {
//	    		case "admin":
//	    			Role adminRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
//	                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
//	    			roles.add(adminRole);
//	    			
//	    			break;
//	    		case "pm":
//	            	Role pmRole = roleRepository.findByName(RoleName.ROLE_PM)
//	                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
//	            	roles.add(pmRole);
//	            	
//	    			break;
//	    		default:
//	        		Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
//	                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
//	        		roles.add(userRole);        			
//        	}
//        });
//        
//        user.setRoles(roles);
//        userRepository.save(user);
//
//        return ResponseEntity.ok().body("User registered successfully!");
//    }
}