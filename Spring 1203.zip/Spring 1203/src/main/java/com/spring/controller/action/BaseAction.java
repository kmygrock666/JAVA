package com.spring.controller.action;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

import com.spring.security.UserPrinciple;

import lombok.Data;

@Data
@Controller
public abstract class BaseAction {
	
	
	
	public UserPrinciple getUserInfo() {
		return (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	}
	
	public String getView(String path) {

		return path;
	}

}
