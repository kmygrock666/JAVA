package com.spring.config;

import javax.servlet.Filter;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;


import com.spring.security.CustomAuthTokenFilter;
import com.spring.security.CustomAuthenticationProvider;
import com.spring.security.CustomFilterSecurityInterceptor;
import com.spring.security.CustomUserDetailsServiceImpl;

import com.spring.security.PersistentTokenService;
import com.spring.security.handel.CustomAccessDeniedHandler;
import com.spring.security.handel.CustomLogoutHandler;
import com.spring.security.handel.CustomizeAuthenticationSuccessHandler;
import com.spring.security.handel.JwtAuthEntryPoint;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true) 
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private CustomUserDetailsServiceImpl customUserDetailsServiceImpl;
	
	@Autowired
	private CustomAuthenticationProvider provider;
	
	@Autowired
    private CustomFilterSecurityInterceptor customFilterSecurityInterceptor;
	
	@Autowired
	private PersistentTokenService persistentTokenService;
	
    @Autowired
    private CustomAccessDeniedHandler myAccessDeniedHandler;
    
    @Autowired
    private JwtAuthEntryPoint unauthorizedHandler;
    
    @Autowired
    private CustomizeAuthenticationSuccessHandler customizeAuthenticationSuccessHandler;
    
    @Autowired
    private CustomLogoutHandler customLogoutHandler;
    
	@Autowired
	SysConfig conf;
	
    @Autowired
    private DataSource dataSource;
 
	@Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
//        authenticationManagerBuilder
//                .userDetailsService(customUserDetailsServiceImpl)
//                .passwordEncoder(bCryptPasswordEncoder());   //使用BCrypt進行密碼的hash
		authenticationManagerBuilder.authenticationProvider(provider);
    }
	
    @Bean
    public CustomAuthTokenFilter authenticationJwtTokenFilter() {
        return new CustomAuthTokenFilter();
    }
	
	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}
 
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
   
	@Override
    protected void configure(HttpSecurity http) throws Exception {
		http.csrf().ignoringAntMatchers("/api/*");  // Api use token authentication.
		
		http
	    	.exceptionHandling()
	    		//存取被拒時，拋出異常
	    		.accessDeniedHandler(myAccessDeniedHandler) 
	    		//當前用戶請求資源，但是未通過認證，拋出異常
                .authenticationEntryPoint(unauthorizedHandler)
			.and()
				.authorizeRequests() //表示以下都是授权的配置 
//		        .antMatchers("/cm/**").hasAuthority("USER")
//		        .antMatchers("/api/*").permitAll()
		        .anyRequest().authenticated() //其他请求需要登录认证
		    .and()
		        .formLogin()
		        .loginPage("/login")
//		        .defaultSuccessUrl("/cm/index",true)
		        .successHandler(customizeAuthenticationSuccessHandler)
//		        .failureUrl("/login?error").permitAll()
//		        .permitAll()
		    .and()
		    	.logout()
		    	.logoutSuccessUrl("/login")
//		    	.logoutSuccessHandler(customLogoutHandler)
		    	
		    	.deleteCookies("JSESSIONID")//删除当前的JSESSIONID
		    	.permitAll()
		    .and()
			    .rememberMe()
			    .rememberMeParameter(conf.getCookies())
			    .key("remember-me")
//			    .alwaysRemember(true)
//			    .tokenRepository(persistentTokenRepository())
//			    .userDetailsService(customUserDetailsServiceImpl)
			    .rememberMeServices(persistentTokenBasedRememberMeServices())
	            .tokenValiditySeconds(60*60)
//	            .rememberMeCookieName(conf.getCookies())
//	        .and()
		    	// don't create session
//            	.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		    .and()
		    	.csrf().disable();// 禁用跨站攻击
//		http.sessionManagement().maximumSessions(1).maxSessionsPreventsLogin(false).expiredUrl("/login")
//		.sessionRegistry(sessionRegistry());
		http.addFilterBefore((Filter) authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
		http.addFilterBefore(customFilterSecurityInterceptor, FilterSecurityInterceptor.class);
//		http.addFilterBefore(myGenericFilterBean, UsernamePasswordAuthenticationFilter.class);

	}
	
	public PersistentTokenRepository persistentTokenRepository(){
	     JdbcTokenRepositoryImpl tokenRepositoryImpl = new JdbcTokenRepositoryImpl();
	     tokenRepositoryImpl.setDataSource(dataSource);
	     return tokenRepositoryImpl;
	}
	
	@Bean
	public PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices() {
		PersistentTokenBasedRememberMeServices persistenceTokenBasedservice = new PersistentTokenBasedRememberMeServices(
				"remember-me", customUserDetailsServiceImpl, persistentTokenService);
		persistenceTokenBasedservice.setCookieName(conf.getCookies());
//		persistenceTokenBasedservice.setParameter(conf.getCookies());
//		persistenceTokenBasedservice.setTokenValiditySeconds(60*60);
		return persistenceTokenBasedservice;
	}
	
	@Bean
	public SessionRegistry sessionRegistry() {
	    return new SessionRegistryImpl();
	}
	
    @Override
    public void configure(WebSecurity web) throws Exception {
    	//允许所有用户访问
//        web.ignoring().antMatchers("/bootstraps/css/**");
//        web.ignoring().antMatchers("/bootstraps/js/**");
        web.ignoring().antMatchers("/bootstraps/**");
        web.ignoring().antMatchers("/custom/**");
        web.ignoring().antMatchers("/favicon.ico");
        web.ignoring().antMatchers("/api/signin");
//        web.ignoring().antMatchers("/manager/delete/**");
//        web.ignoring().antMatchers("/");
    }
	
}
