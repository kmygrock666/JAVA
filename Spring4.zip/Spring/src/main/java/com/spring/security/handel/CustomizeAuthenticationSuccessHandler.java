package com.spring.security.handel;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.spring.config.SysConfig;
import com.spring.security.UserPrinciple;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomizeAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler  {
	
	@Autowired
    private RedisTemplate redisTemplate;
	
	@Autowired
	SysConfig conf;
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		// TODO Auto-generated method stub
//		Cookie[] cookies = request.getCookies();
//    	String token = "";
//
//    	for(Cookie cookiel : cookies){
//    		System.out.println("cookies 的 key 為 "+cookiel.getName()+"  值為 "+cookiel.getValue());
//    		if(cookiel.getName().equals(conf.getCookies())) {
//    			token = cookiel.getValue();
//    			break;
//    		}
//        }
    	
    	
//		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//		
//		Map<String,Object> testMap = new HashMap();
//        testMap.put("account",userPrincipal.getUsername());
//        testMap.put("username",userPrincipal.getName());
//        testMap.put("role",userPrincipal.getRole().toString());
//        redisTemplate.opsForHash().putAll("user:"+token,testMap);
//		log.info("登入成功------------------------- "+token);
		response.sendRedirect("/cm/index");
	}

}
