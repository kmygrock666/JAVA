package com.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.entity.book;

public interface BookRepository  extends JpaRepository<book, Long>{
	book findByid(int id);
}
