package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.demo.entity.book;
import com.demo.repository.BookRepository;
import com.demo.service.bookService;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class BookController {
	
	@Autowired
	bookService BooksService;
	/**
	 * 獲取書單列表
	 * @param model
	 * @return
	 */
	@GetMapping("/books")
	public String list(Model model) {
		List<book> Books = BooksService.findAll();
		model.addAttribute("books",Books);
		
		return "books2";
	}
	/**
	 * 獲取書單詳情
	 * @param id
	 * @param model
	 * @return
	 */
	@GetMapping("/books/{id}")
	public String detail(@PathVariable int id,Model model) {
		System.out.println("aaaaaaaaaaaa");
		book Book = BooksService.findOne(id);
		if (Book == null) {
			 Book = new book();
			
		}
		log.info("aaa");
		model.addAttribute("book",Book);
		return "books";
	}
	/*
	 * input提交頁面
	 */
	@GetMapping("/books/inpute")
	public String inputPage(Model model) {
		book Book = new book();
		model.addAttribute(Book);
		return "input";
	}
	/**
	 * 跳轉到更新頁面
	 * @param id
	 * @param model
	 * @return
	 */
	@GetMapping("/books/{id}/input")
	public String inputEditPage(@PathVariable int id,Model model) {
		book Book = BooksService.findOne(id);
		model.addAttribute("book",Book);
		return "input";
	}
	/**
	 * 提交一個書單
	 * @param Book
	 * @return
	 */
	@PostMapping("/books")
	public String post(book Book) {
		BooksService.save(Book);
		return "redirect:/books";
	}
	
}
