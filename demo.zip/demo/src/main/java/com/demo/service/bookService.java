package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.book;
import com.demo.repository.BookRepository;

@Service
public class bookService {
	@Autowired
	BookRepository bookRepository;
	
	public book findOne(int id) {
		return bookRepository.findByid(id);
		
	}
	
	public List<book> findAll(){
		return bookRepository.findAll();
	}

	public book save(book book) {
		// TODO Auto-generated method stub
		return bookRepository.save(book);
	}
}
