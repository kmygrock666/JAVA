package com.demo;

import java.sql.Date;
import java.time.LocalDateTime;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import com.demo.DemoApplication;
import com.demo.entity.user;
import com.demo.repository.userRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DemoApplication.class)
public class JpaTest {
	
	@Autowired
	private userRepository userRepositorys; 
	
	@Autowired
	private BCryptPasswordEncoder passwordEncode;
	
	@Test
	public void save() {
		user info = new user();
		info.setAccount("ian");
		info.setPassword(passwordEncode.encode("123"));
		info.setCreate_at(LocalDateTime.now());
		System.out.println(userRepositorys.save(info));
		System.out.println("SUCCESS");
	}
}
