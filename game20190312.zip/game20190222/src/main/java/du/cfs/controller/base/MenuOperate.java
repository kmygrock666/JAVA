package du.cfs.controller.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.common.util.PermissionRuleTreeUtils;
import du.cfs.controller.system.action.vo.AuthRolePermissionVO;
import du.cfs.security.AdmUserPrinciple;

@Component
public class MenuOperate {
	
	@Autowired
    private RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	private List<AuthRolePermissionVO> menus = null;
	
	public List<AuthRolePermissionVO> getMenu(AdmUserPrinciple userinfo) {
			
			if(menus == null) {
				System.out.println("===========get menus=============");	
				List<String> roles = userinfo.getRole();
				Set<Long> keys = new HashSet<Long>();
				for(String r : roles) {
					Role role = roleService.findByName(r);
					List<Permission> permissions = role.getPermissions();
					List<Long> checkedKeys  = permissions.stream().map(Permission::getId).collect(Collectors.toList());
					keys.addAll(checkedKeys);
				}
				
				List<Permission> permissions = permissionService.findAll();
				menus = PermissionRuleTreeUtils.merge(permissions,0L,keys);
	
				Iterator<AuthRolePermissionVO> m = menus.iterator();
			    while (m.hasNext()){
			    	AuthRolePermissionVO next = m.next();
	
			    	if(next.getChildren().size() <= 0 || !next.getIsShow()) {
			    		m.remove();
			    	}else {
			    		Iterator<AuthRolePermissionVO> sub = next.getChildren().iterator();
			    		while (sub.hasNext()) {
				    		AuthRolePermissionVO nextSub = sub.next();
				    		if(!nextSub.getIsShow() || !keys.contains(nextSub.getId())) sub.remove();
				    		System.out.println(nextSub.getId());
						}
			    		if(next.getChildren().size() <= 0 ) m.remove();
			    	}
			    	
			    }
//		    	System.out.println(JSON.toJSONString(keys,true));

			}

		return menus;
	}

	public Map<String,String> getMainTitle(String dir,String action,AdmUserPrinciple userinfo) {
		Map<String,String> pathDetial = new HashMap<>();
		if(menus == null) menus = getMenu(userinfo);
		Iterator<AuthRolePermissionVO> m = menus.iterator();
	    while (m.hasNext()){
	    	AuthRolePermissionVO next = m.next();    	
	    	if(next.getPermission().equals(dir)) {
	    		pathDetial.put("dir", next.getTitle());
	    		Iterator<AuthRolePermissionVO> sub = next.getChildren().iterator();
	    		while (sub.hasNext()) {
		    		AuthRolePermissionVO nextSub = sub.next();
		    		if(nextSub.getPermission().equals(action)) {
		    			pathDetial.put("sub", nextSub.getTitle());
		    			break;
		    		}
				}
	    		break;
	    	}
	    }

		return pathDetial;
	}
	
	public void clearMenu() {
		menus = null;
	}
}
