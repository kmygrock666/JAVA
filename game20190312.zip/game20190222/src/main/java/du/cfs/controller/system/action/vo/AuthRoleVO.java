package du.cfs.controller.system.action.vo;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;

import lombok.Data;

@Data
public class AuthRoleVO {
	private long id;
	private String name;
	private String description;
	private Date  createdAt;
}
