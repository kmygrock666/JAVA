package du.cfs.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import du.cfs.config.exception.NotFoundException;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;


import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping
public class Auth {
	
	@Autowired
	AccountService accountService;
	
	/**
	 * 登入介面
	 * @return
	 */
	@GetMapping("/login")
	public String login() {
		if (SecurityContextHolder.getContext().getAuthentication().getPrincipal().equals("anonymousUser")) {
			return "login";
		}
		return "redirect:/cm";
	}
	
	@GetMapping("/logout")
	public String logout() {
		
		System.out.println("Core-Logout");
//		int rq = commerceService.updateInfo("123", 1, "1", 6);
//		System.out.println(rq);
		return "login";
	}
	
	@GetMapping("/")
	public String redirect() {
		return "redirect:/cm";
	}
	
	@GetMapping("/403")
	public String error() {
		return "error/403";
	}
	
	@PostMapping("/403")
	public String postError() {
		return "error/403";
	}
	
	@GetMapping("signing")
	public String sign() {
		Account user = new Account();
		user.setUsername("rdian");
		user.setPassword("123");
		accountService.save(user);
		log.info("success");
		return "login";
	}
	
	@RequestMapping("/login/error")
    public void loginError(HttpServletRequest request, HttpServletResponse response) {
		log.info("loginError");
        response.setContentType("text/html;charset=utf-8");
        AuthenticationException exception =
                (AuthenticationException)request.getSession().getAttribute("SPRING_SECURITY_LAST_EXCEPTION");
        try {
            response.getWriter().write(exception.toString());
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
	
//	@GetMapping("/")
//	@PreAuthorize("hasRole('ROLE_USER')")
//	public String index(HttpSession session) {
//		System.out.println("SESSION ID: ==>"+session.getId());
//		System.out.println("SESSION ID: ==>"+session.getServletContext());
//		return "index";
//	}
	@GetMapping("/te")
	public String Index() {
		System.out.println("aaaaa");
		throw new NotFoundException("密碼錯誤");
	}
}
