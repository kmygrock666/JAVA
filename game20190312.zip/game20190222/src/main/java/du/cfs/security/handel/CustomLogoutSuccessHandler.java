package du.cfs.security.handel;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.stereotype.Component;

import du.cfs.common.util.UserOperate;
import du.cfs.controller.base.MenuOperate;
import du.cfs.security.AdmUserPrinciple;

@Component
public class CustomLogoutSuccessHandler implements LogoutHandler {
	
    @Autowired
    UserOperate session;
    
    @Autowired
    MenuOperate menuOperate;
    
	@Override
	public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
		// TODO Auto-generated method stub
		HttpSession sessionId = request.getSession();
		String token = sessionId.getId();
		if(SecurityContextHolder.getContext().getAuthentication() == null) {
			return;
		}
		
		AdmUserPrinciple userPrincipal = (AdmUserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		menuOperate.clearMenu();
		String indexName = userPrincipal.getUsername();
//		System.out.println("用戶名:"+indexName);
		session.removeUser(indexName,token);
	}
}
