package du.cfs.global.gamesocket.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Data
@Entity
public class CashFlow {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	private User userData;

	private float amount;
	private float beforeAmount;
	private float afterAmount;
	
	private UserModifyAmount_Type serviceType;

	private enum_games_Type gametype;
	private int period_id;
	private int order_id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
}
