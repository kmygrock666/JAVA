package du.cfs.global.gamesocket.dice;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import du.cfs.global.gamesocket.dice.enum_DICE.enum_bet_type;
import du.cfs.global.gamesocket.dice.enum_DICE.enum_result;
import du.cfs.global.gamesocket.model.User;
import lombok.Data;

@Data
@Entity
public class Order_DICE {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;


	@ManyToOne
	User user;

	@ManyToOne
	Period_DICE period;

	enum_bet_type betType;

	private String number;


	private float amount;
	private float ifWinAmount;
	private enum_result result;

	private String md5;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
}
