package du.cfs.global.gamesocket.dice;

public class enum_DICE {
	public enum enum_game_status {
		INIT, BET, STOP_BET, WAIT_WIN, WIN
	}

	public enum enum_result {
		UNSET, LOSE, WIN, TIE, RETREAT
	}

	public enum enum_bet_type {
		Error, BIG, SMAIL, ODD, EVEN, B1, B6, DOUBLE, TRIPLE, SUM, ANY_TRIPLE
	}
}
