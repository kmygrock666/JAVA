package du.cfs.global.gamesocket.model;

public enum UserModifyAmount_Type {
	ATM_IN, ATM_OUT, GAME_BET, GAME_WIN
}
