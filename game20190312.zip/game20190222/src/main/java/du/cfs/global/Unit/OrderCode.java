package du.cfs.global.Unit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import lombok.val;

public class OrderCode {

	

	public static int  StringCodeToInt(String codeMap,String codeKey,String CodeString) {
		int unit = codeMap.length();
		
		String[] arrstr = CodeString.split(codeKey);
		if(arrstr.length!=2)
			return -1;
		CodeString = arrstr[1];
		
		val arr = new ArrayList<Integer>();
		
		for (char ch: CodeString.toCharArray()) {
			arr.add(codeMap.indexOf(ch));
		}
		Collections.reverse(arr);
		int i = 0 ,out = 0;
		for (Integer value : arr) {
			out +=  value * Math.pow(unit,i) ;
			i++; 
		}
		return out;
	}
	
	public static String IntToCodeString(String codeMap,String codeKey,int number,int bit) {
		int unit = codeMap.length();
		int c = (number-(number%unit))/unit;
		val arr = new ArrayList<Integer>();
		arr.add(number%unit);
		int b = 0;
		while(c>0){
			b = c%unit;
			c = (c - b) / unit;
			arr.add(b);
		}
		arr.add(-1);
		while(arr.size() < bit)
			arr.add(-2);
		Random ran = new Random();
		Collections.reverse(arr);
		String outString = "";
		for (Integer value : arr) {
			if(value==-1){
				outString += codeKey;
			}
			else if(value==-2){
				int r = ran.nextInt(codeMap.length());
				outString += codeMap.substring(r, r+1);
			}
			else{
				outString += codeMap.substring(value, value+1);
			}
		}
		return outString;
	}
	

	
	
}
