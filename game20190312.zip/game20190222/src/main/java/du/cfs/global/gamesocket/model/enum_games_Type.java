package du.cfs.global.gamesocket.model;

public enum enum_games_Type {
	DICE, game2
}
