package du.cfs.common.util;

import java.util.HashMap;
import java.util.Map;

import du.cfs.api.base.ResultVO;
import du.cfs.common.enums.ResultEnum;


public class ResultVOUtils {
	/**
	 * 成功時返回
	 * @param data
	 * @return
	 */
	public static ResultVO success(Object data) {
        ResultVO<Object> resultVO = new ResultVO<>();
        resultVO.setCode(0);
        resultVO.setMessage("success");
        resultVO.setData(data);
        return resultVO;
    }
	
	public static ResultVO success() {
        Map data = new HashMap();
        return success(data);
    }
	
	/**
	 * 錯誤返回
	 * @param code 錯誤碼
	 * @param message
	 * @return
	 */
	public static ResultVO error(Integer code, String message) {
        ResultVO<Object> resultVO = new ResultVO<>();
        resultVO.setCode(code);
        resultVO.setMessage(message);
        Map data = new HashMap();
        resultVO.setData(data);
        return resultVO;
    }
	
	public static ResultVO error(ResultEnum resultEnum) {
		return error(resultEnum.getCode(), resultEnum.getMessage());
	}
	
	/**
	 * 錯誤返回
	 * @param resultEnum 錯誤列舉
	 * @param message
	 * @return
	 */
	public static ResultVO error(ResultEnum resultEnum, String message) {
        return error(resultEnum.getCode(), message);
    }
}
