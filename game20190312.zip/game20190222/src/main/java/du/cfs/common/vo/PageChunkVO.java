package du.cfs.common.vo;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class PageChunkVO<T> {
	private List<T> content = new ArrayList<>();
	private Integer size;
	private long totalElements;
	private Integer totalPages;
	private Integer number;

	public void setNumber(Integer number) {
		this.number = number + 1;
	}
	
	
}
