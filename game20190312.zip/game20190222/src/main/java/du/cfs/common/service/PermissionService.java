package du.cfs.common.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.repository.PermissionRepository;


@Service
public class PermissionService {
	
	@Autowired
    private PermissionRepository permissionRepository;
	
	public List<Permission> findAll(){
		return permissionRepository.findAllByOrderByListorderAsc();
	}
	
	public Permission save(Permission permission) {
		return permissionRepository.save(permission);
	}
	
	public List<Permission> findByIdIn(List<Long> ids){
		return permissionRepository.findByIdIn(ids);
	} 
	
//	public Permission unIncludeRole(Long id) {
//		Permission permission = permissionRepository.findById(id).orElse(null);
//		List<Role> roles = permission.getRoles();
//		for(Role role:roles) {
//			role.getPermissions().remove(id);
//		}
//	}
	
	@Transactional
	public void deletePermission(Long id) {
		Permission permission = permissionRepository.findById(id).orElse(null);
		List<Role> roles = permission.getRoles();
		for(Role role:roles) {
			role.getPermissions().remove(id);
		}
		permissionRepository.deleteBy(id);
	}
	
	public Permission findById(Long id) {
		return permissionRepository.findById(id).orElse(null);
	}

	public Permission findByPermission(String permission) {
		return permissionRepository.findByPermission(permission);
	}
	

	
	
}
