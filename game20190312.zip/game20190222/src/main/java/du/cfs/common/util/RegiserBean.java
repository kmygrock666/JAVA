package du.cfs.common.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class RegiserBean {
	
	@Autowired
	private ConfigurableApplicationContext applicationContext;
	
	//動態註冊bean
		public <T> T registerBean(String name, Class<T> clazz, Object... args) {
			//建構bean定義
		    BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(clazz);
		    //設置依賴
		    if (args.length > 0) {
		        for (Object arg : args) {
		            beanDefinitionBuilder.addConstructorArgValue(arg);
		        }
		    }
		      
		    BeanDefinition beanDefinition = beanDefinitionBuilder.getRawBeanDefinition();
		    //註冊bean定義
		    BeanDefinitionRegistry beanFactory = (BeanDefinitionRegistry) applicationContext.getBeanFactory();
		    beanFactory.registerBeanDefinition(name, beanDefinition);
		    return applicationContext.getBean(name, clazz);
		}
		//刪除bean
		public void deleteBean(String beanName) {
			BeanDefinitionRegistry beanFactory = (BeanDefinitionRegistry) applicationContext.getBeanFactory();
			beanFactory.removeBeanDefinition(beanName);
		}
}
