package com.du.gemesocket.gloabl;

public enum enum_UserModifyAmount {
	ATM_IN, ATM_OUT, GAME_BET, GAME_WIN
}
