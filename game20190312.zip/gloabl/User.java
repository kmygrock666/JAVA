package com.du.gemesocket.gloabl;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.springframework.web.socket.WebSocketSession;

import lombok.Data;

//server.session.persistent=true
@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "name" }) })
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;

	private String name;

	private String token;


	float amount;

	private boolean iLock;

	@Transient
	private WebSocketSession webSocketSession;
	@Transient
	private String sessionID;
	@Transient
	private Date ActionDate;
    

	@PrePersist
	void createdAt() {
		this.createdAt = new Date();
		this.updatedAt = new Date();
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}

	public User() {

	}
	public User(String token, WebSocketSession webSocketSession, String userID) {
		super();
		this.token = token;
		this.webSocketSession = webSocketSession;
		this.ActionDate = new Date();
		this.name = userID;
	}

}
