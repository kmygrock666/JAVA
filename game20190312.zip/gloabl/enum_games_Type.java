package com.du.gemesocket.gloabl;

public enum enum_games_Type {
	DICE, game2
}
