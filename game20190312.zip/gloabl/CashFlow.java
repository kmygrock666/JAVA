package com.du.gemesocket.gloabl;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;


@Data
@Entity
//@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "gm_gate_id", "gateOrderNumber", "serviceType" }) })

@Table(indexes = { @Index(columnList = "isSettle"), @Index(columnList = "user_id,isSettle") })

public class CashFlow {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	private User user;

	private float amount;
	private float beforeAmount;
	private float afterAmount;

	private enum_UserModifyAmount serviceType;

	private enum_games_Type gametype;
	private int period_id;
	private int order_id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;

	private boolean isSettle;

	@PrePersist
	void createdAt() {
		this.createdAt = new Date();
	}

	public CashFlow() {

	}
}
