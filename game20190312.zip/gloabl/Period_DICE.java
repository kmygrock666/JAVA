package com.du.gemesocket.gloabl;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import com.du.gemesocket.gloabl.enum_DICE.enum_bet_type;
import com.du.gemesocket.gloabl.enum_DICE.enum_game_status;

import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "type", "areaIdx", "periodName" }) })
public class Period_DICE {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Transient
	private enum_game_status status;

	private enum_games_Type type;
	private int areaIdx;
	private String periodName;
	private String number;
	private boolean settle;

	@OneToMany(mappedBy = "period", cascade = { CascadeType.PERSIST }, fetch = FetchType.LAZY)
	List<Order_DICE> orders;

	@Transient
	private int second;
	@Transient
	private List<enum_bet_type> winTypes;

	// @OneToMany(mappedBy = "period", cascade = { CascadeType.PERSIST }, fetch =
	// FetchType.LAZY)
	// private List<GameOrder_DICE> orders = new ArrayList<GameOrder_DICE>();

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;

	@PrePersist
	void createdAt() {
		this.createdAt = new Date();
		this.settle = false;
		this.number = "";
		this.second = 0;
	}

	public Period_DICE() {

	}
}
