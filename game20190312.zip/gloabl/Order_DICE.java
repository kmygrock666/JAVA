package com.du.gemesocket.gloabl;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.codec.digest.DigestUtils;

import com.du.gemesocket.gloabl.enum_DICE.enum_bet_type;
import com.du.gemesocket.gloabl.enum_DICE.enum_result;
import com.du.gemesocket.utils.DateUnit;

import lombok.Data;

@Data
@Entity
public class Order_DICE {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;


	@ManyToOne
	User user;

	@ManyToOne
	Period_DICE period;

	enum_bet_type betType;

	private String number;


	private float amount;
	private float ifWinAmount;
	private enum_result result;

	private String md5;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;


	@PrePersist
	void createdAt() {
		this.result = enum_result.UNSET;
		this.createdAt = new Date();
		this.updatedAt = new Date();
		this.md5 = DigestUtils.md5Hex(GetBeforeMd5()).toUpperCase();
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
		this.md5 = DigestUtils.md5Hex(GetBeforeMd5()).toUpperCase();
	}

	public String GetBeforeMd5() {
		StringBuilder beforeMd5 = new StringBuilder();
		beforeMd5.append(user.getId());
		beforeMd5.append(period.getId());
		beforeMd5.append(number);
		beforeMd5.append(amount);
		beforeMd5.append(ifWinAmount);
		beforeMd5.append(DateUnit.DateTimeToStr(createdAt, "yyyyMMddHHmmss"));
		beforeMd5.append(DateUnit.DateTimeToStr(updatedAt, "yyyyMMddHHmmss"));
		beforeMd5.append("LIANG");
		return beforeMd5.toString();
	}

	public boolean checkMd5() {
		return this.md5.equals(DigestUtils.md5Hex(GetBeforeMd5()).toUpperCase());
	}

	public Order_DICE() {

	}
}
