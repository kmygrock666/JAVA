package du.cfs;


import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

//@EntityScan(basePackages = { "du.cfs.db.ADM","du.cfs.common"})
//@EnableJpaRepositories(basePackages = { "du.cfs.db.ADM","du.cfs.common"})
//@ComponentScan({"du.cfs.db.ADM","du.cfs.config","du.cfs.common","du.cfs.security","du.cfs.controller"})
@EntityScan
@EnableJpaRepositories
@ComponentScan
//@EnableScheduling
@SpringBootApplication
public class Enter_ALL {

}
