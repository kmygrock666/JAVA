package du.cfs.security;

import org.springframework.context.annotation.Profile;
import org.springframework.security.core.GrantedAuthority;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.db.ADM.Account;
import du.cfs.db.MER.MerchantMember;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@Slf4j
@Profile("mer")
public class MerUserPrinciple implements UserDetails{
	private static final long serialVersionUID = 1L;
	 
	private long id;
 
    private String name;
 
    private String username;
 
    private LocalDateTime created_at;
    
    private List<String> role;
 
    @JsonIgnore
    private String password;
 
    private Collection<? extends GrantedAuthority> authorities;
 
    public MerUserPrinciple(long id, String name, 
			    		String username, LocalDateTime created_at, String password, List<String> role,
			    		Collection<? extends GrantedAuthority> authorities) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.created_at = created_at;
        this.password = password;
        this.role = role;
        this.authorities = authorities;
        log.info("新增用戶資訊");
    }
 
    public static MerUserPrinciple build(MerchantMember user) {
//        List<GrantedAuthority> authorities = user.getRoles().stream().map(role ->
//                new SimpleGrantedAuthority(role.getName().name())
//        ).collect(Collectors.toList());
    	
//    	List<Role> roles = user.getRoles();
//    	List<GrantedAuthority> authorities = new ArrayList<>();
//    	for (Role role : roles) {
//    		authorities.add(new SimpleGrantedAuthority(role.getName()));
//    	}
    	Set<Role> roles = user.getRoles();

    	List<String> user_role = new ArrayList<>();
    	List<GrantedAuthority> authorities = new ArrayList<>();
    	for (Role role : roles) {
    		GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(role.getName());
    		//此處將角色信息添加到GrantedAuthority對像中，在後面進行全權限驗證時會使用GrantedAuthority對象。
    		authorities.add(grantedAuthority);
    		List<Permission> permissions = role.getPermissions();
    		user_role.add(role.getName());
    		log.info("用戶角色"+role.getName());
            for (Permission permission : permissions)
            {
                if (permission != null && permission.getName() != null)
                {   
	               	 log.info("用戶權限"+permission.getUrl());
	               	 GrantedAuthority grantedAuthority1 = new SimpleGrantedAuthority(permission.getPermission());
	               	//此處將權限信息添加到GrantedAuthority對像中，在後面進行全權限驗證時會使用GrantedAuthority對象。
	               	 authorities.add(grantedAuthority1);
                }
            }
    	}
    	log.info("新增儲存用戶權限"+authorities.toString());
        return new MerUserPrinciple(
                user.getId(),
                user.getNickname(),
                user.getUsername(),
                user.getCreated_at(),
                user.getPassword(),
                user_role,
                authorities
        );
    }
 
    public long getId() {
        return id;
    }
 
    public String getName() {
        return name;
    }
 
    public LocalDateTime getCreated_at() {
        return created_at;
    }
 
    @Override
    public String getUsername() {
        return username;
    }
 
    @Override
    public String getPassword() {
        return password;
    }
 
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }
 
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }
 
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }
 
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
 
    @Override
    public boolean isEnabled() {
        return true;
    }
 
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        MerUserPrinciple user = (MerUserPrinciple) o;
        return Objects.equals(id, user.id);
    }
}
