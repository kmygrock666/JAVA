package du.cfs.security.handel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;

import du.cfs.common.util.RemoveUser;
import du.cfs.security.AdmUserPrinciple;

@Component
public class CustomLogoutSuccessHandler implements LogoutHandler {
	
    @Autowired
    RemoveUser session;
    
	@Override
	public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
		// TODO Auto-generated method stub
		HttpSession sessionId = request.getSession();
		String token = sessionId.getId();
		AdmUserPrinciple userPrincipal = (AdmUserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		String indexName = userPrincipal.getUsername();
		System.out.println("用戶名:"+indexName);
		session.removeUser(indexName,token);
	}
}
