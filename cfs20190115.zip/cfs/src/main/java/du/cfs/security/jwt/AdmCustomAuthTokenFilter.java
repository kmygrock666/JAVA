package du.cfs.security.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import du.cfs.common.model.SysConfig;
import du.cfs.global.Unit.IpUtil;
import du.cfs.security.AdmCustomUserDetailsServiceImp;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Profile("dev")
public class AdmCustomAuthTokenFilter extends OncePerRequestFilter{

 
    @Autowired
    private AdmCustomUserDetailsServiceImp userDetailsService;
    
//    @Autowired
//    private SysConfigService sysConfigService;
    
    @Autowired
    private JwtProvider tokenProvider;
    
    protected void doFilterInternal(HttpServletRequest request, 
    								HttpServletResponse response, 
    								FilterChain filterChain) throws ServletException, IOException {
    	
        try {
        	
        	log.info("COMING IN CustomAuthTokenFilter-------------------------------------------------");
        	
            String jwt = getJwt(request);    

            if (jwt!=null) {
            	tokenProvider.validateJwtToken(jwt);
//            	SysConfig sysDb = sysConfigService.findByToken(jwt);
//            	String clientIp = IpUtil.getIpAddr(request);
//            	String token = sysDb.getToken();
//            	String dbIp = sysDb.getIp();

//            	if(jwt.toUpperCase().equals(token) && clientIp.equals(dbIp)) {
	            	//解析token取得用戶名
	                String username = tokenProvider.getUserNameFromJwtToken(jwt);
//            		String username = sysDb.getCommerce_name();
	                logger.info("checking authentication " + username);
	                //查詢用戶是否存在
	                UserDetails userDetails = userDetailsService.loadUserByUsername(username);
	                
	                UsernamePasswordAuthenticationToken authentication 	= new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
	                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
	                log.info("authenticated user " + username + ", setting security context");
	                SecurityContextHolder.getContext().setAuthentication(authentication);
//            	}
            }
        } catch (Exception e) {
            logger.error("Can NOT set user authentication -> Message: {}", e);
        }
 
        filterChain.doFilter(request, response);
    }
 
    private String getJwt(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        	
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
        	return authHeader.replace("Bearer ","");
        }
 
        return null;
    }
}
