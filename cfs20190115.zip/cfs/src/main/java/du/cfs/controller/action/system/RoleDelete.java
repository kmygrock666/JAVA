package du.cfs.controller.action.system;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class RoleDelete extends BaseAction{
	
	@Autowired
	RoleService roleService;

	@Override
	public String execute() {
		
		String id =  getParam("id");

//		roleService.deleteRole( Long.parseLong(id));
		System.out.println("THIS IS DELETE ID = "+id);
		return "redirect:/cm/system/RoleManagement";
	}
	
}
