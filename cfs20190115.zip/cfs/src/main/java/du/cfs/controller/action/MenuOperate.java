package du.cfs.controller.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.RememberTokenService;
import du.cfs.common.service.RoleService;
import du.cfs.security.AdmUserPrinciple;

@Component
public class MenuOperate {
	
	@Autowired
    private RememberTokenService commerceService;
	
	@Autowired
    private RoleService roleService;
	
	
	private List<Map<String,Object>> menus = new ArrayList<>();
	
	public List<Map<String,Object>> getMenu(AdmUserPrinciple userinfo) {
		
		if(menus.size() == 0) {
			System.out.println("===========get menus=============");
			Map<Integer, List<Permission>> tmp = new HashMap<>();  
			
			List<String> roles = userinfo.getRole();
			
			for(String r : roles) {
				
				Role role = roleService.findByName(r).orElse(null);
				List<Permission> permissions = role.getPermissions();

				for(Permission  permit : permissions) {
					List<Permission> tmpPermit;
//					System.out.println(JSON.toJSONString(permit,true));
					Menu menu = permit.getMenu();
					int key = menu.getSort();
					if(permit.getParent_id() == 1) {
						if(tmp.containsKey(menu.getSort())) {
							tmpPermit = tmp.get(key);
							tmpPermit.add(permit);
							tmp.put(key, tmpPermit);
						}else {
							tmpPermit = new ArrayList<>();
							tmpPermit.add(permit);
							tmp.put(key, tmpPermit);
						}
					}
				}		
			}
			

			for(Entry<Integer, List<Permission>> entry : tmp.entrySet()) {
				Map<String,Object> Mapp = new HashMap<>();
				Menu tmpMenu = entry.getValue().get(0).getMenu();
				Mapp.put("sub", tmpMenu.getName());
				Mapp.put("icon", tmpMenu.getIcon());
				Mapp.put("dir", entry.getValue());
				menus.add(Mapp);
			}
		}
				
		return menus;
	}
	
	public Map<String,String> getMainTitle(String sub,String action) {
		Map<String,String> pathDetial = new HashMap<>();
		for (Map<String,Object> m:menus) {
			List<Permission> permissions = (List<Permission>) m.get("dir");

			for (Permission permit:permissions) {
				if (permit.getPermission().contentEquals(action)) {
					pathDetial.put("dir", (String) m.get("sub"));
					pathDetial.put("sub", permit.getName());
				}
			}
		}
		return pathDetial;
		
	}
}
