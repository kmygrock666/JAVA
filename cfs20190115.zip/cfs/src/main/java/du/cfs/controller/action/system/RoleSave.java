package du.cfs.controller.action.system;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class RoleSave extends BaseAction{
	
	@Autowired
	RoleService roleService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		String code =  getParam("code");
//		String[] rolea =  getParam("code");
		String name =  getParam("name");
		Role role = new Role();
		role.setName("ROLE_"+code.toUpperCase());
		role.setDescription(name);
		roleService.saveRole(role);
		
		return "redirect:/cm/system/RoleManagement";
	}
	
}
