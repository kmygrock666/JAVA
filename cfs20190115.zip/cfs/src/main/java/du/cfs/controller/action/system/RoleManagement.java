package du.cfs.controller.action.system;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class RoleManagement extends BaseAction{
	
	@Autowired
	RoleService roleService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		List<Role> roles = roleService.findAll();
		assign("roleList",roles);
//		System.out.println(JSON.toJSONString(roles,true));
		return getView("role");
	}
	
}
