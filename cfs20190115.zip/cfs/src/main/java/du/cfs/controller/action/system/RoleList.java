package du.cfs.controller.action.system;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.repository.PermissionRepository;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class RoleList extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	MenuService menuService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		String code =  getParam("code");
		List<Menu> menus = menuService.findAll();
		Role roles = roleService.findByName(code).orElse(null);
//		List<Permission> permissions = permissionService.findAll();
		
		Map<String, String> permissions = roles.getPermissions().stream().collect(Collectors.toMap(Permission::getPermission, Permission::getPermission));

		assign("menus",menus);
		assign("perAll",permissions);
		System.out.println(JSON.toJSONString(permissions,true));
		System.out.println(JSON.toJSONString(menus));
		System.out.println("Success");
		return getView("roleList");
	}
	
}
