package du.cfs.db.ADM;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import du.cfs.db.ADM.AccountRepository;

@Service
public class AccountService {
	@Autowired
    private AccountRepository accountRepository;
	
	@Autowired
	@Lazy //TODO 解決 Requested bean is currently in creation: Is there an unresolvable circular reference 問題 
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	public Account save(Account user){
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		user.setCreated_at(LocalDateTime.now());
		return accountRepository.save(user);
	}
	
	public Optional<Account> findByUsername(String name) {
		return accountRepository.findByUsername(name);
	}
	
	public void deleteAccount(Long id) {
		accountRepository.deleteById(id);
	}
//	public Collection<MenuPermission> findMenuByUsername(String username) {
//		// TODO Auto-generated method stub
//		return accountRepository.findMenuByUsername(username);
//	}
	
	/**
	 * 測試事務操作方法
	 * @param id
	 * @param role_id
	 * @param uid
	 * @return
	 */
//	@Transactional
//	public int deleteAndUpdate(int id,int role_id,int uid) {
//		int dcount =  accountRepository.deleteByJPQL(id);
//
//		int ucount = accountRepository.updateByJPQL(role_id, uid);
//		
//		return dcount+ucount;
//	}
//	
//	public int updateInfo(String password,int role_id,String com04,int id) {
//		password = bCryptPasswordEncoder.encode(password);
//		return accountRepository.updateInfoByJPQL(password, role_id, com04, id);
//	}
}
