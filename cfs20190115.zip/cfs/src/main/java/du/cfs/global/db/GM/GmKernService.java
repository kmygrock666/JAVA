package du.cfs.global.db.GM;

public interface GmKernService {
	GmKern GetGmKern(int id);

	GmKern create(GmKern gmKern);
}
