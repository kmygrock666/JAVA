package du.cfs.global.Unit;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.xml.bind.DatatypeConverter;

public class EncryptAndDecrypt {
	public static boolean Md5Check(String sourceString,String hash) {
		return hash.equals(Md5(sourceString));
	}
	public static String Md5(String sourceString) {
		try {
			MessageDigest md;
			md = MessageDigest.getInstance("MD5");
			md.update(sourceString.getBytes());
			byte[] digest = md.digest();
			return DatatypeConverter.printHexBinary(digest).toUpperCase();
		} catch (NoSuchAlgorithmException e) {
		}
		return "";
	}
	
}
