package du.cfs.global.db.GM;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GmKernServiceImpl implements GmKernService {

	@Autowired
	GmKernRepository repository;

	public GmKern GetGmKern(int id) {
		Optional<GmKern> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public GmKern create(GmKern gmKern) {
		return repository.save(gmKern);
	}
}
