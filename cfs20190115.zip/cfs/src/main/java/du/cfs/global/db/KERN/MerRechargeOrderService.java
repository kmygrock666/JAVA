package du.cfs.global.db.KERN;

public interface MerRechargeOrderService {

	MerRechargeOrder GetRechargeOrder(int id);

	MerRechargeOrder save(MerRechargeOrder r);

	MerRechargeOrder InsertOrder(MerRechargeOrder rechargeOrder);

	MerRechargeOrder GetRechargeOrder(String kernOrderNumber);
}
