package du.cfs.global.db.GM;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Unit.OrderCode;

@Service
public class GmGateServiceImpl implements GmGateService {

	@Autowired
	GmGateRepository repository;
	
	private static String codeMap = "vwA0xyBtFcMOd7EqrUGkIfgRJKjChlmSunH2PoL6eTY4i3zWXDZQbNVa5p";
	private static String codeKey = "s";
	
	@Override
	public GmGate GetGmGate(int id) {
		Optional<GmGate> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public GmGate GetGmGateByCode(String Code) {
		int id = OrderCode.StringCodeToInt(codeMap, codeKey, Code);
		return GetGmGate(id);
	}

	@Override
	public GmGate update(GmGate gateListRecharge) {
		return repository.save(gateListRecharge);
	}
	@Override
	public GmGate create(GmGate gateListRecharge) {
		gateListRecharge = repository.save(gateListRecharge);
		String gateCode = OrderCode.IntToCodeString(codeMap, codeKey, (int) gateListRecharge.getId(), 20);
		gateListRecharge.setGateCode(gateCode);
		return repository.save(gateListRecharge);
	}

	@Override
	public GmGate GetGmGateByIP(String ip) {
		Optional<GmGate> optional = repository.findBygateIp(ip);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public List<GmGate> GetAllGmGate() {
		return repository.findAll();
	}
	
	

}
