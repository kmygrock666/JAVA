package du.cfs.global.db.KERN;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Unit.OrderCode;

@Service
public class MerAgentPayOrderServiceImpl implements MerAgentPayOrderService {

	@Autowired
	private MerAgentPayOrderRepository repository;

	public MerAgentPayOrder GetRechargeOrder(int id) {
		Optional<MerAgentPayOrder> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public MerAgentPayOrder GetRechargeOrder(String kernOrderNumber) {
		int id = OrderCode.StringCodeToInt(codeMap, codeKey, kernOrderNumber);
		return GetRechargeOrder(id);
	}

	private static String codeMap = "vwA0xyBzWXDZQbUcMOd7Eqrst1SunH2PoL6eTY4i3GkIfgRJKjChlmNVa5p"; // form config
	private static String codeKey = "F"; // from config

	public MerAgentPayOrder InsertOrder(MerAgentPayOrder rechargeOrder) {
		try {
			rechargeOrder = repository.save(rechargeOrder);
			String orderCode = OrderCode.IntToCodeString(codeMap, codeKey, (int) rechargeOrder.getId(), 20);
			rechargeOrder.setKernOrderNumber(orderCode);
			rechargeOrder = repository.save(rechargeOrder);
			return rechargeOrder;
		} catch (Exception e) {
			return null;
		}
	}

	public MerAgentPayOrder save(MerAgentPayOrder r) {
		return repository.save(r);
	}

}
