package du.cfs.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.common.model.Menu;

public interface MenuRepository extends JpaRepository<Menu, Long>{
	List<Menu> findAllByOrderBySortAsc();
}
