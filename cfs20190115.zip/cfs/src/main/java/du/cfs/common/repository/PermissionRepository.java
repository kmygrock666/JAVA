package du.cfs.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.common.model.Permission;

public interface PermissionRepository extends JpaRepository<Permission, Long>{
	
}
