package du.cfs.common.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;

@Component
@Profile("dev")
public class BackStateSeed {
	@Autowired
    private AccountService accountService;
	
	@Autowired
    private RoleService roleService;
	
	@Autowired
    private PermissionService permissionService;
	
	@Autowired
    private MenuService menuService;
	
	public void AddAccount(){
		System.out.println("---------------新增帳號----------------------");
		Account user1 = new Account();
		user1.setUsername("rdian");
		user1.setPassword("123");
		user1.setNickname("rdian");
		user1.setStatus("ACCESS");
		Role WhatRole1 = roleService.findByName("ROLE_ADMIN")
                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
		
//		System.out.println(JSON.toJSONString(WhatRole,true));
		user1.addRole(WhatRole1);
		accountService.save(user1);
		
		Account user = new Account();
		user.setUsername("ian");
		user.setPassword("123");
		user.setNickname("ian");
		user.setStatus("ACCESS");
		Role WhatRole = roleService.findByName("ROLE_USER")
                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
		
//		System.out.println(JSON.toJSONString(WhatRole,true));
		user.addRole(WhatRole);
		accountService.save(user);
	}
	
	//建立sub
	public void addMenu() {
		System.out.println("---------------建立目錄----------------------");
		Menu menu = new Menu();
		menu.setIcon("fa fa-gear");
		menu.setName("系統管理");
		menu.setCode("system");
		menu.setSort(1);
		menuService.save(menu);
		
		Menu menu1 = new Menu();
		menu1.setIcon("fa fa-align-left");
		menu1.setName("代收管理");
		menu1.setCode("agent");
		menu1.setSort(2);
		menuService.save(menu1);
		
		Menu menu3 = new Menu();
		menu3.setIcon("fa fa-align-left");
		menu3.setName("未分類");
		menu3.setCode("none");
		menu3.setSort(3);
		menuService.save(menu3);
	}
	
	//權限
	public void addPermission() {
		System.out.println("---------------權限----------------------");
		List<Menu> menus = menuService.findAll();
//		System.out.println(JSON.toJSONString(menus,true));
		
		Permission p = new Permission();
		p.setParent_id(0);;
		p.setName("首頁");
		p.setPermission("Index");
		p.setUrl("/index/Index");
		p.setMenu(menus.get(2));
		permissionService.save(p);
		
		Permission p1 = new Permission();
		p1.setParent_id(1);
		p1.setName("商戶管理");
		p1.setPermission("Merchant");
		p1.setUrl("/system/Merchant");
		p1.setMenu(menus.get(0));
		permissionService.save(p1);
		
		Permission p2 = new Permission();
		p2.setParent_id(1);
		p2.setName("控端管理");
		p2.setPermission("Account");
		p2.setUrl("/system/Account");
		p2.setMenu(menus.get(0));
		permissionService.save(p2);
		
		Permission p21 = new Permission();
		p21.setParent_id(1);
		p21.setName("權限管理");
		p21.setPermission("Permission");
		p21.setUrl("/system/Permission");
		p21.setMenu(menus.get(0));
		permissionService.save(p21);
		
		Permission p22 = new Permission();
		p22.setParent_id(1);
		p22.setName("角色管理");
		p22.setPermission("RoleManagement");
		p22.setUrl("/system/RoleManagement");
		p22.setMenu(menus.get(0));
		permissionService.save(p22);
		
		Permission p23 = new Permission();
		p23.setParent_id(1);
		p23.setName("Menu管理");
		p23.setPermission("Menu");
		p23.setUrl("/system/Menu");
		p23.setMenu(menus.get(0));
		permissionService.save(p23);
		
		Permission p3 = new Permission();
		p3.setParent_id(1);
		p3.setName("代收查詢");
		p3.setPermission("OrderList");
		p3.setMenu(menus.get(1));
		p3.setUrl("/order/OrderList");
		permissionService.save(p3);
	}
	//角色
	public void AddRole() {
		System.out.println("---------------新增角色----------------------");
		List<Permission> permissions = permissionService.findAll();
		Role role = new Role();
		role.setName("ROLE_ADMIN");
		role.setDescription("管理者");
		role.setPermissions(permissions);
		roleService.saveRole(role);
		
		List<Permission> permissions2 = new ArrayList();
		permissions2.add(permissions.get(0));
		permissions2.add(permissions.get(4));
		
		Role role2 = new Role();
		role2.setName("ROLE_USER");
		role2.setDescription("使用者");
		role2.setPermissions(permissions2);
		roleService.saveRole(role2);
	}
	
}
