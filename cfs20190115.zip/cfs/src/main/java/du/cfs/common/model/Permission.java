package du.cfs.common.model;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Entity
public class Permission {
	 @Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	 private Long id;
	 //权限名称
	 private String name;
	 //权限描述
	 private String permission;
	 //授权链接
	 private String url;
	//顯示於menu
	 private int parent_id;
	 
	 @ManyToOne
	 private Menu menu;
	 
//	 @ManyToMany(mappedBy = "permissions")
//	 private List<Role> roles;
	 
}
