package du.cfs.common.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.repository.RoleRepository;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountRepository;

@Service
public class RoleService {
	@Autowired
    private RoleRepository roleRepository;
	
	@Autowired
    private AccountRepository accountRepository;
	
	/**
	 * 查詢角色
	 * @param name
	 * @return
	 */
	public Optional<Role> findByName(String name) {
		return roleRepository.findByName(name);
	}
	
	public Role saveRole(Role role) {
		return roleRepository.save(role);
	}
	
	public List<Role> findAll() {
		return roleRepository.findAll();
	}
	
	@Transactional
	public void deleteRole(long id) {
		Role role = roleRepository.findById(id).orElse(null);
		System.out.println(JSON.toJSONString(role,true));
//		for(Account account : role.getAccount()) {
//			account.getRoles().remove(role);
//		}
		
//		roleRepository.delete(role);
//		roleRepository.deleteRole(id);
	}
	
	
	

	
	
}
