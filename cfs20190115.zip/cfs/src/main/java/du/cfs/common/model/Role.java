package du.cfs.common.model;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonFormat;

import du.cfs.db.ADM.Account;
import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "name", "description" }) })
public class Role {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(length = 50,nullable = false,updatable=false)
	private String  name;
	@Column(length = 50,nullable = false,updatable=false)
	private String description;
	
//	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="timestamp", columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private LocalDateTime  created_at;
	
	@ManyToMany
	private List<Permission> permissions;
	
//	@ManyToMany(mappedBy = "roles")	
//	private Set<Account> account = new HashSet<>();
	
	
}
