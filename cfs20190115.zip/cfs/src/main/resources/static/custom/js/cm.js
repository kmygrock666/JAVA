$(function() {
    console.log( "ready!" );
    $('.modal').on('hidden.bs.modal', function(){
        $(this).find('form')[0].reset();
    });
});

Vue.component('m-content',{
	template: "<div></div>"
});

var model = new Vue({
	el: "#showmodal",
	data : {
		contentName : "m-content"
	},
	methods:{
		show: function(){
			this.show = true;
		}
	}
}); 

function logout(logout){
	parent.location.href = logout;
}

function getLoad(url){
	$("#container").load(url);
}

function openWin(page) {


//	$('#showDialog #dialogPage', parent.document).on('load', function() {
//		$('#showDialog #dialogPage', parent.document).contents().find('#closebutton').on('click', function() {
//			closeWin();
//		});
//		$('#showDialog #dialogPage', parent.document).contents().find('form').on('#submit', function() {
//			closeWin();
//		});
//	});
//

	this.model.contentName = 'm-content';
	$('#diaLoad').load(page);
	$('#showDialog').modal("show");
	//console.log($('#showDialog',parent.document).data('bs.modal'));
}

function dia(el){

	Vue.component(el,{
		template: "#"+el,
		methods:{
			formSubmit: function(){

				var formData =new FormData(this.$refs.dataForm);
				var url = this.$refs.dataForm.action;
				var type = this.$refs.dataForm.method;
				let config = {headers:{'Content-Type':'multipart/form-data'}};
				
				if(type.toLowerCase() == 'post'){
					this.$http.post(url,formData,config).then(function(success){
//						console.log("success");
//						console.log(res);
						this.$Message.success('新增成功');
						closeDialog();
						refreshView(success.body);
					},function(error){
						// error callback
//						console.log("error");
						this.$Message.success('新增失敗');
						closeDialog();
						refreshView(error.body);
					}).finally(function(){
						// finally callback
//						closeDialog();
					})
				}else{
					this.$http.get(url,{params:  formData}).then(function(success){
//						console.log(res);
						closeDialog();
						refreshView(success.body);
					},function(error){
						// error callback
						closeDialog();
						refreshView(error.body);
					}).finally(function(){
						// finally callback
//						closeDialog();
					})
				}

			},
			//隱藏
			hideForm: function(){
				//清空表單
//				this.$refs['dataForm'].resetFields();
				closeDialog();
			}
		}
		
		
	});
	
	this.model.contentName = el;

	$('#diaLoad').html("");
	$('#showDialog').modal("show");
	
}

function closeDialog(){
	$('#showDialog').modal("hide");
}

function refreshView(respond){
	$("#container").html(respond);
}

function post(url,d){
	Vue.http.post(url,d).then(function(success) {
		
	},function(error){
		
	})
}

function get(url,d=''){
	Vue.http.get(url,{params:d}).then(function(success) {
		refreshView(success.body);
	},function(error){
		refreshView(error.body);
	})
}

