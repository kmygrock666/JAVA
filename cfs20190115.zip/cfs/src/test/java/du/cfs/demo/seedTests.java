package du.cfs.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import du.cfs.Application;
import du.cfs.common.util.BackStateSeed;

@RunWith(SpringRunner.class)
@ActiveProfiles(profiles = "dev")
@SpringBootTest(classes = Application.class)
public class seedTests {
//	@Autowired
//	DataSeed_kern dataSeed_kern;
	
	@Autowired
	BackStateSeed backStateSeed;
	

//	@Autowired
//	DataSeed_gate dataSeed_gate;
	
	@Test
	public void test1() {
//		Merchant mc  = dataSeed_kern.SetMerConfigTestSeed();
//		int gateInfoId = dataSeed_kern.SetGateInfoTestSeed(null, null);
//		int gateListId = dataSeed_kern.SetGateListTestSeed(gateInfoId);
//		int MerGateConfigId = dataSeed_kern.SetMerGateConfigTestSeed(mc,gateListId);
//		int RechargeId = dataSeed_kern.SetRechargeTestSeed(mc,gateListId);
//		String t = "AAA";
//		assertThat(t).isEqualTo("AAA");
	}
	
	@Test
	public void test2() {
		
		backStateSeed.addMenu();
		backStateSeed.addPermission();
		backStateSeed.AddRole();
		backStateSeed.AddAccount();
		
	}
	
	String KernCode = "";
	@Test
	public void testSeedKern() {
//		GateListRecharge glr = dataSeed_gate.SetGateListRecharge(); 
//		KernCode = dataSeed_gate.SetKern();
//		Merchant mc = dataSeed_kern.SetMerConfigTestSeed();
//		int gateInfoId = dataSeed_kern.SetGateInfoTestSeed(KernCode,glr.getName());
//		int gateListId = dataSeed_kern.SetGateListTestSeed(gateInfoId);
//		dataSeed_kern.SetMerGateConfigTestSeed(mc, gateListId);
//		dataSeed_kern.SetRechargeTestSeed(mc, gateListId);
//		String t = "AAA";
//		assertThat(t).isEqualTo("AAA");
	}
}
