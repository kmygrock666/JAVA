package com.spring.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import du.cfs.Application;
import du.cfs.global.db.Merchant;
import du.cfs.global.event.BackStateSeed;
import du.cfs.global.seed.DataSeed_kern;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class seedTests {
	@Autowired
	DataSeed_kern dataSeed_kern;
	
	@Autowired
	BackStateSeed backStateSeed;
	
	@Test
	public void test1() {
		Merchant mc  = dataSeed_kern.SetMerConfigTestSeed();
		int gateInfoId = dataSeed_kern.SetGateInfoTestSeed();
		int gateListId = dataSeed_kern.SetGateListTestSeed(gateInfoId);
		int MerGateConfigId = dataSeed_kern.SetMerGateConfigTestSeed(mc,gateListId);
		int RechargeId = dataSeed_kern.SetRechargeTestSeed(mc,gateListId);
		String t = "AAA";
//		assertThat(t).isEqualTo("AAA");
	}
	
	@Test
	public void test2() {
		
		backStateSeed.AddRole();
		backStateSeed.AddCommerce();
		backStateSeed.addMenu();
		backStateSeed.addPermission();
		
	}
}
