package du.cfs.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Service;

import du.cfs.model.Permission;
import du.cfs.model.Role;
import du.cfs.repository.PermissionRepository;
import du.cfs.repository.RoleRepository;
import du.cfs.service.CommerceService;
import du.cfs.service.PermissionService;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import lombok.extern.slf4j.Slf4j;
/**
 * 權限配置資源管理
 * @author RD00
 * @Description 
 * 實現FilterInvocationSecurityMetadataSource
 * 啟動時就去加載了所有權限列表
 * 判斷用戶訪問資源是否在保護的範圍內
 */
@Slf4j
@Service
public class CustomFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource{
	
	 @Autowired
	 private PermissionService permissionService;
	
	/**
	 * 儲存相關權限
	 * todo : 權限若修改新增，無法及時更新
	 */
	private Map<RequestMatcher, Collection<ConfigAttribute>> requestMap = null;
	
	public void loadResourceDefine() {
		Map<RequestMatcher, Collection<ConfigAttribute>> map = new HashMap<>();
        //用来存储权限的容器
        ConfigAttribute cfg;
        //从数据库查询全部的权限信息
		List<Permission> permissions = permissionService.findAll();

		for(Permission permission : permissions) {
			AntPathRequestMatcher matcher = new AntPathRequestMatcher(permission.getUrl());
            cfg = new SecurityConfig(permission.getPermission());
            log.info("---------------------加载数据库中全部权限--------------------->>>loadResourceDefine");
//            log.info("---------------------加载数据库中全部权限--------------------->>>-"+permission.getUrl());
            ArrayList<ConfigAttribute> configs = new ArrayList<>();
            configs.add(cfg);            
            map.put(matcher, configs);

        }
		this.requestMap = map;
	}
	
	@Override
	public Collection<ConfigAttribute> getAttributes(Object object) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		if(requestMap == null)  loadResourceDefine();

		// object中包含用戶請求的請求信息
		HttpServletRequest request = ((FilterInvocation) object).getHttpRequest();
//        log.info("---------------------判斷是否存在數據中权限--------------------->>>getAttributes-");
        log.info("---------------------判斷是否存在數據中权限--------------------->>>"+request.getRequestURI());

        for (Map.Entry<RequestMatcher, Collection<ConfigAttribute>> entry : requestMap
                .entrySet()) {
        	//请求路径和requestMap中的路径进行匹配，成功了就从requestMap中获取对应路径的权限
            if (entry.getKey().matches(request)) {
            	log.info("---------------------判斷是否存在數據中权限--------------------->>>for->if-"+entry.getValue());
            	log.info("---------------------判斷是否存在數據中权限--------------------->>>for->if-"+entry.getKey());
                return entry.getValue();
            }
        }

        return null;

	}

	@Override
	public Collection<ConfigAttribute> getAllConfigAttributes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return true;
	}

}
