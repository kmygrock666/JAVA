package du.cfs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.model.Permission;
import du.cfs.repository.CommerceRepository;
import du.cfs.repository.PermissionRepository;

@Service
public class PermissionService {
	@Autowired
    private PermissionRepository permissionRepository;
	
	public List<Permission> findAll(){
		return permissionRepository.findAll();
	}
	
	public Permission save(Permission permission) {
		return permissionRepository.save(permission);
	}
}
