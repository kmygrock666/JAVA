package du.cfs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.model.Permission;

public interface PermissionRepository extends JpaRepository<Permission, Long>{

}
