package du.cfs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.model.Account;

public interface AccountRepository extends JpaRepository<Account, Long>{

}
