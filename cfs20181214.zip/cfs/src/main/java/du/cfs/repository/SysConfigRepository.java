package du.cfs.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import du.cfs.model.Commerce;
import du.cfs.model.Menu;
import du.cfs.model.SysConfig;


public interface SysConfigRepository extends JpaRepository<SysConfig, Long>{
	SysConfig findByToken(String token);
}
