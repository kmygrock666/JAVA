package du.cfs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.model.Menu;

public interface MenuRepository extends JpaRepository<Menu, Long>{
	List<Menu> findAllByOrderBySortAsc();
}
