package du.cfs.controller.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import du.cfs.security.UserPrinciple;

@Component
public class BaseCore {
	
	@Autowired
	MenuOperate menu;
	/**
	 * 設置VIEW
	 */
	public void initView(Model model) {
		UserPrinciple userInfo = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<Map<String,Object>> menus = menu.getMenu(userInfo);
		model.addAttribute("menus", menus);
		model.addAttribute("user", userInfo);
	}
	
	public Map<String,Object> transferData(HttpServletRequest request,Model model,String sub){
		 Map<String,Object> data = new HashMap<>();
		 request.setAttribute("sub", sub);
		 data.put("model", model);
		 data.put("request", request);
		 return data;
	}
	
	public void name() {
		System.out.println("asczcsqwea");
	}
	

}
