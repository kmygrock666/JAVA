package du.cfs.controller.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.taglibs.standard.lang.jstl.test.beans.PublicBean1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import du.cfs.model.Commerce;
import du.cfs.model.Menu;
import du.cfs.model.Permission;
import du.cfs.model.Role;
import du.cfs.repository.CommerceRepository;
import du.cfs.repository.CommerceRepository.MenuPermission;
import du.cfs.security.UserPrinciple;
import du.cfs.security.response.FieldResource;
import du.cfs.service.CommerceService;
import du.cfs.service.MenuService;

@Component
public class MenuOperate {
	
	@Autowired
    private CommerceService commerceService;
	
	@Autowired
    private MenuService menuService;
	
	private List<Map<String,Object>> menus = new ArrayList<>();
	
	public List<Map<String,Object>> getMenu(UserPrinciple userinfo) {
		
		if(menus.size() == 0) {
			Map<Integer, List<Permission>> tmp = new HashMap<>();  
			
			List<String> roles = userinfo.getRole();
			
			for(String r : roles) {
				
				Role role = commerceService.findByName(r).orElse(null);
				List<Permission> permissions = role.getPermissions();

				for(Permission  permit : permissions) {
					List<Permission> tmpPermit;
//					System.out.println(JSON.toJSONString(permit,true));
					Menu menu = permit.getMenu();
					int key = menu.getSort();
					if(permit.getMenu_show() == 1) {
						if(tmp.containsKey(menu.getSort())) {
							tmpPermit = tmp.get(key);
							tmpPermit.add(permit);
							tmp.put(key, tmpPermit);
						}else {
							tmpPermit = new ArrayList<>();
							tmpPermit.add(permit);
							tmp.put(key, tmpPermit);
						}
					}
				}		
			}
			

			for(Entry<Integer, List<Permission>> entry : tmp.entrySet()) {
				Map<String,Object> Mapp = new HashMap<>();
				Menu tmpMenu = entry.getValue().get(0).getMenu();
				Mapp.put("sub", tmpMenu.getName());
				Mapp.put("icon", tmpMenu.getIcon());
				Mapp.put("dir", entry.getValue());
				menus.add(Mapp);
			}
		}
		//another method
//		if(menus.size() == 0) {
//			System.out.println("menu == null");
//			Collection<MenuPermission> permissions = commerceService.findMenuByUsername(userinfo.getUsername());
//			List<Menu> menu = menuService.findAll();
//			for(Menu m : menu) {
//				List<MenuPermission> fieldpermission = new ArrayList<>();
//				for(MenuPermission permission : permissions) {
//					if( permission.getMenu_show().equals("1") && m.getId() == permission.getMenu()) {
//						fieldpermission.add(permission);
//					}
//				}
//				if(fieldpermission.size() > 0) {
//					Map<String,Object> Mapp = new HashMap<>();
//					Mapp.put("sub", m.getName());
//					Mapp.put("icon", m.getIcon());
//					Mapp.put("dir", fieldpermission);
//					menus.add(Mapp);
//				}
//			}
//		}
				
		return menus;
	}
	
	
}
