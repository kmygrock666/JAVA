package du.cfs.controller;


import lombok.AllArgsConstructor;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.data.redis.RedisOperationsSessionRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import du.cfs.security.UserPrinciple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
public class UserManageApi {
private final FindByIndexNameSessionRepository<? extends Session> sessionRepository;
private final RedisOperationsSessionRepository redisOperationsSessionRepository;

/**
* 管理指定使用者退出登入
* @param userId 使用者ID
* @return 使用者 Session 資訊
*/
//@PreAuthorize("hasRole('ROLE_ADMIN')")
@GetMapping("/manager/delete/{userId}")
public String data(@PathVariable Long userId){
	System.out.println("COMING DATA   ； ");
// 查詢 PrincipalNameIndexName（Redis 使用者資訊的 key），結合自身業務邏輯來實現
//UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//String indexName = userPrincipal.getUsername();
	String indexName = "rdian";
	System.out.println("COMING DATA AND 名字  ； "+indexName);
// 查詢使用者的 Session 資訊，返回值 key 為 sessionId
Map<String, ? extends Session> userSessions = sessionRepository.findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, indexName);
// 移除使用者的 session 資訊
List<String> sessionIds = new ArrayList<>(userSessions.keySet());

for (String session : sessionIds) {
	System.out.println("找到的ＳＥＳＳＩＯＮ  ； "+session);
	redisOperationsSessionRepository.deleteById(session);
}
return userSessions.toString();
}
}
