package du.cfs.global.Service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import du.cfs.global.Repository.GateInfoRepository;
import du.cfs.global.db.GateInfo;
@Service
public class GateInfoServiceImpl implements GateInfoService {

	@Autowired
	GateInfoRepository repository;

	public GateInfo getGateInfo(int id) {
		Optional<GateInfo> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Transactional
	public GateInfo save(GateInfo gateType) {
		return repository.save(gateType);
	}

}
