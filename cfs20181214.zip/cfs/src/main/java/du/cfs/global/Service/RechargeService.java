package du.cfs.global.Service;

import du.cfs.global.Enums.StatusType;
import du.cfs.global.db.GateList;
import du.cfs.global.db.RechargeOrder;

public interface RechargeService {

	RechargeOrder GetRechargeOrder(int id);

	RechargeOrder save(RechargeOrder r);

	RechargeOrder InsertOrder(GateList gateList, RechargeOrder rechargeOrder);

	int UndateRechareOrderGateStatus(int id, StatusType status);
}
