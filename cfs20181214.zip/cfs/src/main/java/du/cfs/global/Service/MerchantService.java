package du.cfs.global.Service;


import du.cfs.global.db.Merchant;

public interface MerchantService {
	Merchant getMerchant(String merCode);
	Merchant save(Merchant merConfig);
}
