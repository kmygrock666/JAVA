package du.cfs.global.Service;


import du.cfs.global.Enums.PayType;
import du.cfs.global.db.MerGateConfig;


public interface MerGateConfigService {
	MerGateConfig getMerGateConfig(String merCode);
	
	MerGateConfig getMerGateConfigByPayType(String merCode,PayType payType);
	
	MerGateConfig save(MerGateConfig merGateConfig);
}
