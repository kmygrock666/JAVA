package du.cfs.global.Service;

import du.cfs.global.db.GateInfo;

public interface GateInfoService {
	GateInfo getGateInfo(int id);
	GateInfo save(GateInfo gateType);
}
