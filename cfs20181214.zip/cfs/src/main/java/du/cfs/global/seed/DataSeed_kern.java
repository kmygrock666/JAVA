package du.cfs.global.seed;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import du.cfs.global.Repository.MerchantRepository;
import du.cfs.global.Enums.BankType;
import du.cfs.global.Enums.PayType;
import du.cfs.global.Enums.StatusType;
import du.cfs.global.Repository.MerGateConfigRepository;
import du.cfs.global.Service.GateInfoService;
import du.cfs.global.Service.GateListService;
import du.cfs.global.Service.RechargeService;
import du.cfs.global.Unit.DateUnit;
import du.cfs.global.db.GateInfo;
import du.cfs.global.db.GateList;
import du.cfs.global.db.Merchant;
import du.cfs.global.db.MerGateConfig;
import du.cfs.global.db.RechargeOrder;

import du.cfs.global.db.RechargeOrderSubInfo;

@Configuration
public class DataSeed_kern {
	@Autowired
	RechargeService rechargeService;
	@Autowired
	GateInfoService gateInfoService;
	@Autowired
	GateListService gateListService;
	@Autowired
	MerGateConfigRepository merGateConfigRepository;
	@Autowired
	MerchantRepository merConfigRepository;

	@Bean
	public DataSeed_kern GetDataSeed() {
		return new DataSeed_kern();
	}

	private String sGatIp = "localhost:8082/gate/recharge";
	private String sC_name = "新派支付";
	private String sE_name = "XPPAY";

	public int SetGateInfoTestSeed() {
		System.out.println("=========SetTypeTestSeed=========");
		GateInfo gateInfo = new GateInfo();
		gateInfo.setId(1);
		gateInfo.setGatIp(sGatIp);
		gateInfo.setC_name(sC_name);
		gateInfo.setE_name(sE_name);
		gateInfo.setPayAgent_feedback_proc("PA_PROC");
		gateInfo.setRecharge_feedback_proc("RC_PROC");
		gateInfo = gateInfoService.save(gateInfo);
		return gateInfo.getId();
	}

	private String sCfs_code = "123456788";
	private String sMd5 = "123456788";
	private String sRsa = "123456788";

	public int SetGateListTestSeed(int gateInfoId) {
		System.out.println("=========SetListTestSeed=========");
		GateInfo gateInfo = gateInfoService.getGateInfo(gateInfoId);
		GateList gateList = new GateList();
		gateList.setId(2);
		gateList.setCfs_code(sCfs_code);
		gateList.setGateInfo(gateInfo);
		gateList.setMd5(sMd5);
		gateList.setRsa(sRsa);
		gateList.setGatePayType(PayType.QUICK_PAY);
		gateList.setEnable(true);
		gateList = gateListService.save(gateList);
		return gateList.getId();
	}

	private String sMerCode = "DU00001";

	public int SetRechargeTestSeed(Merchant mc, int gateListId) {
		System.out.println("=========SetRechargeTestSeed=========");
		GateList gateList = gateListService.getGateList(gateListId);
		// RechargeOrderSubInfo rechargeOrderSubInfo = null;
		RechargeOrderSubInfo rechargeOrderSubInfo = new RechargeOrderSubInfo();
		rechargeOrderSubInfo.setMerAccount("ABCDE");
		rechargeOrderSubInfo.setMerAccountName("DEF");
		rechargeOrderSubInfo.setMerPhone("POIWE");
		rechargeOrderSubInfo.setMerBankId(BankType.ABC);

		RechargeOrder rechargeOrder = new RechargeOrder();
		rechargeOrder.setMerchant(mc);

		String sMerOrderNumber = "DU" + DateUnit.TimestampToStr(DateUnit.GetTimestamp(0), "yyyyMMddHHmmss");

		rechargeOrder.setMerOrderNumber(sMerOrderNumber);
		rechargeOrder.setMerAmount(10);
		rechargeOrder.setMerPayType(PayType.QUICK_PAY);
		rechargeOrder.setMerDesc("desc");
		rechargeOrder.setMerSyncNotifyUrl("http://www.google.com.tw/");
		rechargeOrder.setMerUnsyncNotifyUrl("http://www.google.com.tw/");
		rechargeOrder.setMerTransDate(new Date());

		if (rechargeOrderSubInfo != null)
			rechargeOrder.setRechargeOrderSubInfo(rechargeOrderSubInfo);

		RechargeOrder ro = rechargeService.InsertOrder(gateList, rechargeOrder);
		ro.setMerStatus(StatusType.UNPAY);
		ro.setGateStatus(StatusType.UNPAY);
		ro = rechargeService.save(ro);

		return ro.getId();
	}

	public Merchant SetMerConfigTestSeed() {
		Merchant mc = new Merchant();
		mc.setEnable(true);
		mc.setMd5Key("jLl8pWoMLOS9sEe1aXW8mblYaqn4bVW4");
		mc.setRsaKey("jLl8pWoMLOS9sEe1aXW8mblYaqn4bVW4");
		mc.setApiIp("0:0:0:0:0:0:0:1");
		mc.setBackstageIp("0:0:0:0:0:0:0:1");
		mc.setMerCode(sMerCode);
		return merConfigRepository.save(mc);
	}

	public int SetMerGateConfigTestSeed(Merchant mc, int gateListId) {
		GateList gateList = gateListService.getGateList(gateListId);
		MerGateConfig merGateConfig = new MerGateConfig();
		merGateConfig.setEnable(true);
		merGateConfig.setGateList(gateList);
		merGateConfig.setPayType(gateList.getGatePayType());
		merGateConfig.setMerchant(mc);
		merGateConfig = merGateConfigRepository.save(merGateConfig);
		return merGateConfig.getId();

	}

}
