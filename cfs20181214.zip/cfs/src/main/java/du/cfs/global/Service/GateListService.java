package du.cfs.global.Service;

import du.cfs.global.db.GateList;

public interface GateListService {
	GateList getGateList(int id);
	GateList save(GateList gateList);
}
