package du.cfs.global.Enums;

public enum PayType{
	UNSET(-1), 
	UNIONPAY(0), 
	SCAN_WECHAT(21), SCAN_QQ(22), SCAN_ALIPAY(23),SCAN_UNIONPAY(24),
	QUICK_PAY(51), WAP_QQ(52), WAP_WECHAT(53),WAP_ALIPAY(54);
	private final int id;

	PayType(int id) {
		this.id = id;
	}

	public int getValue() {
		return id;
	}
}