package du.cfs.global.db;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

//Merchant
//商戶通道設定
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merCode"}) })
public class Merchant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	// 商戶編號
	@Column(updatable = false, length = 50, nullable = false)
	private String merCode;
	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	@Column(nullable = false)
	private String md5Key;
	private String rsaKey;

	private String apiIp;
	private String backstageIp;

	@OneToMany(mappedBy = "merchant", cascade = { CascadeType.PERSIST}, fetch = FetchType.LAZY)
	private List<MerGateConfig> MerGateConfig= new ArrayList<MerGateConfig>();


	@OneToMany(mappedBy = "merchant", cascade = { CascadeType.PERSIST}, fetch = FetchType.LAZY)
	private List<RechargeOrder> RechargeOrder= new ArrayList<RechargeOrder>();


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getMerCode() {
		return merCode;
	}


	public void setMerCode(String merCode) {
		this.merCode = merCode;
	}


	public boolean isEnable() {
		return enable;
	}


	public void setEnable(boolean enable) {
		this.enable = enable;
	}


	public String getMd5Key() {
		return md5Key;
	}


	public void setMd5Key(String md5Key) {
		this.md5Key = md5Key;
	}


	public String getRsaKey() {
		return rsaKey;
	}


	public void setRsaKey(String rsaKey) {
		this.rsaKey = rsaKey;
	}


	public List<MerGateConfig> getMerGateConfig() {
		return MerGateConfig;
	}


	public void setMerGateConfig(List<MerGateConfig> merGateConfig) {
		MerGateConfig = merGateConfig;
	}


	public List<RechargeOrder> getRechargeOrder() {
		return RechargeOrder;
	}


	public void setRechargeOrder(List<RechargeOrder> rechargeOrder) {
		RechargeOrder = rechargeOrder;
	}


	public String getApiIp() {
		return apiIp;
	}


	public void setApiIp(String apiIp) {
		this.apiIp = apiIp;
	}


	public String getBackstageIp() {
		return backstageIp;
	}


	public void setBackstageIp(String backstageIp) {
		this.backstageIp = backstageIp;
	}






	
}
