package du.cfs.global.db;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

//通道類型
@Entity
public class GateInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	// 通道英文名稱
	@Column(length = 20, nullable = false)
	private String E_name;
	// 通道中文名稱
	@Column(length = 20, nullable = false)
	private String C_name;
	// Recharges feedback 處理程序
	@Column(length = 50, nullable = false)
	private String Recharge_feedback_proc;
	// Recharges feedback 處理程序
	@Column(length = 50, nullable = false)
	private String PayAgent_feedback_proc;

	@Column(length = 50, nullable = false)
	private String gatIp;
	
	@OneToMany(mappedBy = "gateInfo", cascade = { CascadeType.PERSIST}, fetch = FetchType.EAGER)
	private List<GateList> gateList = new ArrayList<GateList>();
	public GateInfo() {

	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getE_name() {
		return E_name;
	}
	public void setE_name(String e_name) {
		E_name = e_name;
	}
	public String getC_name() {
		return C_name;
	}
	public void setC_name(String c_name) {
		C_name = c_name;
	}
	public String getRecharge_feedback_proc() {
		return Recharge_feedback_proc;
	}
	public void setRecharge_feedback_proc(String recharge_feedback_proc) {
		Recharge_feedback_proc = recharge_feedback_proc;
	}
	public String getPayAgent_feedback_proc() {
		return PayAgent_feedback_proc;
	}
	public void setPayAgent_feedback_proc(String payAgent_feedback_proc) {
		PayAgent_feedback_proc = payAgent_feedback_proc;
	}


	public List<GateList> getGateList() {
		return gateList;
	}
	public void setGateList(List<GateList> gateList) {
		this.gateList = gateList;
	}
	public String getGatIp() {
		return gatIp;
	}
	public void setGatIp(String gatIp) {
		this.gatIp = gatIp;
	}
	

/*
	public String TransformBankid(BankType bankType) {
		String id = bankTypeMap.get(bankType);
		if(id==null)
			return bankType.toString();
		return id;

	}
	Map<BankType, String> bankTypeMap = new EnumMap<BankType, String>(BankType.class);
	public Gate_type() {
		bankTypeMap.put(BankType.ABC, "ABC");
		bankTypeMap.put(BankType.BCOM, "BCOM");
	}
	*/
	
	



}
