package du.cfs.global.db;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import du.cfs.global.Enums.PayType;



// 通道清單
@Entity
public class GateList {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@ManyToOne
	private GateInfo gateInfo;
	// 第三方商號
	@Column(length = 20, nullable = false)
	private String cfs_code;
	@Column(nullable = false)
	private String md5;
	@Column(nullable = false)
	private String rsa;
	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	
	@OneToMany(mappedBy = "gateList", cascade = { CascadeType.PERSIST}, fetch = FetchType.LAZY)
	private List<RechargeOrder> rechargeOrder = new ArrayList<RechargeOrder>();
	

	@OneToMany(mappedBy = "gateList", cascade = { CascadeType.PERSIST}, fetch = FetchType.LAZY)
	private List<MerGateConfig> merGateConfig= new ArrayList<MerGateConfig>();
	
	@Column(updatable = false, nullable = false)
	PayType gatePayType = PayType.UNSET;
	
	public GateList() {

	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public GateInfo getGateInfo() {
		return gateInfo;
	}
	public void setGate_type(GateInfo gate_type) {
		this.gateInfo = gate_type;
	}
	public String getCfs_code() {
		return cfs_code;
	}
	public void setCfs_code(String cfs_code) {
		this.cfs_code = cfs_code;
	}
	public String getMd5() {
		return md5;
	}
	public void setMd5(String md5) {
		this.md5 = md5;
	}
	public String getRsa() {
		return rsa;
	}
	public void setRsa(String rsa) {
		this.rsa = rsa;
	}
	public boolean isEnable() {
		return enable;
	}
	public void setEnable(boolean enable) {
		this.enable = enable;
	}



	public List<RechargeOrder> getRechargeOrder() {
		return rechargeOrder;
	}
	public void setRechargeOrder(List<RechargeOrder> rechargeOrder) {
		this.rechargeOrder = rechargeOrder;
	}
	public List<MerGateConfig> getMerGateConfig() {
		return merGateConfig;
	}
	public void setMerGateConfig(List<MerGateConfig> merGateConfig) {
		this.merGateConfig = merGateConfig;
	}
	


	
	public PayType getGatePayType() {
		return gatePayType;
	}
	public void setGatePayType(PayType gatePayType) {
		this.gatePayType = gatePayType;
	}
	public void setGateInfo(GateInfo gateInfo) {
		this.gateInfo = gateInfo;
	}
	
	
	
}
