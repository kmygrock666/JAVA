package du.cfs.global.Service;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Enums.PayType;
import du.cfs.global.Enums.StatusType;
import du.cfs.global.Repository.RechargeOrderRepository;
import du.cfs.global.Unit.OrderCode;
import du.cfs.global.db.GateList;
import du.cfs.global.db.RechargeOrder;

@Service
public class RechargeServiceImpl implements RechargeService {

	@Autowired
	private RechargeOrderRepository repository;

	public RechargeOrder GetRechargeOrder(int id) {
		Optional<RechargeOrder> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	private static String codeMap = "vwA0xyBzWXDZQbUcMOd7Eqrst1SunH2PoL6eTY4i3GkIfgRJKjChlmNVa5p";
	private static String codeKey = "F";

	public RechargeOrder InsertOrder(GateList gateList, RechargeOrder rechargeOrder) {
		if (gateList == null || rechargeOrder.getMerPayType() == PayType.UNSET)
			return null;
		if (gateList.getGatePayType() != rechargeOrder.getMerPayType())
			return null;
		try {
			rechargeOrder.setGateList(gateList);
			rechargeOrder = repository.save(rechargeOrder);
			String orderCode = OrderCode.IntToCodeString(codeMap, codeKey, (int) rechargeOrder.getId(), 20);
			rechargeOrder.setCfsOrderNumber(orderCode);
			rechargeOrder = repository.save(rechargeOrder);
			return rechargeOrder;
		} catch (Exception e) {
			return null;
		}

	}

	public int UndateRechareOrderGateStatus(int id, StatusType status) {
		RechargeOrder ro = GetRechargeOrder(id);
		ro.setGateStatus(status);
		ro.setGatePayTime(new Date());
		ro = repository.save(ro);
		return (int) ro.getId();
	}

	public RechargeOrder save(RechargeOrder r) {
		return repository.save(r);
	}

}
