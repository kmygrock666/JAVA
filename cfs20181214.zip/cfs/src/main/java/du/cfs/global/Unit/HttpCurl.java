package du.cfs.global.Unit;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import du.cfs.controller.Core;
import du.cfs.global.Unit.CURL.RequestData;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HttpCurl {

	public static JSONObject  post (final Object  data, final String URL) {
		if (!StringUtils.isNotBlank(URL)) {return null;}
		
		ObjectMapper objectMapper = new ObjectMapper();
//		 objectMapper.setSerializationInclusion(Inclusion.NON_EMPTY);
		String requestJson = null;
		try {
			requestJson = objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HttpHeaders headers = new HttpHeaders();//設定表頭
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
        System.out.print(JSON.toJSONString(entity,true));
        SimpleClientHttpRequestFactory requestFactory = new  SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(180000);// 设置超时
        requestFactory.setReadTimeout(180000);
        
        RestTemplate restTemplate = new RestTemplate(requestFactory);
        ResponseEntity<String> response = restTemplate.exchange(URL, HttpMethod.POST, entity, String.class);
        
        JSONObject body = new JSONObject().parseObject(response.getBody());
        log.info("body:{}", body);
        return body;
	}
	
	
	public static JSONObject get(final String URL) {
		 
		if (!StringUtils.isNotBlank(URL)) {return null;}
		
		SimpleClientHttpRequestFactory requestFactory = new  SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(180000);// 设置超时
        requestFactory.setReadTimeout(180000);
        
        RestTemplate restTemplate = new RestTemplate(requestFactory);
        ResponseEntity<String> response = restTemplate.getForEntity(URL, String.class);
        Integer code = response.getStatusCode().value();

        JSONObject body = new JSONObject().parseObject(response.getBody());
        log.info("body:{}", body);
        return body;
	 
	}

}
