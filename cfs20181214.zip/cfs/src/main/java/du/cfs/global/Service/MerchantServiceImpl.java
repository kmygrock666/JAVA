package du.cfs.global.Service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import du.cfs.global.Repository.MerchantRepository;
import du.cfs.global.db.Merchant;
@Service
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	MerchantRepository repository;

	public Merchant getMerchant(String merCode) {
		Optional<Merchant> optional = repository.findBymerCode(merCode);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public Merchant save(Merchant merConfig) {
		return repository.save(merConfig);
	}
}
