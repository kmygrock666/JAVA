package com.spring.security;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.rememberme.PersistentRememberMeToken;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.model.RememberToken;
import com.spring.service.CommerceService;
import com.spring.util.JsonUtils;

import jdk.internal.jline.internal.Log;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class PersistentTokenService implements PersistentTokenRepository{
	
	@Autowired
    private RedisTemplate redisTemplate;
	
	@Autowired
    private CommerceService commerceService;
	
	@Override
	public void createNewToken(PersistentRememberMeToken token) {
		// TODO Auto-generated method stub
		RememberToken persistentLogin = new RememberToken();
        persistentLogin.setUsername(token.getUsername());
        persistentLogin.setSeries(token.getSeries());
        persistentLogin.setToken(token.getTokenValue());
        persistentLogin.setLast_used(token.getDate());
        redisTemplate.opsForValue().set("user_remember:"+token.getSeries(), JsonUtils.toJson(persistentLogin), 30, TimeUnit.DAYS);
        
//        commerceService.save(persistentLogin);
		log.info("創建TOKEN-------------------------");
	}

	@Override
	public void updateToken(String series, String tokenValue, Date lastUsed) {
		// TODO Auto-generated method stub
		String payload = (String) redisTemplate.opsForValue().get("user_remember:"+series);
//		String payload = (String) redisTemplate.opsForHash().get("user_:"+series,"token");
        try {
            RememberToken rememberToken = JsonUtils.fromJson(payload, RememberToken.class);
            rememberToken.setToken(tokenValue);
            rememberToken.setLast_used(lastUsed);
//          redisTemplate.opsForValue().set(series, JsonUtils.toJson(rememberToken), 30, TimeUnit.DAYS);
//            commerceService.updateByPK(tokenValue, lastUsed, series);
            redisTemplate.opsForHash().putIfAbsent("user_remember:"+series, "token", JsonUtils.toJson(rememberToken));
            log.debug("Remember me token is updated. seried={}", series);
        } catch (Exception e) {
            log.error("Persistent token is not valid. payload={}, error={}", payload, e);
        }
		log.info("更新TOKEN---------------------------------");
	}

	@Override
	public PersistentRememberMeToken getTokenForSeries(String seriesId) {
		// TODO Auto-generated method stub
		String payload = (String) redisTemplate.opsForValue().get("user_remember:"+seriesId);
//		String payload = (String) redisTemplate.opsForHash().get("user_:"+seriesId,"token");
//		RememberToken rememberMe = commerceService.findBySeries(seriesId);
        if (payload == null) return null;
        try {
            RememberToken rememberToken = JsonUtils.fromJson(payload, RememberToken.class);
            PersistentRememberMeToken token = new PersistentRememberMeToken(
                    rememberToken.getUsername()
                    , seriesId
                    , rememberToken.getToken()
                    , rememberToken.getLast_used());
            return token;
        } catch (Exception e) {
            log.error("Persistent token is not valid. payload={}, error={}", payload, e);
            return null;
        }
	}

	@Override
	public void removeUserTokens(String username) {
		// TODO Auto-generated method stub
		log.info("移除TOKEN--------------------------------");
	}

}
