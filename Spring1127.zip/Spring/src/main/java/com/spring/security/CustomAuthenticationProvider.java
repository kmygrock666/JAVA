package com.spring.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.spring.model.Commerce;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class CustomAuthenticationProvider implements AuthenticationProvider{

	@Autowired
    private CustomUserDetailsServiceImpl userDetailService;
	
	@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		// TODO Auto-generated method stub

		String username = authentication.getName();// 這個獲取表單輸入中返回的用户名;
		String password =  authentication.getCredentials().toString();// 這個是表單中輸入的密碼；

        UserDetails userInfo = userDetailService.loadUserByUsername(username);
        
        if(!bCryptPasswordEncoder.matches(password, userInfo.getPassword())) {
//        	System.out.println("DATABASE "+userInfo.getPassword());
//        	System.out.println("INPUT "+password);
            throw new BadCredentialsException("Wrong password.");
        }
        log.info("Authentication success 認證成功");
        return new UsernamePasswordAuthenticationToken(userInfo, null, userInfo.getAuthorities());
	}

	@Override
	public boolean supports(Class<?> authentication) {
		// TODO Auto-generated method stub
		//同意執行
		return true;
	}

}
