package du.cfs.global.db.GM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Gen.cfsEnum.ServiceType;
import du.cfs.global.Gen.cfsEnum.SttleStatus;
import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "gm_gate_id", "gateOrderNumber", "serviceType" }) })
public class GmCashFlow {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	private GmMerchant mer;

	@ManyToOne
	private GmGate gmGate;

	@Column(length = 50, nullable = false)
	private String gateOrderNumber = "";

	@Column(length = 50, nullable = false)
	private String kernOrderNumber = "";

	@Column(length = 50, nullable = false)
	private String merOrderNumber = "";

	@Column(length = 50, nullable = false)
	private int merAmount;

	private int befoSttledAmount;
	private int afterSttledAmount;

	private SttleStatus sttleStatus;

	@Column(length = 50, nullable = false)
	private ServiceType serviceType;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;

	public GmCashFlow() {

	}

	@PrePersist
	void createdAt() {
		this.createdAt = new Date();
	}

}
