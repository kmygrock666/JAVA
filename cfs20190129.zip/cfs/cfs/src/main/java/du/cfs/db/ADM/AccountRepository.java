package du.cfs.db.ADM;

import java.util.Collection;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface AccountRepository extends JpaRepository<Account, Long>{
//	Commerce findByUsername(String username);
	
	Optional<Account> findByUsername(String username);
	
	
	
//	@Modifying
//	@Transactional
//	@Query("update Commerce c set c.role_id = ?1 where id = ?2")
//	int updateByJPQL(int role_id,int id);
//	
//	@Modifying
//	@Transactional
//	@Query("delete from Commerce c where c.id = ?1")
//	int deleteByJPQL(int id);
//	
//	@Modifying
//	@Transactional
//	@Query("update from Commerce c set c.password = ?1 ,c.role_id = ?2,c.com04 = ?3 where c.id = ?4")
//	int updateInfoByJPQL(String password,int role_id,String com04,int id);
	
	/**
	 * 查詢用戶權限
	 * @param username
	 * @return
	 */
//	@Query(value="select p.url,p.name,p.menu,p.menu_show from commerce as c "+
//				"join commerce_roles as cr on c.id = cr.user_id "+
//				"join role_permissions as rp on cr.role_id = rp.role_id "+
//				"join permission as p on p.id = rp.permissions_id "+
//				"where c.username = ?1",nativeQuery=true)
//	Collection<MenuPermission> findMenuByUsername(String username);
//	
//	interface MenuPermission {
//		String getUrl();
//		
//        String getName();
//
//        Long getMenu();
//        
//        String getMenu_show();
//
//        
//    }
}
