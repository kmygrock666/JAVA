package du.cfs.controller.action.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class AuthPermissionSave extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	MenuService menuService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		String code =  getParam("p_code");
		String name =  getParam("p_title");
		String url =  getParam("p_url");
		Long pid =  Long.parseLong(getParam("p_parent"));

		Permission permission = permissionService.findByPermission(code);
		if(permission == null)
			permission = new Permission();
		permission.setPermission(code);
		permission.setTitle(name);;
		permission.setUrl(url);
		permission.setPid(pid);

		permissionService.save(permission);
		
		System.out.println("Save Success");
		return redirect("/system/AuthPermission");
	}
	
}
