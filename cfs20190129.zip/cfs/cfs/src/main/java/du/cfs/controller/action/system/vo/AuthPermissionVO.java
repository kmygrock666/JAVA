package du.cfs.controller.action.system.vo;

import java.time.LocalDateTime;

import javax.persistence.Column;

import lombok.Data;

@Data
public class AuthPermissionVO {
	private Long id;
	 //权限名称
	 private String title;
	 //权限描述
	 private String permission;
	 //授权链接
	 private String url;
	 
	 private Long pid;
}
