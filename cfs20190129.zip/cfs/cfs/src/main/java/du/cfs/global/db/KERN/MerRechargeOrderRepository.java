package du.cfs.global.db.KERN;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerRechargeOrderRepository extends JpaRepository<MerRechargeOrder, Integer> {

	Page<MerRechargeOrder> findAll(Pageable pageable);
	
	Optional<MerRechargeOrder> findById(int id);
	
	/*
	 * List<Book2> findByAuthor(String author); List<Book2>
	 * findByAuthorAndStatus(String author,int status); List<Book2>
	 * findByDescriptionEndsWith(String des); List<Book2>
	 * findByDescriptionContains(String des);
	 * 
	 * //@Query("select b form Book b where length(b.name) > ?1")
	 * 
	 * @Query(value="select * form book where length(name) > ?1", nativeQuery= true)
	 * List<Book2> finByJPQL(int len);
	 * 
	 * 
	 * @Transactional
	 * 
	 * @Modifying
	 * 
	 * @Query("update Book2 b set b.status = ?1 where b.id = ?2") int
	 * updateByJPQL(int status,long id);
	 * 
	 * 
	 * @Transactional
	 * 
	 * @Modifying
	 * 
	 * @Query("delete from Book2 b where b.id = ?1") int deleteByJPQL(long id);
	 */
}
