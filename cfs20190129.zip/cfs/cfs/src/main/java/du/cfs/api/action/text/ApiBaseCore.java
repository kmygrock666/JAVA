package du.cfs.api.action.text;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import du.cfs.common.util.RegiserBean;
import du.cfs.controller.Core;
import du.cfs.security.AdmUserPrinciple;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ApiBaseCore {
	
	@Autowired
	private RegiserBean regiser;
	
	@Autowired
    BeanFactory beanFactory;
	
	public Object runModel(String sub,String action,Map<String,Object> data) {
		try {
			//實體class
			Class model_class = Class.forName("du.cfs.controller.action." + sub + "." + action);
			Object classObj2;
			//取得bean
			if (beanFactory.containsBean(action)) {
				classObj2 = beanFactory.getBean(model_class);
			}else {
				classObj2 = regiser.registerBean(action, model_class);
			}
			 
			log.info("=============In ApiCore Class============");
			
			//產生method，並呼叫
			Method setInit = model_class.getMethod("init", new Class[]{Map.class});
			Object getInit = setInit.invoke(classObj2, new Object[]{data});
			//產生method，並呼叫 
			Method setInfo = model_class.getMethod("execute", null);
			Object getReturn = setInfo.invoke(classObj2, null);
			
			//移除bean
//			baseCore.deleteBean(action);
			return getReturn;
		} catch( ClassNotFoundException e ) {
			//my class isn't there!
			log.error("Not Path : {}", e.getMessage());
			throw new RuntimeException("Not Path : " + e.getMessage());
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 B " + e.getMessage());
			throw new RuntimeException("初始化錯誤 B " + e.getMessage());
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 C " + e.getMessage());
			throw new RuntimeException("初始化錯誤 C " + e.getMessage());
		}  catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 F " + e.getMessage());
			throw new RuntimeException("初始化錯誤 F " + e.getMessage());
		}
		
	}

}
