package du.cfs.global.Gen;

import java.util.TreeMap;

import lombok.Data;

@Data
public class Struce_Input_JumpProxy {
	public enum METHOD {
		POST, GET
	};
	private String url;
	private METHOD method;
	private TreeMap<String, String> param;
}
