$(function() {
    console.log( "ready!" );
//    $('.modal').on('hidden.bs.modal', function(){
//        $(this).find('form')[0].reset();
//    });
});
//vue register
Vue.component('m-content',{
	template: "<div id='diaLoad'></div>",
});

//var model2 = new Vue({
//    el: '#iview-modal',
//    data: {
//        visible: false,
//        contentName : "m-content"
//    },
//    methods: {
//        show: function () {
//            this.visible = true;
//        },
//    	hide: function() {
//    		this.visible = false;
//    	}
//    }
//})

Vue.component('iview-modal', {
    props:['componetName','data'],
    template: '#iview-modal',
    data() {
        return{
        	visible: false,
        }
    },
    methods: {
        show: function () {
            this.visible = true;
        },
    	close(){
    		this.visible = false;
    	}
    }
});
//========================
function logout(){
	parent.location.href = "logout";
}

function getLoad(url){

	$("#container").load(url,function(res,status,xhr){
		console.log(res);
		console.log(status);
		console.log(xhr);
	});
}

function openWin(page) {
	this.model2.contentName = "m-content";
	Vue.http.get(page).then(function(success) {
		$('#diaLoad').html(success.body);
		$('#diaLoad').children("#delT").remove();
		this.model2.show();
	},function(error){
		if(!error.body.success)
			parent.location.href = '';
	})
}

function append(){
	return $('#diaLoad');
}

function dia(el){

	Vue.component(el,{
		template: "#"+el,
		methods:{
			formSubmit: function(){

				var formData =new FormData(this.$refs[el]);
				var url = this.$refs[el].action;
				var type = this.$refs[el].method;
				let config = {headers:{'Content-Type':'multipart/form-data'}};
				
				if(type.toLowerCase() == 'post'){
					this.$http.post(url,formData,config).then(function(success){
//						console.log("success");
//						console.log(res);
						this.$Message.success('新增成功');
						closeDialog();
						refreshView(success.body);
					},function(error){
						// error callback
//						console.log("error");
						this.$Message.success('新增失敗');
						closeDialog();
						refreshView(error.body);
					}).finally(function(){
						// finally callback
//						closeDialog();
					})
				}else{
					this.$http.get(url,{params:  formData}).then(function(success){
//						console.log(res);
						closeDialog();
						refreshView(success.body);
					},function(error){
						// error callback
						closeDialog();
						refreshView(error.body);
					}).finally(function(){
						// finally callback
//						closeDialog();
					})
				}

			},
			//隱藏
			hideForm: function(){
				//清空表單
//				this.$refs['dataForm'].resetFields();
				closeDialog();
			}
		}
		
		
	});
	
	this.model2.contentName = el;
	this.model2.show();
	
}

function showDialog(el){
	this.model2.contentName = el;
	this.model2.show();
}

function closeDialog(){
	this.model2.hide();
}

function refreshView(respond){
	$("#container").html(respond);
}

function post(url,d){
	Vue.http.post(url,d).then(function(success) {
		
	},function(error){
		
	})
}

function get(url,d=''){
	Vue.http.get(url,{params:d}).then(function(success) {
//		console.log("success");
//		console.log(success);
		refreshView(success.body);
	},function(error){
//		console.log("error");
		if(!error.body.success)
			parent.location.href = '';
		refreshView(error.body);
	})
}

function getMethodRes(url){
	Vue.http.get(url).then(function(success) {
		return success;
	},function(error){
		if(!error.body.success)
			parent.location.href = '';
		refreshView(error.body);
	})
}


//TODO form to FormData 轉換
function toFormData(obj, form, namespace) {
  let fd = form || new FormData();
  let formKey;
  
  for(let property in obj) {
    if(obj.hasOwnProperty(property) && obj[property]) {
      if (namespace) {
        formKey = namespace + '[' + property + ']';
      } else {
        formKey = property;
      }
     
      // if the property is an object, but not a File, use recursivity.
      if (obj[property] instanceof Date) {
        fd.append(formKey, obj[property].toISOString());
      }
      else if (typeof obj[property] === 'object' && !(obj[property] instanceof File)) {
        toFormData(obj[property], fd, formKey);
      } else { // if it's a string or a File object
        fd.append(formKey, obj[property]);
      }
    }
  }
  
  return fd;
}

//日期格式化
function formatDate (date, fmt) {
  let o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'S': date.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  for (var k in o) {
      if (new RegExp('(' + k + ')').test(fmt)) {
          fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
      }
  }
  return fmt
}

