//package du.cfs.common.service;
//
//import java.time.LocalDateTime;
//import java.util.Collection;
//import java.util.Date;
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import du.cfs.common.model.RememberToken;
//import du.cfs.common.model.Role;
//import du.cfs.common.model.SysConfig;
//import du.cfs.common.repository.RememberTokenRepository;
//import du.cfs.common.repository.RoleRepository;
//import du.cfs.common.repository.SysConfigRepository;
//import du.cfs.db.ADM.Account;
//import du.cfs.db.ADM.AccountRepository;
//
//
//@Service
//public class SysConfigService {
//	@Autowired
//    private SysConfigRepository sysConfigRepository;
//	
//	@Autowired
//    private RoleRepository roleRepository;
//	
//	@Autowired
//    private RememberTokenRepository rememberTokenRepository;
//	
////	public Commerce GetUserByName(String name) {
////		return commerceRepository.findByUsername(name);
////	}
//	/**
//	 * 	建立TOKEN
//	 * @param token
//	 */
//	public void save(RememberToken token) {
////		return rememberTokenRepository.insert(token.getToken(),token.getLast_used(),token.getSeries());
//		 rememberTokenRepository.save(token);
//	}
//	/**
//	 * 	更新TOKEN
//	 * @param tokenValue
//	 * @param lastUsed
//	 * @param series
//	 * @return
//	 */
//	public int updateByPK(String tokenValue, Date lastUsed, String series) {
//		return rememberTokenRepository.updateByPK(tokenValue,lastUsed,series);
//	}
//	
//	public SysConfig findByToken(String token){
//		return sysConfigRepository.findByToken(token);
//	}
//	
//	
//
//	
//	
//}
