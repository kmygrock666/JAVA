package du.cfs.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Service;

import du.cfs.common.model.Permission;
import du.cfs.common.service.PermissionService;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import lombok.extern.slf4j.Slf4j;
/**
 * 權限配置資源管理
 * @author RD00
 * @Description 
 * 實現FilterInvocationSecurityMetadataSource
 * 啟動時就去加載了所有權限列表
 * 判斷用戶訪問資源是否在保護的範圍內
 */
@Slf4j
@Service
public class CustomFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource{
	
	 @Autowired
	 private PermissionService permissionService;
	 
	 private FilterInvocationSecurityMetadataSource  superMetadataSource;
	
	/**
	 * 儲存相關權限
	 * todo : 權限若修改新增，無法及時更新
	 */
	private Map<RequestMatcher, Collection<ConfigAttribute>> requestMap = null;
	
	public void loadResourceDefine() {
		Map<RequestMatcher, Collection<ConfigAttribute>> map = new HashMap<>();
        //用来存储权限的容器
        ConfigAttribute cfg;
        //从数据库查询全部的权限信息
		List<Permission> permissions = permissionService.findAll();

		for(Permission permission : permissions) {
			if(permission.getPid().equals(0L)) continue;
			AntPathRequestMatcher matcher = new AntPathRequestMatcher(permission.getUrl());
            cfg = new SecurityConfig(permission.getPermission());

            ArrayList<ConfigAttribute> configs = new ArrayList<>();
            configs.add(cfg);            
            map.put(matcher, configs);

        }
		log.info("加载数据库中全部权限==>>>loadResourceDefine");
		this.requestMap = map;
	}
	
	@Override
	public Collection<ConfigAttribute> getAttributes(Object object) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		if(requestMap == null)  loadResourceDefine();
		log.info("執行權限====>>>getAttributes");
		// object中包含用戶請求的請求信息
		FilterInvocation fi = (FilterInvocation) object;
		HttpServletRequest request = fi.getHttpRequest();
//
        for (Map.Entry<RequestMatcher, Collection<ConfigAttribute>> entry : requestMap
                .entrySet()) {
        	//请求路径和requestMap中的路径进行匹配，成功了就从requestMap中获取对应路径的权限
            if (entry.getKey().matches(request)) {
                return entry.getValue();
            }
        }
        log.info("不存在於權限表中====>>>{}",request.getRequestURI());
        return null;
    //  返回代码定义的默认配置
//        return superMetadataSource.getAttributes(object);
//		System.out.println("MyInvocationSecurityMetadataSourceService = " + object);
//        Collection<ConfigAttribute> co = new ArrayList<>();
//        co.add(new SecurityConfig("null"));
//        return co;

	}

	@Override
	public Collection<ConfigAttribute> getAllConfigAttributes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return true;
	}

}
