package du.cfs.config.exception;

import org.springframework.validation.Errors;

import lombok.Data;

@Data
public class InvalidRequestException extends RuntimeException{
	private Errors errors;
	
	public InvalidRequestException(String message,Errors error) {
		super(message);
		this.errors = error;
	}
}
