package du.cfs.global.db.GM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "gateIp", "gatePort" }) })
public class GmGate {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	@Column(length = 50)
	private String gateCode;
	@Column(length = 50, nullable = false)
	private String gateIp;
	@Column(length = 5, nullable = false)
	private String gatePort;
	@Column(length = 50, nullable = false)
	private String gateBn;
	@Column(length = 50, nullable = false)
	private String md5Key;
}