package du.cfs.global.db.GATE;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GateRechargeProcResultServiceImpl implements GateRechargeProcResultService {

	@Autowired
	private GateRechargeProcResultRepository repository;


	@Override
	public GateRechargeProcResult GetGateRechargeProcResult(int id) {
		Optional<GateRechargeProcResult> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}


	@Override
	public GateRechargeProcResult saveNuAutoOrderNumber(GateRechargeProcResult gateRechargeProcResult) {
		return repository.save(gateRechargeProcResult);
	}



}
