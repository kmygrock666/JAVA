package du.cfs.global.db.GATE;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Gen.cfsEnum.ProcResultState;
import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "thirdBN", "gateOrderNumber" }) })
public class GateRechargeFeedbackOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
	@Column(updatable = false, nullable = false)
	private int merAmount;
	@Column(length = 50)
	private String thirdBN;
	@Column(length = 50)
	private String gateOrderNumber;
	@Temporal(TemporalType.TIMESTAMP)
	private Date thirdTranDate;
	@Column(length = 50)
	private String thirdOrderNumber;

	@Column(length = 50)
	private String gateCode;
	private ProcResultState procResultStateGate = ProcResultState.UNSET;
	private ProcResultState procResultStateGm = ProcResultState.UNSET;
	private ProcResultState procResultStateKern = ProcResultState.UNSET;

	@OneToOne
	GateRechargeNotify gateRechargeNotify;

	private String echoToThird;

	public GateRechargeFeedbackOrder() {
	}

	// ----------------------------------------------------------
	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------
}

