package du.cfs.global.db.GM;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class GmMerGateMapServiceImpl implements GmMerGateMapService {

	@Autowired
	private GmMerGateMapRepository repository;

	
	@Override
	public GmMerGateMap save(GmMerGateMap r) {
		return repository.save(r);
	}

	@Override
	public GmMerGateMap GetGmMerGateMap(int id) {
		Optional<GmMerGateMap> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public GmMerGateMap GetGmMerGateMap(String merCode) {
		Optional<GmMerGateMap> optional = repository.findByMer_merCode(merCode);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

}
