package du.cfs.global.db.GATE;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSeed_gate {


}
