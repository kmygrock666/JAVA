package du.cfs.global.db.GM;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GmMerGateMapRepository extends JpaRepository<GmMerGateMap, Integer> {

	Page<GmMerGateMap> findAll(Pageable pageable);

	Optional<GmMerGateMap> findById(int id);

	Optional<GmMerGateMap> findByMer_merCode(String merCode);

}
