package du.cfs.global.Gen;

import java.util.Date;

import du.cfs.global.Gen.cfsEnum.PayType;
import du.cfs.global.Gen.cfsEnum.ProcResultState;
import du.cfs.global.Gen.cfsEnum.ServiceType;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
public class Struce_Input_RechargeFeedback extends converBase {
	private String merCode = "";
	private String gateCode;
	private String gateBN;
	private String gateOrderNumber = "";
	private String kernOrderNumber = "";
	private String merOrderNumber = "";
	private PayType merPayType = PayType.UNSET;
	private int merAmount;
	private ProcResultState procResultStateGate = ProcResultState.UNSET;
	private ProcResultState procResultStateGm = ProcResultState.UNSET;
	private ProcResultState procResultStateKern = ProcResultState.UNSET;
	private Date thirdTranDate;
	private ServiceType serviceType;
	private Struce_RechargeNotify feedback_Recharge;
}

