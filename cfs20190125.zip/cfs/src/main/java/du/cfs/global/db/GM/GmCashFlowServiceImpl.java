package du.cfs.global.db.GM;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import du.cfs.global.Gen.Struce_Input_AgentPayFeedback;
import du.cfs.global.Gen.Struce_Response_AgentPay;
import du.cfs.global.Gen.cfsEnum.ServiceType;
import du.cfs.global.Gen.cfsEnum.SttleStatus;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GmCashFlowServiceImpl implements GmCashFlowService {

	@Autowired
	GmCashFlowRepository repository;

	@Override
	public GmCashFlow GetGmCashFlow(int id) {
		Optional<GmCashFlow> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public List<GmCashFlow> GetAllGmCashFlow() {
		return repository.findAll();
	}

	@Override
	public GmCashFlow update(GmCashFlow gmCashFlow) {
		return repository.save(gmCashFlow);
	}

	@Override
	public GmCashFlow create(GmCashFlow gmCashFlow) {
		return repository.save(gmCashFlow);
	}

	@Override
	public List<GmCashFlow> IdGreaterThan(int id) {
		return repository.findByIdGreaterThan(id);
	}

	@Override
	public int lestUnDoneId() {
		Pageable pageable = PageRequest.of(0, 1, Sort.Direction.DESC, "id");
		Page<GmCashFlow> result = repository.search(pageable);
		Optional<GmCashFlow> optional = result.get().findFirst();

		if (optional.isPresent()) {
			return optional.get().getId();
		}
		return -1;
	}

	@Override
	public List<GmCashFlow> findBymer_merCodeAndServiceTypeAndSttleStatus(String merCode, ServiceType serviceType, SttleStatus sttleStatus) {
		return repository.findBymer_merCodeAndServiceTypeAndSttleStatus(merCode, serviceType, sttleStatus);
	}

	public GmCashFlow TransactionalSuccess(GmGate gmGate, GmMerchant gmMerchant, Struce_Response_AgentPay input_AgentPay) {
		try {
			// TODO 要判斷 AgentPay申請的金額 跟 目前要退款的金額 是否依樣
			log.debug(" Transactional");
			GmCashFlow gmCashFlow = new GmCashFlow();
			gmCashFlow.setServiceType(ServiceType.AgenPay);
			gmCashFlow.setGateOrderNumber(input_AgentPay.getGateOrderNumber());
			gmCashFlow.setKernOrderNumber(input_AgentPay.getKernOrderNumber());
			gmCashFlow.setMer(gmMerchant);
			gmCashFlow.setGmGate(gmGate);
			gmCashFlow.setMerOrderNumber(input_AgentPay.getMerOrderNumber());
			gmCashFlow.setSttleStatus(SttleStatus.UNSTTLE);
			gmCashFlow.setMerAmount(input_AgentPay.getMerAmount() * -1);
			create(gmCashFlow);
			return gmCashFlow;
		} catch (Exception e) {
			return null;
		}

	}

	public GmCashFlow TransactionalFail(GmGate gmGate, GmMerchant gmMerchant, Struce_Response_AgentPay input_AgentPay) {
		try {
			// TODO 要判斷 AgentPay申請的金額 跟 目前要退款的金額 是否依樣
			log.debug(" Transactional");
			GmCashFlow gmCashFlow = new GmCashFlow();
			gmCashFlow.setServiceType(ServiceType.AgenPayFail);
			gmCashFlow.setGateOrderNumber(input_AgentPay.getGateOrderNumber());
			gmCashFlow.setKernOrderNumber(input_AgentPay.getKernOrderNumber());
			gmCashFlow.setMer(gmMerchant);
			gmCashFlow.setGmGate(gmGate);
			gmCashFlow.setMerOrderNumber(input_AgentPay.getMerOrderNumber());
			gmCashFlow.setSttleStatus(SttleStatus.UNSTTLE);
			gmCashFlow.setMerAmount(input_AgentPay.getMerAmount());
			create(gmCashFlow);
			return gmCashFlow;
		} catch (Exception e) {
			return null;
		}
	}

	public GmCashFlow TransactionalFail(GmGate gmGate, GmMerchant gmMerchant, Struce_Input_AgentPayFeedback input_AgentPay) {
		try {
			log.debug(" Transactional");
			GmCashFlow gmCashFlow = new GmCashFlow();
			gmCashFlow.setServiceType(ServiceType.AgenPayFail);
			gmCashFlow.setGateOrderNumber(input_AgentPay.getGateOrderNumber());
			gmCashFlow.setKernOrderNumber(input_AgentPay.getKernOrderNumber());
			gmCashFlow.setMer(gmMerchant);
			gmCashFlow.setGmGate(gmGate);
			gmCashFlow.setMerOrderNumber(input_AgentPay.getMerOrderNumber());
			gmCashFlow.setSttleStatus(SttleStatus.UNSTTLE);
			gmCashFlow.setMerAmount(input_AgentPay.getMerAmount());
			create(gmCashFlow);
			return gmCashFlow;
		} catch (Exception e) {
			log.warn("TransactionalFail " + e.toString());
			return null;
		}
	}

}
