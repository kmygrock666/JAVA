package du.cfs.controller.action.system.vo;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;

import lombok.Data;

//樹狀權限列表
@Data
public class AuthRolePermissionVO {
	private Long id;
	 //權限中文描述
	 private String title;
	 //权限唯一識別
	 private String permission;
	 //路徑
	 private String url;
	//父級id
	 private Long pid;
	 
	 private String icon;
	 //展開
	 private Boolean expand = true;
	 private Boolean checked;

	// 一次性加載所有權限規則生成 tree 樹形節點
	private List<AuthRolePermissionVO> children;
}
