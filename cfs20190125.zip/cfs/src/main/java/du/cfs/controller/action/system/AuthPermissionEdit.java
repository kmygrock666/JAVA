package du.cfs.controller.action.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class AuthPermissionEdit extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	MenuService menuService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		String id =  getParam("id");
		Permission permission = permissionService.findById(Long.parseLong(id));
		Menu permission_menu = permission.getMenu();
		List<Menu> menus = menuService.findAll();
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("p_name", permission.getTitle());
		data.put("p_code", permission.getPermission());
		data.put("p_url", permission.getUrl());
		data.put("p_parent", permission_menu.getCode());
		
//		Map<String, String> parents = menus.stream().collect(Collectors.toMap(Menu::getCode, Menu::getName));
		List<Object> parents = new ArrayList<>();
		for(Menu m: menus) {
			Map<String, String> parent = new HashMap<>();
			parent.put("code", m.getCode());
			parent.put("name", m.getName());
			parents.add(parent);
		}
//		data.put("p_parents", parents);
		assign("parents",parents);
		assign("data",data);
		System.out.println("EDIT Success");
		return getView("authPermissionEdit");
	}
	
}
