package du.cfs.controller.action.system;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.api.action.text.ApiBaseAction;
import du.cfs.api.action.text.ResultVO;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.MenuService;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.common.util.ResultVOUtils;
import du.cfs.controller.action.system.vo.AuthRolePermissionVO;

public class AuthRolePermission extends ApiBaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	MenuService menuService;

	@Override
	public ResultVO execute() {
		// TODO Auto-generated method stub
		System.out.println("asda");
		Long id =  Long.parseLong(getParam("id"));
		//find role permission
		Role role = roleService.findById(id);
		List<Permission> rolePermission = role.getPermissions();
		List<Long> checkedKeys  = rolePermission.stream().map(Permission::getId).collect(Collectors.toList());
		//find all permission transfer tree data
		List<Permission> permissions = permissionService.findAll();
		List<AuthRolePermissionVO> merge = merge(permissions,0L,checkedKeys);
		
		
			
//		assign("authRolePermission",merge);
		System.out.println(JSON.toJSONString(merge,true));
//		System.out.println(roles.size());
		return ResultVOUtils.success(merge);
		

	}
	
	public List<AuthRolePermissionVO> merge(List<Permission> permissions,Long pid,List<Long> checkedKeys){
		
		List<AuthRolePermissionVO> AuthRolePermissionList = new ArrayList<>();
		
		for(Permission p : permissions) {
			AuthRolePermissionVO authRolePermission = new AuthRolePermissionVO();
			BeanUtils.copyProperties(p, authRolePermission);
			if(checkedKeys.contains(p.getId()))
				authRolePermission.setChecked(true);
			if(pid.equals(p.getPid())) {
				authRolePermission.setChildren(merge(permissions,p.getId(),checkedKeys));
				AuthRolePermissionList.add(authRolePermission);
			}
		}
		return AuthRolePermissionList;
	}
	
}
