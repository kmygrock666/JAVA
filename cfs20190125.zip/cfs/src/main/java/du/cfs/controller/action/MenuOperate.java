package du.cfs.controller.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Menu;
import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RememberTokenService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.system.vo.AuthRolePermissionVO;
import du.cfs.security.AdmUserPrinciple;

@Component
public class MenuOperate {
	
	@Autowired
    private RememberTokenService commerceService;
	
	@Autowired
    private RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	//TODO 優化
	public List<AuthRolePermissionVO> getMenu(AdmUserPrinciple userinfo) {

			System.out.println("===========get menus=============");
			List<AuthRolePermissionVO> menus = new ArrayList<>();
			List<String> roles = userinfo.getRole();
			List<Long> keys = new ArrayList<Long>();
			for(String r : roles) {
				Role role = roleService.findByName(r);
				List<Permission> permissions = role.getPermissions();
				List<Long> checkedKeys  = permissions.stream().map(Permission::getId).collect(Collectors.toList());
				keys.addAll(checkedKeys);
			}
			
			List<Permission> permissions = permissionService.findAll();
			menus = merge(permissions,0L,keys);
			for(AuthRolePermissionVO m : menus) {
				if(m.getChildren().size() <= 0 ) menus.remove(m);
			}
			System.out.println(JSON.toJSONString(menus,true));
		
				
		return menus;
	}
	//TODO 優化
	public Map<String,String> getMainTitle(String sub,String action) {
		Map<String,String> pathDetial = new HashMap<>();
		List<Permission> permissions = permissionService.findAll();
			for (Permission permit:permissions) {
				if (permit.getPermission().contentEquals(sub)) {
					pathDetial.put("dir", permit.getTitle());
				}
				if (permit.getPermission().contentEquals(action)) {
					pathDetial.put("sub", permit.getTitle());
					break;
				}
				
			}
		return pathDetial;
	}
	
	public List<AuthRolePermissionVO> merge(List<Permission> permissions,Long pid,List<Long> checkedKeys){
		
		List<AuthRolePermissionVO> AuthRolePermissionList = new ArrayList<>();
		
		for(Permission p : permissions) {
			AuthRolePermissionVO authRolePermission = new AuthRolePermissionVO();
			BeanUtils.copyProperties(p, authRolePermission);
			if(!checkedKeys.contains(p.getId()) && !p.getPid().equals(0L))
				continue;
			if(pid.equals(p.getPid())) {
				authRolePermission.setChildren(merge(permissions,p.getId(),checkedKeys));
				AuthRolePermissionList.add(authRolePermission);
			}
		}
		return AuthRolePermissionList;
	}
}
