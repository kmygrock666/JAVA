package du.cfs;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@EntityScan(basePackages = { "du.cfs.db.MER","du.cfs.common.model"})
@EnableJpaRepositories(basePackages = { "du.cfs.db.MER","du.cfs.common.repository"})
@ComponentScan({"du.cfs.db.MER","du.cfs.config","du.cfs.common","du.cfs.security"})
@EnableScheduling
@SpringBootApplication
public class Enter_MER {

}
