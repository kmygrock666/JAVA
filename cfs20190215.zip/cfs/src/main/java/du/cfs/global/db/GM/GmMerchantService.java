package du.cfs.global.db.GM;

public interface GmMerchantService {
	GmMerchant getMerchant(String merCode);
	GmMerchant update(GmMerchant merConfig);
	GmMerchant create(GmMerchant merConfig);
}
