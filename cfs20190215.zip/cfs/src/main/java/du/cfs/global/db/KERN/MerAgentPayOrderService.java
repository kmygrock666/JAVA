package du.cfs.global.db.KERN;

public interface MerAgentPayOrderService {

	MerAgentPayOrder GetRechargeOrder(int id);

	MerAgentPayOrder save(MerAgentPayOrder merAgentPayOrder);

	MerAgentPayOrder InsertOrder(MerAgentPayOrder merAgentPayOrder);

	MerAgentPayOrder GetRechargeOrder(String kernOrderNumber);
}
