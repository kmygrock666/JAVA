package du.cfs.global.Gen;

import org.springframework.beans.BeanUtils;

public abstract class converBase {
	public <T> T converTo( T clazz) {
		BeanUtils.copyProperties(this, clazz);
		return clazz;
	}
}
