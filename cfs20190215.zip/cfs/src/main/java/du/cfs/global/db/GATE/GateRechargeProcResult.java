package du.cfs.global.db.GATE;

import java.util.Date;
import java.util.TreeMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import du.cfs.global.Gen.cfsEnum.SttleStatus;
import lombok.Data;

@Data
@Entity
public class GateRechargeProcResult {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;



	@Column(columnDefinition = "TINYINT(1)")
	private SttleStatus sttleStatus;

	@Column(nullable = true,updatable=false)
	private String url;

	@Column(nullable = true,updatable=false)
	private String method;
	
	@Lob
	@Column(nullable = true,updatable=false)
	private TreeMap<String, String> param;


	
	
	@OneToOne
	GateRechargeOrder gateRechargeOrder;

	
	

	// ----------------------------------------------------------
	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
		this.sttleStatus = SttleStatus.UNSTTLE;
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------

	
}
