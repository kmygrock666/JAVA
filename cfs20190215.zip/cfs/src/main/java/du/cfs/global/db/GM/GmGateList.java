package du.cfs.global.db.GM;

import java.util.List;

import lombok.Data;

@Data
public class GmGateList{
	List<GmGate> list;


}
