package du.cfs.global.Gen;

import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.databind.ObjectMapper;

import du.cfs.global.Gen.cfsEnum.BankType;
import du.cfs.global.Gen.cfsEnum.PayType;
import du.cfs.global.Unit.EncryptAndDecrypt;
import lombok.Data;
import lombok.EqualsAndHashCode;

// 充值訂單
@EqualsAndHashCode(callSuper = false)
@Data
public class Struce_Input_Recharge  extends converBase{
	@NotBlank(message = "merCode can,t be empty")
	protected String merCode;
	@NotBlank(message = "merOrderNumber can,t be empty")
	protected String merOrderNumber;
	@NotNull(message = "merAmount can,t be empty")
	@Min(value = 10, message = "merAmount must be more than the 10")
	protected int merAmount;
	@NotNull(message = "merPayType can,t be empty")
	protected PayType merPayType;
	@NotNull(message = "merTransDate can,t be empty")

	@Past(message = "merTransDate must be Past")
	protected Date merTransDate;
	@NotBlank(message = "merSyncNotifyUrl can,t be empty")
	@Length(max = 200, message = "merUnsyncNotifyUrl length less than 200")
	protected String merSyncNotifyUrl;
	@NotBlank(message = "merUnsyncNotifyUrl can,t be empty")
	@Length(max = 200, message = "merUnsyncNotifyUrl length less than 200")
	protected String merUnsyncNotifyUrl;
	@Length(max = 50, message = "merDesc length less than 50")
	protected String merDesc;
	
	@NotBlank(message = "sign can,t be empty")
	protected String sign;

	@Length(max = 20)
	protected String merPhone;
	@Length(max = 20)
	protected String merAccount;
	@Length(max = 20)
	protected String merAccountName;
	protected BankType merBankId;
	
	private String kernOrderNumber;
	private String gateOrderNumber;
	
	@Override
	public String toString() {
		ObjectMapper oMapper = new ObjectMapper();
		@SuppressWarnings("unchecked")
		TreeMap<String, String> map = oMapper.convertValue(this, TreeMap.class);
		String smd5strString = "";
		for (Map.Entry<String, String> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if (!key.equals("sign") && value != null)
				smd5strString += key + "=" + value + "&";
		}
		smd5strString = smd5strString.replaceAll("&$", "");
		return smd5strString;
	}

	public String GetMd5Sign(String key) {

		return EncryptAndDecrypt.Md5(this.toString() + key);
	}

	public Boolean CheckMd5Sign(String key) {

		if (sign == null)
			return false;
		String smd5strString = this.toString();
		// System.out.println(smd5strString);
		// System.out.println(GetMd5Sign(Key));
		return EncryptAndDecrypt.Md5Check(smd5strString + key, sign);
	}
	
	public void SetMd5Sign(String key) {
		sign = GetMd5Sign(key);
	}

}
