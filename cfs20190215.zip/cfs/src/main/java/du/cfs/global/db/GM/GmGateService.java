package du.cfs.global.db.GM;

import java.util.List;

public interface GmGateService {
	GmGate GetGmGate(int id);

	GmGate GetGmGateByIP(String ip);
	List<GmGate> GetAllGmGate();
	GmGate update(GmGate gateListRecharge);

	GmGate create(GmGate gateListRecharge);

	GmGate GetGmGateByCode(String Code);
}
