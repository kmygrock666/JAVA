package du.cfs.global.db.GATE;

import java.util.Date;
import java.util.List;

import du.cfs.global.Gen.cfsEnum.NotifyStatus;

public interface GateRechargeNotifyService {
	GateRechargeNotify save(GateRechargeNotify r);

	List<GateRechargeNotify> findByhidenCreatedAtGreaterThanAndHidenNotifyStatus(Date date, NotifyStatus notifyStatus);
}
