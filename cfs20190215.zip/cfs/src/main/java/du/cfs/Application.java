package du.cfs;

import java.text.DateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	 
	public static void main(String[] args) {
		printDateIn(TimeZone.getDefault());
		System.out.println("=====RUN APPLICATION======="+TimeZone.getDefault());
		System.out.println("=====RUN APPLICATION=======");
		for (String string : args) {
			System.out.println("============"+string);
			Pattern pattern = Pattern.compile("--spring.profiles.active=(.+)", Pattern.MULTILINE);
			Matcher matcher = pattern.matcher(string);
			while (matcher.find()) {
				switch (matcher.group(1)) {
				case "mer":
					SpringApplication.run(Enter_MER.class, args);
					break;
				case "dev":
				case "pro":
					SpringApplication.run(Enter_ALL.class, args);
					break;
				}
			}
		}
//		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
		
	}
	
	private static void printDateIn(TimeZone tz) {
		// date為2013-09-19 14:22:30
		Date date = new Date();
		System.out.println(date);
		System.out.println(LocalDateTime.now());
		// 獲取預設的DateFormat，用於格式化Date
		DateFormat df = DateFormat.getInstance();
		// 設定時區為tz
		df.setTimeZone(tz);
		// 獲取格式化後的字串
		String str = df.format(date);
		System.out.println(tz.getID() +" :" +str);
		}
}
