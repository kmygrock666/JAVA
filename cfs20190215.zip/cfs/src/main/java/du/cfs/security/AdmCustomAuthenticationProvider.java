package du.cfs.security;

import org.jboss.aerogear.security.otp.Totp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;


import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
@Profile("dev")
public class AdmCustomAuthenticationProvider implements AuthenticationProvider{

	@Autowired
    private AdmCustomUserDetailsServiceImp userDetailService;
	
	@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String username = authentication.getName();// 這個獲取表單輸入中返回的用户名;
		String password =  authentication.getCredentials().toString();// 這個是表單中輸入的密碼；

		AdmUserPrinciple userInfo = (AdmUserPrinciple) userDetailService.loadUserByUsername(username);

        if(!bCryptPasswordEncoder.matches(password, userInfo.getPassword())) {
            throw new BadCredentialsException("Wrong password.");
        }
    
        if (userInfo.getIsUsing2FA()) {
            final String verificationCode = ((CustomWebAuthenticationDetails) authentication.getDetails()).getVerificationCode();
            final Totp totp = new Totp(userInfo.getSecret());
            
            if (!isValidLong(verificationCode) || !totp.verify(verificationCode)) {
                throw new BadCredentialsException("Invalid verfication code");
            }

        }
     
        return new UsernamePasswordAuthenticationToken(userInfo, null, userInfo.getAuthorities());
	}
	
	private boolean isValidLong(String code) {
        try {
            Long.parseLong(code);
        } catch (final NumberFormatException e) {
            return false;
        }
        return true;
    }

	@Override
	public boolean supports(Class<?> authentication) {
		//同意執行
		return true;
	}

}
