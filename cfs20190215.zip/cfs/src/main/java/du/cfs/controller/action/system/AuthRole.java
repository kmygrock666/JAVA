package du.cfs.controller.action.system;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.common.util.PageChunkVO;
import du.cfs.controller.action.BaseAction;
import du.cfs.controller.action.system.vo.AuthRoleVO;

public class AuthRole extends BaseAction{
	
	@Autowired
	RoleService roleService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		
		String pageNum = getParam("page");
		String pageSize = getParam("size");
		
//		List<Role> roles = roleService.findAll();
		Page<Role> roles = roleService.findAllByPage(pageNum == null ? 0: Integer.valueOf(pageNum), pageSize == null ? 10: Integer.valueOf(pageSize));
		List<AuthRoleVO> authRoleVOList = roles.stream().map(item->{
			AuthRoleVO authRoleVO = new AuthRoleVO();
			BeanUtils.copyProperties(item, authRoleVO);
			authRoleVO.setName(StringUtils.substringAfter(authRoleVO.getName(), "_"));
            return authRoleVO;
		}).collect(Collectors.toList());
		
		PageChunkVO<AuthRoleVO> result = new PageChunkVO<>();
		BeanUtils.copyProperties(roles, result);
		result.setContent(authRoleVOList);
		
		
		assign("roleList",result);
//		System.out.println(JSON.toJSONString(result,true));
//		System.out.println(roles.size());
		return getView("authRole");
		

	}
	
}
