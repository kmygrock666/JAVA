package du.cfs.controller.action.system;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;

public class AuthRoleSave extends BaseAction{
	
	@Autowired
	RoleService roleService;

	@Override
	public String execute() {
		// TODO Auto-generated method stub

		Long id =  Long.parseLong(getParam("roleId"));
		String name =  getParam("roleDescription");
		Role role = roleService.findById(id);
		
		
		if(role == null) {
			String code =  getParam("roleCode");
			code = "ROLE_"+code.toUpperCase();
			role = new Role();
			role.setName(code);
			role.setDescription(name);
			roleService.saveRole(role);
		}else {
			roleService.updateRole(name, id);
		}
		
//		System.out.println(JSON.toJSONString(role));
		System.out.println("ROLE SAVE SUCCESS==================");
		return redirect("/system/AuthRole");
	}
	
}
