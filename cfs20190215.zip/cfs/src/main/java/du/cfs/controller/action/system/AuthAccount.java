package du.cfs.controller.action.system;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.constraints.Null;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.common.util.PageChunkVO;
import du.cfs.controller.action.BaseAction;
import du.cfs.controller.action.BaseCore;
import du.cfs.controller.action.system.vo.AuthAccountVO;
import du.cfs.controller.action.system.vo.AuthRoleVO;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;
import du.cfs.security.AdmUserPrinciple;


public class AuthAccount extends BaseAction{
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	RoleService roleService;
	
	@Override
	public String execute() {
		
		String pageNum = getParam("page");
		String pageSize = getParam("size");
		
//		List<Account> accounts = accountService.findAll();
		Page<Account> accounts = accountService.findAllByPage(pageNum == null ? 0: Integer.valueOf(pageNum), pageSize == null ? 10: Integer.valueOf(pageSize));
		List<AuthAccountVO> authAccountVOs = accounts.stream().map(item->{
			AuthAccountVO authAccountVO = new AuthAccountVO();
			BeanUtils.copyProperties(item, authAccountVO);
			
			List<String> authRoleVOList = item.getRoles().stream().map(role->{
	            return String.valueOf(role.getId());
			}).collect(Collectors.toList());
			
			authAccountVO.setRoles(authRoleVOList);
			return authAccountVO;
		}).collect(Collectors.toList());
		
		List<Role> roles = roleService.findAll();

		Map<Long, String> roleList = roles.stream().collect(Collectors.toMap(Role::getId, Role::getDescription));

//		PageHelper.startPage(pageNum == null ? 0: Integer.valueOf(pageNum), pageSize == null ? 20: Integer.valueOf(pageSize));
//		PageHelper.startPage(0,2);
		
//		PageInfo<AuthAccountVO> result = new PageInfo<AuthAccountVO>(authAccountVOs);
//		System.out.println(JSON.toJSONString(accounts,true));
		PageChunkVO<AuthAccountVO> result = new PageChunkVO<>();
		BeanUtils.copyProperties(accounts, result);
		result.setContent(authAccountVOs);
//		System.out.println(JSON.toJSONString(result,true));
		
		assign("account", result);
		assign("roleList", roleList);
//		System.out.println(JSON.toJSONString(authAccountVOs,true));

		return getView("authAccount");
	}
}
