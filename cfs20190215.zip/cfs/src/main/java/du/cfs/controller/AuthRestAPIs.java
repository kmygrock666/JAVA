package du.cfs.controller;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import du.cfs.api.action.ApiBaseCore;
import du.cfs.api.action.ResultVO;
import du.cfs.common.model.Role;
import du.cfs.common.repository.RoleRepository;
import du.cfs.common.util.UserOperate;
import du.cfs.config.exception.InvalidRequestException;
import du.cfs.config.exception.NotFoundException;
import du.cfs.db.ADM.AccountRepository;
import du.cfs.global.Unit.HttpCurl;
import du.cfs.security.AdmUserPrinciple;
import du.cfs.security.jwt.JwtProvider;
import du.cfs.security.request.LoginForm;
import du.cfs.security.request.SignUpForm;
import du.cfs.security.response.JwtResponse;




@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class AuthRestAPIs extends ApiBaseCore{

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    AccountRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    PasswordEncoder encoder;
    
    @Autowired
    JwtProvider jwtProvider;
    
    @Autowired
    UserOperate session;
    
    /**
     * 	身分驗證
     * @param loginRequest
     * @param bindingResult
     * @return
     */
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginForm loginRequest,BindingResult bindingResult) {
    	//驗證用戶帳密
    	if(bindingResult.hasErrors()) {
    		System.out.println(bindingResult);
    		throw new InvalidRequestException("Invliad parameter ",bindingResult);
    	}
    	System.out.println("api 進入登入程序");
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );
        System.out.println("api 登入成功");
        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtProvider.generateJwtToken(authentication);
        return ResponseEntity.ok(new JwtResponse(jwt));
    }
    
    /**
     * API 入口
     * @param sub
     * @param action
     * @param request
     * @param response
     * @return
     */
//    @PostMapping("/{sub}/{action}")
//    public ResponseEntity<?> test(@PathVariable String sub,	
//    								@PathVariable() String action,
//    								HttpServletRequest request, 
//    								HttpServletResponse response) {
//
//    	HttpSession sessionId = request.getSession();
//		String token = sessionId.getId();
//    	try {
//			//實體class
//			 Class model = Class.forName("com.spring.api.action." + sub + "." + action);
//			 Object classObj = model.newInstance();
//			 //產生method，並呼叫
//			 Method setInfo = model.getMethod("execute", new Class[]{"".getClass(),"".getClass()});
//			 Object getReturn = setInfo.invoke(classObj, new Object[]{token,token} );
//			//取得用戶資訊
//			 String indexName = ((AdmUserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();
//			 //移除用戶session
//			 session.removeUser(indexName,token);
//			 return (ResponseEntity<?>) getReturn;
//		} catch( ClassNotFoundException e ) {
//			//my class isn't there!
//			Log.error(String.format("It params is %s and &s not found : "+e.getMessage(),sub,action ));
//			throw new NotFoundException(String.format("It params is %s and &s not found : "+e.getMessage(),sub,action ));
//			
//		} catch (InstantiationException e) {
//			// TODO Auto-generated catch block
//			throw new NotFoundException("Init errors A: "+e.getMessage());
//		} catch (IllegalAccessException e) {
//			// TODO Auto-generated catch block
//			throw new NotFoundException("Init errors B: "+e.getMessage());
//		} catch (NoSuchMethodException e) {
//			// TODO Auto-generated catch block
//			throw new NotFoundException("Init errors C: "+e.getMessage());
//		} catch (SecurityException e) {
//			// TODO Auto-generated catch block
//			throw new NotFoundException("Init errors D: "+e.getMessage());
//		} catch (IllegalArgumentException e) {
//			// TODO Auto-generated catch block
//			throw new NotFoundException("Init errors E: "+e.getMessage());
//		} catch (InvocationTargetException e) {
//			// TODO Auto-generated catch block
//			throw new NotFoundException("Init errors F: "+e.getMessage());
//		}
//    	
////    	return new ResponseEntity<Object>(true,HttpStatus.OK);
//    }
    
    @PostMapping("/{sub}/{action}")
    public ResultVO postEnter(@PathVariable String sub,	
			@PathVariable() String action,
			HttpServletRequest request, 
			HttpServletResponse response) {
    
    	Map<String,Object> data = new HashMap<>();
	 	request.setAttribute("sub", sub);
	 	data.put("request", request);

		return  (ResultVO) runModel(sub, action, data);
    }
    
    @GetMapping("/{sub}/{action}")
    public ResultVO getEnter(@PathVariable String sub,	
			@PathVariable() String action,
			HttpServletRequest request, 
			HttpServletResponse response) {
    
    	Map<String,Object> data = new HashMap<>();
	 	request.setAttribute("sub", sub);
	 	data.put("request", request);

		return  (ResultVO) runModel(sub, action, data);
    }
    
    @PostMapping("/test")
    public ResponseEntity<?> authenticateUser() {
    	//驗證用戶帳密
    	MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();     
    	body.add("book", "value");
//    	JSONObject obj = HttpCurl.post(body, "http://localhost:8080/api/test1");
    	JSONObject obj = HttpCurl.get("http://localhost:8080/api/test2?a=100");
        return ResponseEntity.ok(obj);
//    	 return ResponseEntity.ok("welcome");
    }
    
    @PostMapping("/test1")
    public ResponseEntity<?> authenticateUser1(@RequestBody Map<String, Object> payload) {
    	//驗證用戶帳密
    	payload.put("request", "success");
        return ResponseEntity.ok(payload);
    }
    
    @GetMapping("/test2")
    public ResponseEntity<?> authenticateUser2(@RequestParam("a") String a) {
    	//驗證用戶帳密
    	
    	Map<String, String> arr = new HashMap<>();
    	arr.put("param", a);
    	arr.put("request", "success");
        return ResponseEntity.ok(arr);
    }
    

//    @PostMapping("/signup")
//    public ResponseEntity<String> registerUser(@Valid @RequestBody SignUpForm signUpRequest) {
//        if(userRepository.existsByUsername(signUpRequest.getUsername())) {
//            return new ResponseEntity<String>("Fail -> Username is already taken!",
//                    HttpStatus.BAD_REQUEST);
//        }
//
//        if(userRepository.existsByEmail(signUpRequest.getEmail())) {
//            return new ResponseEntity<String>("Fail -> Email is already in use!",
//                    HttpStatus.BAD_REQUEST);
//        }
//
//        // Creating user's account
//        User user = new User(signUpRequest.getName(), signUpRequest.getUsername(),
//                signUpRequest.getEmail(), encoder.encode(signUpRequest.getPassword()));
//
//        Set<String> strRoles = signUpRequest.getRole();
//        Set<Role> roles = new HashSet<>();
//
//        strRoles.forEach(role -> {
//        	switch(role) {
//	    		case "admin":
//	    			Role adminRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
//	                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
//	    			roles.add(adminRole);
//	    			
//	    			break;
//	    		case "pm":
//	            	Role pmRole = roleRepository.findByName(RoleName.ROLE_PM)
//	                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
//	            	roles.add(pmRole);
//	            	
//	    			break;
//	    		default:
//	        		Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
//	                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
//	        		roles.add(userRole);        			
//        	}
//        });
//        
//        user.setRoles(roles);
//        userRepository.save(user);
//
//        return ResponseEntity.ok().body("User registered successfully!");
//    }
}