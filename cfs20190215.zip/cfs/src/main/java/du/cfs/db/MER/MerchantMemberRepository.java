package du.cfs.db.MER;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantMemberRepository extends JpaRepository<MerchantMember, Long>{
	Optional<MerchantMember> findByUsername(String username);
}
