package du.cfs.db.MER;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class MerchantMemberService {
	@Autowired
    private MerchantMemberRepository merchantMemberRepository;
	
	@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	public MerchantMember save(MerchantMember user){
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		user.setCreated_at(LocalDateTime.now());
		return merchantMemberRepository.save(user);
	}
	
	public Optional<MerchantMember> findByUsername(String name) {
		return merchantMemberRepository.findByUsername(name);
	}
	
//	public Collection<MenuPermission> findMenuByUsername(String username) {
//		// TODO Auto-generated method stub
//		return accountRepository.findMenuByUsername(username);
//	}
	
	/**
	 * 測試事務操作方法
	 * @param id
	 * @param role_id
	 * @param uid
	 * @return
	 */
//	@Transactional
//	public int deleteAndUpdate(int id,int role_id,int uid) {
//		int dcount =  accountRepository.deleteByJPQL(id);
//
//		int ucount = accountRepository.updateByJPQL(role_id, uid);
//		
//		return dcount+ucount;
//	}
//	
//	public int updateInfo(String password,int role_id,String com04,int id) {
//		password = bCryptPasswordEncoder.encode(password);
//		return accountRepository.updateInfoByJPQL(password, role_id, com04, id);
//	}
}
