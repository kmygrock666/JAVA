package du.cfs.api.action;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class test {
	public ResponseEntity<?> execute(String token,String token2){
		Map<String, Object> map = new HashMap<>();
		map.put("id", 2);
		map.put("redirect", "login");
		map.put("test", "測試");
		map.put("token", token);
		return new ResponseEntity<Object>(map,HttpStatus.OK);
		
	}
}
