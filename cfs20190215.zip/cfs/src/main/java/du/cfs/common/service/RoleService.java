package du.cfs.common.service;


import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import du.cfs.common.model.Role;
import du.cfs.common.repository.RoleRepository;
import du.cfs.db.ADM.AccountRepository;

@Service
public class RoleService {
	@Autowired
    private RoleRepository roleRepository;
	
	@Autowired
    private AccountRepository accountRepository;
	
	/**
	 * 查詢角色
	 * @param name
	 * @return
	 */
	public Role findByName(String name) {
		return roleRepository.findByName(name).orElse(null);
	}
	
	public Role findById(Long id) {
		return roleRepository.findById(id).orElse(null);
	}
	
	public List<Role> findByIdIn(List<Long> ids){
		return roleRepository.findByIdIn(ids);
	}
	
	public void updateRole(String description,Long id) {
		roleRepository.updateRole(description, id);
	}
	
	public Role saveRole(Role role) {
		return roleRepository.save(role);
	}
	
	public List<Role> findAll() {
		return roleRepository.findAll();
	}
	/**
	 * 分頁
	 * @param page
	 * @param size
	 * @return
	 */
	public Page<Role> findAllByPage(Integer page,Integer size){
		
		Sort sort = new Sort(Sort.Direction.ASC,"id");
		Pageable pageable = PageRequest.of(page, size, sort);
		return roleRepository.findAll(pageable);
	}
	
	@Transactional
	public void deleteRole(long id) {
		Role role = roleRepository.findById(id).orElse(null);
//		System.out.println(JSON.toJSONString(role,true));
//		for(Account account : role.getAccount()) {
//			account.getRoles().remove(role);
//		}
		
		roleRepository.delete(role);
//		roleRepository.deleteRole(id);
	}
	
	public  Role findAll(Long id) {
		return roleRepository.findById(id).orElse(null);
	}
	
	
	

	
	
}
