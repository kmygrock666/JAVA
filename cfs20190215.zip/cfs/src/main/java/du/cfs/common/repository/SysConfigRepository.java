//package du.cfs.common.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import du.cfs.common.model.SysConfig;
//
//
//
//public interface SysConfigRepository extends JpaRepository<SysConfig, Long>{
//	SysConfig findByToken(String token);
//}
