package du.cfs.common.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import du.cfs.common.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long>{
	
	Optional<Role> findByName(String roleName);
	
//	@Query("delete from Role r where r.id=?1")
	@Query(value = "delete from role where id = ?1", nativeQuery=true)
	void deleteRole(Long id);
	
	@Transactional
	@Modifying
	@Query(value = "update role set description = ?1 where id = ?2",nativeQuery=true)
	void updateRole(String description,Long id);
	
	List<Role> findByIdIn(List<Long> ids);
	
	Page<Role> findAll(Pageable pageable);
}
