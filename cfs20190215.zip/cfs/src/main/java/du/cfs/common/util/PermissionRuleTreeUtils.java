package du.cfs.common.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;

import du.cfs.common.model.Permission;
import du.cfs.controller.action.system.vo.AuthRolePermissionVO;

public class PermissionRuleTreeUtils {
	
	public static List<AuthRolePermissionVO> merge(List<Permission> permissions,Long pid,List<Long> checkedKeys){
			
		List<AuthRolePermissionVO> AuthRolePermissionList = new ArrayList<>();
		
		for(Permission p : permissions) {
			AuthRolePermissionVO authRolePermission = new AuthRolePermissionVO();
			BeanUtils.copyProperties(p, authRolePermission);
//			if((!checkedKeys.contains(p.getId()) && !p.getPid().equals(0L) ) || p.getId().equals(3L))
//				continue;
			if(checkedKeys.contains(p.getId()) && pid != 0)
				authRolePermission.setChecked(true);
			if(pid.equals(p.getPid())) {
				authRolePermission.setChildren(merge(permissions,p.getId(),checkedKeys));
				AuthRolePermissionList.add(authRolePermission);
			}
		}
		return AuthRolePermissionList;
	}
}
