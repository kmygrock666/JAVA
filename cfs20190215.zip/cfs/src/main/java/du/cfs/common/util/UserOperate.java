package du.cfs.common.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.data.redis.RedisOperationsSessionRepository;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Permission;
import du.cfs.controller.Core;
import du.cfs.security.AdmUserPrinciple;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class UserOperate {
	public static HashMap<String, HttpSession> sessionMap = new HashMap<String, HttpSession>();
	
    @Autowired
    FindByIndexNameSessionRepository<? extends Session> sessionRepository;
    
    @Autowired
    RedisOperationsSessionRepository redisOperationsSessionRepository;
    
	@Autowired
    private RedisTemplate redisTemplate;
	
	@Autowired
//	@Lazy //TODO 解決 Requested bean is currently in creation: Is there an unresolvable circular reference 問題 
//	// @Qualifier("sessionRegistry")
	private SessionRegistry sessionRegistry;
	
	/**
	 * 剔除前一個使用者
	 * @param indexName
	 * @param token
	 */
	public void removeFrontUser(String indexName,String token) {
		// 查詢使用者的 Session 資訊，返回值 key 為 sessionId
		Map<String, ? extends Session> userSessions = sessionRepository.findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, indexName);
        // 移除使用者的 session 資訊
        List<String> sessionIds = new ArrayList<>(userSessions.keySet());
        log.info("操作者的session  ； "+token);
        for (String session : sessionIds) {
        	log.info("找到的ＳＥＳＳＩＯＮ  ； "+session);
        	if(!token.equals(session)) {
	        	redisOperationsSessionRepository.deleteById(session);
	        	log.info("session redis 已刪除 ； "+session);
	        	redisTemplate.delete("user:"+session);
	        	redisTemplate.delete("spring:session:sessions:" + session);
	        	redisTemplate.delete("spring:session:sessions:expires:" + session);
	        	sessionRegistry.removeSessionInformation(session);
	        	log.info("成功剔除 ＳＥＳＳＩＯＮ  為； "+session);
        	}
        }

	}
	
	/**
	 * 刪除使用者
	 * @param indexName
	 * @param token
	 */
	public void removeUser(String indexName,String token) {
//		redisOperationsSessionRepository.deleteById(token);
//		redisTemplate.delete("user:"+token);
//    	sessionRegistry.removeSessionInformation(token);
//    	log.info("成功刪除ＳＥＳＳＩＯＮ  為； "+token);
		// 查詢使用者的 Session 資訊，返回值 key 為 sessionId
		Map<String, ? extends Session> userSessions = sessionRepository.findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, indexName);
        // 移除使用者的 session 資訊

        List<String> sessionIds = new ArrayList<>(userSessions.keySet());
        log.info("操作者的session  ； "+token);
//        sessionRegistry.getSessionInformation(token).expireNow();
        
        System.out.println(sessionRegistry.getAllPrincipals());
        for (String session : sessionIds) {
        	log.info("找到的ＳＥＳＳＩＯＮ  ； "+session);
        	if(token.equals(session)) {
	        	redisOperationsSessionRepository.deleteById(session);
	        	log.info("session redis 已刪除 ； "+session);
	        	redisTemplate.delete("user:"+session);
	        	sessionRegistry.removeSessionInformation(session);
	        	log.info("成功剔除 ＳＥＳＳＩＯＮ  為； "+session);
        	}
        }
	}
	
//	public SecurityContext  findUserInfo(String username) {
//		Map<String, ? extends Session> sessionIds = sessionRepository.findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, username);
////		for (String session : sessionIds) {
////			Session session = sessionRegistry.get;
////			Object obj = session.getAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY);
////			if(obj instanceof SecurityContext)
////				return (SecurityContext) obj;
////		}
////		return null;
//		System.out.println(JSON.toJSONString(sessionIds,true));
//		 
//	}
	
	public void updateOnlineUserRolePermission(String role,List<Permission> permissions) {
		List<Object> loggedUsers = sessionRegistry.getAllPrincipals();
		System.out.println(loggedUsers.size());
		for (Object principal : loggedUsers) {
		    if(principal instanceof AdmUserPrinciple) {
//		    	System.out.println(JSON.toJSONString(sessionRegistry.getAllSessions(principal, true),true));
		        final AdmUserPrinciple user = (AdmUserPrinciple) principal;
		        //find account with role
		        if(user.getRole().contains(role)) {  
		        	List<GrantedAuthority> authorities = new ArrayList<>();
		        	GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(role);
		        	authorities.add(grantedAuthority);
		        	//add modify permission
		        	for (Permission permission : permissions)
		            {
		               	 GrantedAuthority grantedAuthority1 = new SimpleGrantedAuthority(permission.getPermission());
		               	//此處將權限信息添加到GrantedAuthority對像中，在後面進行全權限驗證時會使用GrantedAuthority對象。
		               	 authorities.add(grantedAuthority1);
		            }
		        	user.setAuthorities(authorities);
		        }
		        //update account with permission
		        Authentication newAuth = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
//		        SecurityContextHolder securityContext = findUserInfo(user.getUsername());
//		        securityContext.getContext().setAuthentication(newAuth);
//		        SecurityContextHolder.getContext().setAuthentication(newAuth);

		    }
		} 
	}
}
