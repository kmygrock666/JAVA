package com.spring.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;

import com.spring.security.CustomAuthenticationProvider;
import com.spring.security.CustomFilterSecurityInterceptor;
import com.spring.security.CustomUserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true) 
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	@Autowired
	CustomAuthenticationProvider provider;
	
	@Autowired
    private CustomFilterSecurityInterceptor customFilterSecurityInterceptor;
	
	@Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
//        authenticationManagerBuilder
//                .userDetailsService(userDetailsService)
//                .passwordEncoder(passwordEncoder());   //使用BCrypt進行密碼的hash
		authenticationManagerBuilder.authenticationProvider(provider);
    }
 
//    @Bean
//    @Override
//    public AuthenticationManager authenticationManagerBean() throws Exception {
//        return super.authenticationManagerBean();
//    }
   
	@Override
    protected void configure(HttpSecurity http) throws Exception {
		http
	    	.exceptionHandling()
				.accessDeniedPage("/403") //存取被拒時導往的URL
			.and()
				.authorizeRequests() //表示以下都是授权的配置 
//		        .antMatchers("/cm/**").hasAuthority("USER")
		        .antMatchers("/signup").hasAuthority("ADMIN")
		        .anyRequest().authenticated() //其他请求需要登录认证
		    .and()
		        .formLogin()
		        .loginPage("/login")
		        .defaultSuccessUrl("/cm/index",true)
//		        .failureUrl("/login?error").permitAll()
		        .permitAll()
//		        .successHandler(loginSuccessHandler())
		    .and()
		    	.logout()
		    	.permitAll()
		    .and()
		    	.csrf().disable();// 禁用跨站攻击
//		http.addFilterBefore(customFilterSecurityInterceptor, FilterSecurityInterceptor.class);
	}
	
    @Override
    public void configure(WebSecurity web) throws Exception {
    	//允许所有用户访问
//        web.ignoring().antMatchers("/bootstraps/css/**");
//        web.ignoring().antMatchers("/bootstraps/js/**");
        web.ignoring().antMatchers("/bootstraps/**");
//        web.ignoring().antMatchers("/login");
        web.ignoring().antMatchers("/favicon.ico");
        web.ignoring().antMatchers("/signing");
        web.ignoring().antMatchers("/");
    }
	
}
