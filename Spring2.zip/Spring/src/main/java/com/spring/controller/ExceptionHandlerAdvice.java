package com.spring.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

/**
 * 全局控制器例外處理配置
 * @author RD00
 * @ExceptionHandler(用於全局控制器裡的異常)
 * @InitBinder(用於設置WebDataBinder),WebDataBinder是用來自動綁定前台請求參數到Model中
 * @ModelAttribute(用於綁定鍵值數據到Model中)
 */
@ControllerAdvice
public class ExceptionHandlerAdvice {
	/**
	 * addObject方法可以增加錯誤訊息在這方法在利用前台映射取出數值
	 * setViewName方法為要返回的錯誤頁面　記住！！　我們如果有使用thymeleaf就放置在對應的classpath底下
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(value = Exception.class)
	public ModelAndView exception(Exception ex,WebRequest request){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("errorSomething",ex.getMessage());
		modelAndView.setViewName("403");
		return modelAndView;
	}
	//如果我們要讓所有的@RequestMapping擁有此鍵值
	@ModelAttribute
	public void addAttribute(Model md){
		md.addAttribute("message","你可以設定一些錯誤訊息");
	}
}
