package com.spring.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.security.core.AuthenticationException;
import com.spring.model.Commerce;
import com.spring.service.CommerceService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class Auth {
	
	@Autowired
	CommerceService commerceService;
	
	@GetMapping("/login")
	public String login() {
		
		System.out.println("Core-Login");
//		int rq = commerceService.updateInfo("123", 1, "1", 6);
//		System.out.println(rq);
		return "login";
	}
	
	@GetMapping("signing")
	public String sign() {
		Commerce user = new Commerce();
		user.setUsername("ian");
		user.setPassword("123");
		user.setRole_id(1);
		user.setCom04("1");
		commerceService.save(user);
		log.info("success");
		return "login";
	}
	
	@RequestMapping("/login/error")
    public void loginError(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("text/html;charset=utf-8");
        AuthenticationException exception =
                (AuthenticationException)request.getSession().getAttribute("SPRING_SECURITY_LAST_EXCEPTION");
        try {
            response.getWriter().write(exception.toString());
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	@GetMapping("/")
	public String index() {

		return "index";
	}
}
