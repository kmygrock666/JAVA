package com.spring.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

public class AjaxUtils {
	public static boolean isAjax(HttpServletRequest request) {
		String accept = request.getHeader("accept");
		String ajax = request.getHeader("X-Requested-With");
//		System.out.println("isAjax-accept  "+accept);
//		System.out.println("isAjax-ajax  "+ajax);
		return (StringUtils.indexOf(accept, "json") > -1 && StringUtils.isNotEmpty(ajax));
//		return StringUtils.isNotEmpty(ajax);

	}

	public static boolean isApi(HttpServletRequest request) {
		String accept = request.getHeader("accept");
        String ajax = request.getHeader("X-Requested-With");
//        System.out.println("isApi-accept  "+accept);
//		System.out.println("isApi-ajax  "+ajax);
        return (StringUtils.indexOf(accept, "json") > -1 && StringUtils.isEmpty(ajax));
//        return StringUtils.isEmpty(ajax);
	}
	
	public static boolean isApiRoute(HttpServletRequest request) {
		String url = request.getRequestURI();
		return (url.indexOf("api") == 1);
	}
}
