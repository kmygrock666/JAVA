package com.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.model.Commerce;
import com.spring.model.Role;
import com.spring.repository.CommerceRepository;
import com.spring.repository.RoleRepository;

@Service
public class CommerceService {
	@Autowired
    private CommerceRepository commerceRepository;
	
//	@Autowired
//    private RoleRepository roleRepository;
	
	@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
//	public Commerce GetUserByName(String name) {
//		return commerceRepository.findByUsername(name);
//	}
	
	public Optional<Commerce> findByUsername(String name) {
		return commerceRepository.findByUsername(name);
	}
	
	/**
	 * 測試事務操作方法
	 * @param id
	 * @param role_id
	 * @param uid
	 * @return
	 */
	@Transactional
	public int deleteAndUpdate(int id,int role_id,int uid) {
		int dcount =  commerceRepository.deleteByJPQL(id);

		int ucount = commerceRepository.updateByJPQL(role_id, uid);
		
		return dcount+ucount;
	}
	
	public int updateInfo(String password,int role_id,String com04,int id) {
		password = bCryptPasswordEncoder.encode(password);
		return commerceRepository.updateInfoByJPQL(password, role_id, com04, id);
	}
	
	public Commerce save(Commerce user) {
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		return commerceRepository.save(user);
	}

//	public List<Role> findRoleInfoByRole(String role) {
//		// TODO Auto-generated method stub
//		return roleRepository.findByRole(role);
//	}
	

	
	
}
