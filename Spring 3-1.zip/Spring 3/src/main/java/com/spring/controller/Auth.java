package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class Auth {
	
	@GetMapping("/login")
	public String login() {
		
		System.out.println("Core-Login");
//		int rq = commerceService.updateInfo("123", 1, "1", 6);
//		System.out.println(rq);
		return "login";
	}
}
