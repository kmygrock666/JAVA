package com.spring.model;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="persistent_logins")
public class RememberToken {
	@Id
	@GeneratedValue
	private String series;
	
	private String username;
	
	private String token;
	
	private Date  last_used;
	
}
