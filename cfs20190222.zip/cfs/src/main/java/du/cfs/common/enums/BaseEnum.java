package du.cfs.common.enums;

import lombok.Getter;

@Getter
public enum BaseEnum {
	BASE_URL("/cm"),
	;
	
	
	private String text;
	
	BaseEnum(String message) {
        this.text = message;
    }
}
