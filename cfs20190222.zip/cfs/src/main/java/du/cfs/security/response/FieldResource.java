package du.cfs.security.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FieldResource {
	private String resource;
	private String field;
	private String code;
	private String message;
}
