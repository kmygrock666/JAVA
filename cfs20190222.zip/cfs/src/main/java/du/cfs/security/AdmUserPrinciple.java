package du.cfs.security;

import org.springframework.context.annotation.Profile;
import org.springframework.security.core.GrantedAuthority;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.db.ADM.Account;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Data
@Slf4j
@Profile("dev")
public class AdmUserPrinciple implements UserDetails{
	private static final long serialVersionUID = 1L;
	 
	private long id;
 
    private String nickname;
 
    private String username;
 
    private Date createdAt;
    
    private Boolean isUsing2FA;
    
    private String secret;
    
    private List<String> role;
 
    @JsonIgnore
    private String password;
 
    private Collection<? extends GrantedAuthority> authorities;
 
    public AdmUserPrinciple(long id, 
    						String nickname, 
    						String username,
    						Date created_at,
    						String password,
    						Boolean isUsing2FA,
    						String secret,
    						List<String> role,
    						Collection<? extends GrantedAuthority> authorities) {
        this.id = id;
        this.nickname = nickname;
        this.username = username;
        this.createdAt = created_at;
        this.password = password;
        this.isUsing2FA = isUsing2FA;
        this.secret = secret;
        this.role = role;
        this.authorities = authorities;

    }
 
    public static AdmUserPrinciple build(Account user) {

    	Set<Role> roles = user.getRoles();

    	List<String> user_role = new ArrayList<>();
    	List<GrantedAuthority> authorities = new ArrayList<>();
    	for (Role role : roles) {
    		GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(role.getName());
    		//此處將角色信息添加到GrantedAuthority對像中，在後面進行全權限驗證時會使用GrantedAuthority對象。
    		authorities.add(grantedAuthority);
    		List<Permission> permissions = role.getPermissions();
    		user_role.add(role.getName());
//    		log.info("用戶角色"+role.getName());
            for (Permission permission : permissions)
            {
                if (permission != null && permission.getTitle() != null)
                {   
//	               	 log.info("用戶權限"+permission.getUrl());
	               	 GrantedAuthority grantedAuthority1 = new SimpleGrantedAuthority(permission.getPermission());
	               	//此處將權限信息添加到GrantedAuthority對像中，在後面進行全權限驗證時會使用GrantedAuthority對象。
	               	 authorities.add(grantedAuthority1);
                }
            }
    	}
//    	log.info("新增儲存用戶權限"+authorities.toString());
        return new AdmUserPrinciple(
                user.getId(),
                user.getNickname(),
                user.getUsername(),
                user.getCreatedAt(),
                user.getPassword(),
                user.getIsUsing2FA(),
                user.getSecret(),
                user_role,
                authorities
        );
    }
    
    public Boolean getIsUsing2FA() {
    	return isUsing2FA;
    }
 
    @Override
    public String getUsername() {
        return username;
    }
 
    @Override
    public String getPassword() {
        return password;
    }
 
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }
 
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }
 
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }
 
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
 
    @Override
    public boolean isEnabled() {
        return true;
    }
 
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        AdmUserPrinciple user = (AdmUserPrinciple) o;
        return Objects.equals(id, user.id);
    }
}
