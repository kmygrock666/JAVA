package du.cfs.db.ADM;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.jboss.aerogear.security.otp.api.Base32;

import du.cfs.common.model.Role;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "username"}) })
public class Account{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	@Column(length = 20,updatable=false)
	private String username;
	@Column(length = 20)
	private String nickname;

	private String password;
	private String ip;
	private Boolean status;
	private Boolean isUsing2FA;
	private String secret;
	private String email;
	@Column(insertable = false,updatable = false,columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date createdAt;
	@Column(insertable = false,updatable = false,columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
	private Date updateAt;
	
	@ManyToMany()
//    @JoinTable(
//    		name = "commerce_roles", 
//			joinColumns = @JoinColumn(name = "user_id"), 
//			inverseJoinColumns = @JoinColumn(name = "role_id")
//    )	
	private Set<Role> roles = new HashSet<>();
	
	public void addRole(Role role) {
		roles.add(role);
	}
	public Account() {
		super();
		this.secret = Base32.random();
	}
	

}
