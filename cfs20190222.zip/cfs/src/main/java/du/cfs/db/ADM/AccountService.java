package du.cfs.db.ADM;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import du.cfs.db.ADM.AccountRepository;
import du.cfs.security.AdmUserPrinciple;



@Service
public class AccountService {
	
	public static String QR_PREFIX = "https://chart.googleapis.com/chart?chs=100x100&chld=M%%7C0&cht=qr&chl=";
	public static String APP_NAME = "SpringRegistration";
	
	@Autowired
    private AccountRepository accountRepository;

	public Account save(Account user){
		return accountRepository.save(user);
	}
	
	public Account findByUsername(String name) {
		return accountRepository.findByUsername(name).orElse(null);
	}
	
	public Optional<Account> findOptionalByUsername(String name){
		return accountRepository.findByUsername(name);
	}
	
	public List<Account> findAll(){
		return accountRepository.findAll();
	}
	
	public void deleteAccount(Long id) {
		accountRepository.deleteById(id);
	}

	/**
	 * page search
	 * @param <T>
	 * @param account
	 * @param page 頁數
	 * @param size 每頁數量
	 * @return
	 */
	public <T> Page<Account> findByPage(Account account,T p,T s){
		
		Sort sort = new Sort(Sort.Direction.ASC,"id");
		Integer page = p == null ? 0:  Integer.valueOf((String) p);
		Integer size = s == null ? 10:  Integer.valueOf((String) s);
		Pageable pageable = PageRequest.of(page, size, sort);
		ExampleMatcher matcher = ExampleMatcher.matching().withIgnorePaths("id", "secret");
		Example<Account> example = Example.of(account,matcher);
		Page<Account> accountPage = accountRepository.findAll(example, pageable);
		return accountPage;
	}

	public String generateQRUrl(Account user) throws UnsupportedEncodingException {
		return QR_PREFIX + URLEncoder.encode(String.format(
			      "otpauth://totp/%s:%s?secret=%s&issuer=%s", 
			      APP_NAME, user.getEmail(), user.getSecret(), APP_NAME),
			      "UTF-8");
	}
	
	public void updateUser2FA(AdmUserPrinciple currentUser) {
		// TODO Auto-generated method stub
//		Authentication curAuth = SecurityContextHolder.getContext().getAuthentication();
//	    User currentUser = (User) curAuth.getPrincipal();
//	    currentUser.setUsing2FA(use2FA);
//	    currentUser = userRepository.save(currentUser);
	     
	    Authentication auth = new UsernamePasswordAuthenticationToken(
	      currentUser, currentUser.getPassword(), currentUser.getAuthorities());
	    SecurityContextHolder.getContext().setAuthentication(auth);
	}

//	public Collection<MenuPermission> findMenuByUsername(String username) {
//		// TODO Auto-generated method stub
//		return accountRepository.findMenuByUsername(username);
//	}
	
	/**
	 * 測試事務操作方法
	 * @param id
	 * @param role_id
	 * @param uid
	 * @return
	 */
//	@Transactional
//	public int deleteAndUpdate(int id,int role_id,int uid) {
//		int dcount =  accountRepository.deleteByJPQL(id);
//
//		int ucount = accountRepository.updateByJPQL(role_id, uid);
//		
//		return dcount+ucount;
//	}
//	
//	public int updateInfo(String password,int role_id,String com04,int id) {
//		password = bCryptPasswordEncoder.encode(password);
//		return accountRepository.updateInfoByJPQL(password, role_id, com04, id);
//	}
}
