package du.cfs.global.Gen;

public class cfsEnum {

	public enum MachineType {
		KERN, JUMPER, GM, GATE;
	}

	public enum ServiceType {
		UNSET, Recharge, AgenPay, AgenPayFail;
	}

	public enum SttleStatus {
		UNSTTLE, DONE;
	}

	public enum ProcResultState {
		UNSET, FAIL, DONE, Exception;
	}

	public enum PayType {
		UNSET, UNIONPAY, SCAN_WECHAT, SCAN_QQ, SCAN_ALIPAY, SCAN_UNIONPAY, QUICK_PAY, WAP_QQ, WAP_WECHAT, WAP_ALIPAY;
	}

	public enum RechargeOrderStatus {
		UNPAY, DONE, FAIL, KEEP, SYSTEM_CANCEL;
	}

	public enum AgentPayOrderStatus {
		UNPAY, DONE, FAIL, KEEP, SYSTEM_CANCEL;
	}

	public enum NotifyStatus {
		UN_Notify, NotifyDONE, NotifyFAIL;
	}

	public enum BankType {
		ABC, ICBC, CCB, BCOM, BOC, CMB
		// 农业银行, 工商银行,建设银行,交通银行,中国银行,招商银行
		, CMBC, CEBB, BOB, CIB, PSBC
		// 民生银行,光大银行,北京银行,兴业银行,中国邮政银行"
		, SPDB, ECITIC, HZB, GDB, SHB
		// 浦发银行,中信银行,杭州银行,广发银行,上海银行
		, NBB, HXB, SPABANK;
	}

	public enum EchoType {
		Exception, SUCCESS, PARAMETER_ERROR, SIGN_ERROR, GATE_CONFIG_ERROR, InsufficientSttledAmount, AgentPayLock;
	}
}
