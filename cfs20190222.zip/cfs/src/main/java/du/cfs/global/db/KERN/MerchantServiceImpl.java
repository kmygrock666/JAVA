package du.cfs.global.db.KERN;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Unit.OrderCode;
@Service
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	MerchantRepository repository;
	
	private static String codeMap = "vwA0xyBtFcMOd7EqrUGkIfgRJKjChlmSunH2PoL6eTY4i3zWXDZQbNVa5p";
	private static String codeKey = "s";
	
	public Merchant getMerchant(String merCode) {
		Optional<Merchant> optional = repository.findBymerCode(merCode);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	
	@Override
	public Merchant update(Merchant merConfig) {
		return repository.save(merConfig);
	}

	@Override
	public Merchant create(Merchant merConfig) {
		merConfig.setId(OrderCode.StringCodeToInt(codeMap, codeKey, merConfig.getMerCode()));
		return repository.save(merConfig);
	}
}
