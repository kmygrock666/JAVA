package du.cfs.global.db.GM;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GmMerchantRepository extends JpaRepository<GmMerchant, Integer> {

	Page<GmMerchant> findAll(Pageable pageable);

	Optional<GmMerchant> findById(int id);

	Optional<GmMerchant> findBymerCode(String merCode);
	

}

