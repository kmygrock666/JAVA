package du.cfs.global.db.GM;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import du.cfs.global.Gen.cfsEnum.ServiceType;
import du.cfs.global.Gen.cfsEnum.SttleStatus;

public interface GmCashFlowRepository extends JpaRepository<GmCashFlow, Integer> {

	Page<GmCashFlow> findAll(Pageable pageable);

	Optional<GmCashFlow> findById(Integer id);

	List<GmCashFlow> findByIdGreaterThan(int id);

	@Query("SELECT m FROM GmCashFlow m WHERE m.sttleStatus=1 ")
	Page<GmCashFlow> search(Pageable pageable);


	// List<GmCashFlow> findByserviceTypeAndSttleStatus(ServiceType serviceType,
	// SttleStatus sttleStatus);

	List<GmCashFlow> findBymer_merCodeAndServiceTypeAndSttleStatus(String merCode, ServiceType serviceType, SttleStatus sttleStatus);

}
