package du.cfs.global.Gen;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Map;

import lombok.Data;

// 充值訂單
@Data
public class Struce_Input_JumpRechargeFeedback {
	private String ip;
	private String method;
	private String sData = "";
	Map<String, String> params = new LinkedHashMap<String, String>();

	private void getParam() {
		try {
			String[] pairs = sData.split("&");
			for (String pair : pairs) {
				int idx = pair.indexOf("=");
				params.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
			}
		} catch (UnsupportedEncodingException e) {
		}
	}


	public int GetPatamToInt(String key) {
		String parString = GetParam(key);
		try {
			return Integer.parseInt(parString);
		} catch (NumberFormatException ex) {
		}
		return 0;
	}

	public String GetParam(String key) {
		if (sData != "" && params.size() == 0)
			getParam();
		if (params.containsKey("gateOrderNumber"))
			return params.get(key);
		return "";
	}
}
