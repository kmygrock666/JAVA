package du.cfs.global.db.GATE;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Unit.OrderCode;

@Service
public class GateRechargeOrderServiceImpl implements GateRechargeOrderService {

	@Autowired
	private GateRechargeOrderRepository repository;



	public GateRechargeOrder GetRechargeOrder(int id) {
		Optional<GateRechargeOrder> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public GateRechargeOrder GetRechargeOrder(String gateCode, String orderCode) {
		int id = OrderCode.StringCodeToInt(codeMap, codeKey, orderCode);
		Optional<GateRechargeOrder> optional = repository.findBygateCodeAndId(gateCode, id);
		if (optional.isPresent()) {
			if (orderCode.equals(optional.get().getGateOrderNumber()))
				return optional.get();
		}
		return null;
	}

	private static String codeMap = "vwA0xyBzWXDZQbUcMOd7Eqrst1SunH2PoL6eTY4i3GkIfgRJKjChlmNVa5p";
	private static String codeKey = "F";

	public GateRechargeOrder InsertOrder(GateRechargeOrder rechargeOrder) {
		try {
			rechargeOrder = repository.save(rechargeOrder);
			String orderCode = OrderCode.IntToCodeString(codeMap, codeKey, (int) rechargeOrder.getId(), 20);
			rechargeOrder.setGateOrderNumber(orderCode);
			rechargeOrder = repository.save(rechargeOrder);
			return rechargeOrder;
		} catch (Exception e) {
			return null;
		}

	}

	public GateRechargeOrder save(GateRechargeOrder r) {
		return repository.save(r);
	}


}
