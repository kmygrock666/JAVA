package du.cfs.global.db.GATE;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import du.cfs.global.Gen.cfsEnum.EchoType;
import du.cfs.global.Gen.cfsEnum.NotifyStatus;
import du.cfs.global.Gen.cfsEnum.RechargeOrderStatus;
import du.cfs.global.Gen.converBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
@Entity
public class GateRechargeNotify extends converBase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	// ----------------------------------------------------------
	private EchoType resultCode;
	private String resultMsg;
	private String merCode;
	private int merAmount;
	private String merOrderNumber;
	private String sign;
	private RechargeOrderStatus orderStatus;
	// ----------------------------------------------------------
	private String hidenCallbackUrl;
	private NotifyStatus hidenNotifyStatus;
	private String hidenRespoString;
	@Temporal(TemporalType.TIMESTAMP)
	private Date hidenCreatedAt;
	// ----------------------------------------------------------

	@OneToOne
	GateRechargeFeedbackOrder gateRechargeFeedbackOrder;

	public GateRechargeNotify() {
	}

	// ----------------------------------------------------------
	@PrePersist
	void createdAt() {
		this.hidenCreatedAt = new Date();
		hidenNotifyStatus = NotifyStatus.UN_Notify;
	}

}
