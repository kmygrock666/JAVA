package du.cfs.global.db.GATE;

import java.util.List;

public interface GateRechargeFeedbackOrderService {

	GateRechargeFeedbackOrder GetRechargeFeedbackOrder(int id);

	GateRechargeFeedbackOrder save(GateRechargeFeedbackOrder r);

	List<GateRechargeFeedbackOrder> IdGreaterThan(int id, String gateCode);

	public int lestUnDoneId(String gateCode);
}
