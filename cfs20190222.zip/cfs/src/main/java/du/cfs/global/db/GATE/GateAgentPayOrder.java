package du.cfs.global.db.GATE;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;
import org.springframework.context.annotation.Profile;

import du.cfs.global.Gen.cfsEnum.AgentPayOrderStatus;
import du.cfs.global.Gen.cfsEnum.BankType;
import du.cfs.global.Gen.cfsEnum.ProcResultState;
import du.cfs.global.Gen.converBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merCode", "merOrderNumber" }) })
@Entity
public class GateAgentPayOrder extends converBase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;

	@NotBlank
	protected String merCode;
	@Column(length = 50, updatable = false, nullable = false)
	private String merOrderNumber;
	@Column(updatable = false, nullable = false)
	protected int merAmount;
	@Column(nullable = false)
	protected BankType merBankId;
	@Length(max = 20)
	protected String merAccount;
	@Length(max = 20)
	protected String merAccountName;
	@Length(max = 20)
	protected String province;
	@Length(max = 20)
	protected String city;

	// ---------------------------------------------------
	@Column(columnDefinition = "TINYINT(1)")
	private AgentPayOrderStatus orderStatus;
	// ---------------------------------------------------
	@Column(length = 50)
	private String kernOrderNumber;
	@Column(length = 50)
	private String gateCode;
	@Column(length = 50)
	private String gateOrderNumber;

	// ------------- --------------------------------------

	private ProcResultState procResultStateGate = ProcResultState.UNSET;
	private ProcResultState procResultStateGm = ProcResultState.UNSET;
	private ProcResultState procResultStateKern = ProcResultState.UNSET;

	// ---------------------------------------------------
	@Length(max = 20)
	protected String thirdMsg;
	@Temporal(TemporalType.TIMESTAMP)
	private Date thirdTranDate;
	@Column(length = 50)
	private String thirdOrderNumber;
	// ---------------------------------------------------
	// ---------------------------------------------------

	public GateAgentPayOrder() {
	}

	// ----------------------------------------------------------

	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
		this.orderStatus = AgentPayOrderStatus.UNPAY;
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------




	// ----------------------------------------------------------

}
