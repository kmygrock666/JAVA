package du.cfs.global.Gen;

import java.util.Map;
import java.util.TreeMap;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.databind.ObjectMapper;

import du.cfs.global.Gen.cfsEnum.BankType;
import du.cfs.global.Unit.EncryptAndDecrypt;
import lombok.Data;
import lombok.EqualsAndHashCode;

// 充值訂單
@EqualsAndHashCode(callSuper = false)
@Data
public class Struce_Input_AgentPay  extends converBase{
	@NotBlank
	protected String merCode;

	@NotBlank(message = "merOrderNumber can,t be empty")
	protected String merOrderNumber;
	@Min(1)
	protected int merAmount;
	@NotNull
	protected BankType merBankId;
	@Length(max = 20)
	protected String merAccount;
	@Length(max = 20)
	protected String merAccountName;
	@Length(max = 20)
	protected String province;
	@Length(max = 20)
	protected String city;

	@NotBlank(message = "sign can,t be empty")
	protected String sign;

	private String kernOrderNumber;
	private String gateOrderNumber;

	@Override
	public String toString() {
		ObjectMapper oMapper = new ObjectMapper();
		@SuppressWarnings("unchecked")
		TreeMap<String, String> map = oMapper.convertValue(this, TreeMap.class);
		String smd5strString = "";
		for (Map.Entry<String, String> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if (!key.equals("sign") && value != null)
				smd5strString += key + "=" + value + "&";
		}
		smd5strString = smd5strString.replaceAll("&$", "");
		return smd5strString;
	}

	public String GetMd5Sign(String key) {

		return EncryptAndDecrypt.Md5(this.toString() + key);
	}

	public Boolean CheckMd5Sign(String key) {

		if (sign == null)
			return false;
		String smd5strString = this.toString();
		// System.out.println(smd5strString);
		// System.out.println(GetMd5Sign(Key));
		return EncryptAndDecrypt.Md5Check(smd5strString + key, sign);
	}

	public void SetMd5Sign(String key) {
		sign = GetMd5Sign(key);
	}
}
