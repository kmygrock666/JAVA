package du.cfs.global.db.GATE;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Gen.cfsEnum.NotifyStatus;

@Service
public class GateRechargeNotifyServiceImpl implements GateRechargeNotifyService {

	@Autowired
	private GateRechargeNotifyRepository repository;

	public GateRechargeNotify save(GateRechargeNotify r) {
		return repository.save(r);
	}

	public List<GateRechargeNotify> findByhidenCreatedAtGreaterThanAndHidenNotifyStatus(Date date, NotifyStatus notifyStatus) {
		return repository.findByhidenCreatedAtGreaterThanAndHidenNotifyStatus(date, notifyStatus);
	}
}
