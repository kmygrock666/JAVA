package du.cfs.global.db.GM;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GmKernRepository extends JpaRepository<GmKern, Integer> {

	Page<GmKern> findAll(Pageable pageable);

	Optional<GmKern> findById(int id);

	Optional<GmKern> findByapiIp(String apiIp);
}
