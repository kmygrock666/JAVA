package du.cfs.api.base;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import du.cfs.security.AdmUserPrinciple;

@Component
public abstract class ApiBaseAction{
	
	private HttpServletRequest request;
	ThreadLocal<Long> startTime = new ThreadLocal<>();
	public abstract ResultVO<?> execute();

	/**
	 * get params
	 * @param data
	 */
	public void init(Map<String,Object> data) {
		startTime.set(System.currentTimeMillis());
		request = (HttpServletRequest) data.get("request");
	}
	
	public AdmUserPrinciple getUserInfo() {
		return (AdmUserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	}
	
	public  <T> T getParam(String key) {
		String[] param = request.getParameterValues(key);
		String symbol = key.substring(key.length()-2,key.length());
		if(param == null || (param.length == 1 && !symbol.equals("[]"))) {
			return (T) request.getParameter(key);
		}

		return (T) param;
	}
	

}
