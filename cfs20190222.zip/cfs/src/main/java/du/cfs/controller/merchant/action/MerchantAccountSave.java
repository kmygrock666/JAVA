package du.cfs.controller.merchant.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.config.exception.AccountNotFoundException;
import du.cfs.config.exception.NotFoundException;
import du.cfs.controller.base.BaseAction;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;
import du.cfs.security.AdmUserPrinciple;

public class MerchantAccountSave extends BaseAction{
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
//	@Lazy //TODO 解決 Requested bean is currently in creation: Is there an unresolvable circular reference 問題 
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		
		String username =  getParam("username");
		String nickname =  getParam("nickname");
		String ip =  getParam("ip");
		String is_using2fa =  getParam("isUsing2FA");
		String oldPwd =  getParam("oldPwd");
		String newPwd =  getParam("newPwd");
		String checkPwd =  getParam("checkPwd");

		Account account = accountService.findByUsername(username);
		
		
		if(account == null)
			throw new AccountNotFoundException("not find username");
		if(nickname == null && ip == null && is_using2fa == null) {
			if(!bCryptPasswordEncoder.matches(oldPwd, account.getPassword())) {
				throw new AccountNotFoundException("密碼錯誤");
	        }
			if(newPwd.equals(checkPwd))
				account.setPassword(bCryptPasswordEncoder.encode(newPwd));
			else
				throw new AccountNotFoundException("第二次密碼輸入錯誤");
		}else {
			Boolean is2FA = Boolean.parseBoolean(is_using2fa);
			if(is2FA && !account.getIsUsing2FA()) {
				AdmUserPrinciple user = getUserInfo();
				user.setIsUsing2FA(is2FA);
				accountService.updateUser2FA(user);
			}
			account.setNickname(nickname);
			account.setIp(ip);
			account.setIsUsing2FA(is2FA);
		}
		

		accountService.save(account);
	
		
		System.out.println("MerchantAccountSave Save Success");
		return redirect("/merchant/MerchantAccount");
	}
	
}
