package du.cfs.controller.base;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import du.cfs.common.util.RegiserBean;
import du.cfs.security.AdmUserPrinciple;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BaseCore {
	
	@Autowired
	MenuOperate menu;
	
	@Autowired
    BeanFactory beanFactory;
	
	@Autowired
	private RegiserBean regiser;
	
	public Object runModel(String base,String sub,String action,Map<String,Object> data) {
		Object getReturn = null;
		try {
			//實體class
			Class<?> model_class = Class.forName("du.cfs." + base + "." + sub + ".action." + action);
			Object classObj2;
			//取得bean
			if (beanFactory.containsBean(action)) {
				classObj2 = beanFactory.getBean(model_class);
			}else {
				classObj2 = regiser.registerBean(action, model_class);
			}

			log.info("=============In Core Class============");
			
			//產生method，並呼叫
			Method runInit = classObj2.getClass().getMethod("init", new Class[]{Map.class});
			runInit.invoke(classObj2, new Object[]{data});
			//產生method，並呼叫 
			Method runInfo = classObj2.getClass().getMethod("execute", new Class[]{});
			getReturn = runInfo.invoke(classObj2, new Object[]{});
			
			//移除bean
//			baseCore.deleteBean(action);
//			return getReturn;
			
		} catch( ClassNotFoundException e ) {
			//my class isn't there!
			log.error("Not Path : {}", e.getMessage());
			throw new RuntimeException("Not Path : " + e.getMessage());
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 B " + e.getMessage());
			throw new RuntimeException("初始化錯誤 B " + e.getMessage());
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 C " + e.getMessage());
			throw new RuntimeException("初始化錯誤 C " + e.getMessage());
		}  catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 F {} , Error: " ,e.getMessage(),e.getCause().getMessage());
			throw new RuntimeException(e.getCause().getMessage());
		}
		
//		catch( ClassNotFoundException |
//				IllegalAccessException |
//				NoSuchMethodException |
//				InvocationTargetException reflectionEx) {
//			//my class isn't there!
//			log.error("Reflection error trying to invoke \" : {}", reflectionEx.getClass());
//			throw new RuntimeException("Not Path : " + reflectionEx.getMessage());
//			
//		} 
		
		return getReturn;
		
	}
	
	/**
	 * 設置VIEW
	 */
	public void initView(Model model,String sub,String action) {
		AdmUserPrinciple userInfo = (AdmUserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Map<String,String> dirTitle = menu.getMainTitle(sub,action,userInfo);
		model.addAttribute("menuTitle", dirTitle.get("dir"));
		model.addAttribute("subTitle", dirTitle.get("sub"));
		model.addAttribute("user", userInfo);
	}
}
