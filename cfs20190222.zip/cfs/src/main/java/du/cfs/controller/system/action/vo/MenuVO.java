package du.cfs.controller.system.action.vo;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;

import lombok.Data;

@Data
public class MenuVO {
	private Long id;
	
	private String name;
	
	private String code;
	
	private String icon;
	
	private int sort;
	
	private List<AuthPermissionVO> permissions;
}
