package du.cfs.controller.system.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.common.util.UserOperate;
import du.cfs.controller.base.BaseAction;

public class AuthRolePermissionSave extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	UserOperate userOperate;
	

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		Long id =  Long.parseLong(getParam("roleId"));
		String[] permission  = getParam("authRules[]");
		
		List<Long> ids = new ArrayList<>();
		
		if(permission != null && permission.length > 0) {
			for (String s : permission) {
				ids.add(Long.parseLong(s));
			}
		}
		List<Permission> permissions = permissionService.findByIdIn(ids);
		
		
		Role role = roleService.findById(id);
		role.setPermissions(permissions);
		
		roleService.saveRole(role);
		userOperate.kickOutUserByUpdateRolePermission(role.getName());
		
		System.out.println("Permission save success");
		return redirect("/system/AuthRole");
	}
	
}
