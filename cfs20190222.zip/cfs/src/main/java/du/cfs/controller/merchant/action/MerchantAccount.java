package du.cfs.controller.merchant.action;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.constraints.Null;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RoleService;
import du.cfs.common.vo.PageChunkVO;
import du.cfs.controller.base.BaseAction;
import du.cfs.controller.base.BaseCore;
import du.cfs.controller.system.action.vo.AuthAccountVO;
import du.cfs.controller.system.action.vo.AuthRoleVO;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;
import du.cfs.security.AdmUserPrinciple;


public class MerchantAccount extends BaseAction{
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	RoleService roleService;
	
	@Override
	public String execute() {
		
		String username = getUserInfo().getUsername();

		Account account = accountService.findByUsername(username);	
		AuthAccountVO authAccountVO = new AuthAccountVO();
		BeanUtils.copyProperties(account, authAccountVO);
		authAccountVO.setRoles(null);
		
		if(authAccountVO.getIsUsing2FA()) {
			String qrcode = null;
			try {
				qrcode = accountService.generateQRUrl(account);
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			authAccountVO.setQrCode(qrcode);
		}
		
		assign("account", authAccountVO);
		System.out.println(JSON.toJSONString(authAccountVO,true));

		return getView("merchantAccount");
	}
}
