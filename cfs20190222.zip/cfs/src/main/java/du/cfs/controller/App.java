package du.cfs.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;

import du.cfs.common.model.Role;
import du.cfs.common.service.RememberTokenService;
import du.cfs.controller.base.BaseCore;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;
import du.cfs.security.request.SignUpForm;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/ap")
public class App {
	
	@Autowired
	RememberTokenService commerceService;
	
	@Autowired
	BaseCore baseCore;
	
	@Autowired
	AccountService accountService;
	
//	@RequestMapping("/{sub}/{action}")
//	public ResponseEntity<?> findBy(
//									@PathVariable String sub,
//									@PathVariable String action,
//									HttpServletRequest request, 
//									HttpServletResponse response,
//									Model model){
//		log.info("index ...........");
//		Map<String,Object> data = new HashMap<>();
//	 	request.setAttribute("sub", sub);
//	 	data.put("model", model);
//	 	data.put("request", request);
//		baseCore.initView(model);
//		
//		return ResponseEntity.ok(baseCore.runModel(sub, action, data));
////		return commerceService.deleteAndUpdate(id, role_id, uid);
//	}
	
//    @RequestMapping("/")
//    @PreAuthorize("hasRole('ADMIN')")
//    public String showHome() {
//        String name = SecurityContextHolder.getContext().getAuthentication().getName();
//        log.info("当前登陆用户：" + name);
//        return "home";
//    }
    
    @PostMapping("/signup")
    public ResponseEntity<String> registerUser(@Valid @RequestBody SignUpForm signUpRequest) {
		return null;
//        
//        return ResponseEntity.ok().body("User registered successfully!");
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> login(HttpServletRequest request) {
    	HashMap<String , String> ht = new HashMap<>();
    	ht.put("success", "User registered successfully!");
//        
        return ResponseEntity.ok().body(ht);
    }
    
    @GetMapping("/login")
    public ResponseEntity<String> logins(HttpServletRequest request) {
    	System.out.println("get login");
//        
        return ResponseEntity.ok().body("User registered successfully!");
    }
    
    @GetMapping()
    public ResponseEntity<?> Test(HttpServletRequest request){
    	String[] d = new String[2];
    	d[0] = request.getParameter("a");
    	try {
			d[1] = URLEncoder.encode(request.getParameter("a"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	System.out.println(JSON.toJSONString(d,true));
    	return ResponseEntity.ok().body("successfully!" + JSON.toJSONString(d));
    }
    
    
//    @GetMapping("/acc")
//    public Page<Account> logins() {
//    	System.out.println("get login");
////        
//        return accountService.findAllByPage(0,1);
//    }
    
}
