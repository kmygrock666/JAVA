package du.cfs.controller.index.action;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import du.cfs.controller.base.BaseAction;
import du.cfs.controller.base.BaseCore;
import du.cfs.controller.base.MenuOperate;
import du.cfs.controller.system.action.vo.AuthRolePermissionVO;
import du.cfs.security.AdmUserPrinciple;


public class Index extends BaseAction{
	
	@Autowired
	BaseCore baseCore;
	
	@Autowired
	MenuOperate menu;
	
	@Override
	public String execute() {
		System.out.println("-------------in Index Class-------------");
		AdmUserPrinciple userInfo = getUserInfo();
		
		List<AuthRolePermissionVO> menus = menu.getMenu(userInfo);
		String paths = "view/index/Index";
		assign("path", paths);
		assign("username", userInfo.getUsername());
		assign("menus", menus);

//		System.out.println("-------------使用者名稱-------------"+userInfo.getUsername());
//		System.out.println("-------------使用者暱稱-------------"+userInfo.getName());
//		System.out.println("-------------使用者權限-------------"+userInfo.getAuthorities().toString());
		return "main/makeUp";
	}
}
