package du.cfs.controller;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.*;

import du.cfs.common.service.RememberTokenService;
import du.cfs.controller.base.BaseCore;
import du.cfs.controller.index.action.Index;
import du.cfs.security.AdmUserPrinciple;

@Slf4j
@Controller
@RequestMapping("/cm")
public class Core extends BaseCore{

	@Autowired
	RememberTokenService commerceService;
	
	@RequestMapping("/{sub}/{action}")
	public String runCore(@PathVariable String sub,
						@PathVariable String action,
						HttpServletRequest request, 
						HttpServletResponse response,
						Model model){
			
		 	Map<String,Object> data = new HashMap<>();
		 	request.setAttribute("sub", sub);
		 	data.put("model", model);
		 	data.put("request", request);
		 	initView(model,sub,action);
			return (String) runModel("controller",sub, action, data);
	}
	
	@RequestMapping
	public String runCoreHome(
						HttpServletRequest request, 
						HttpServletResponse response,
						Model model){
			
			String sub = "index";
			String action = "Index";
		 	Map<String,Object> data = new HashMap<>();
		 	request.setAttribute("sub", sub);
		 	data.put("model", model);
		 	data.put("request", request);

			initView(model,sub,action);
			return (String) runModel("controller",sub, action, data);
	}
	
//	@GetMapping("ap/test")
//	public ResponseEntity<?> TEST() {
//		System.out.println("IN TEST FUNCTION");
//		return ResponseEntity.ok().body("success");
//	}
	
}
