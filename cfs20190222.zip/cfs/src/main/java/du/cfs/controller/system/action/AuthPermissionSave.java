package du.cfs.controller.system.action;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.base.BaseAction;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;
import du.cfs.security.CustomFilterInvocationSecurityMetadataSource;


public class AuthPermissionSave extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	
	@Autowired
	CustomFilterInvocationSecurityMetadataSource customFilterInvocationSecurityMetadataSource;
	
	@Override
	public String execute() {
		// TODO Auto-generated method stub
		String id =  getParam("p_id");
		String code =  getParam("p_code");
		String name =  getParam("p_title");
		String url =  getParam("p_url");
		String isShow =  getParam("p_isShow");
		String icon =  getParam("p_icon");
		String listorder = getParam("p_listorder");
		Long pid =  Long.parseLong(getParam("p_parent"));
		
		Permission permission;
		
		if(id == null || id.equals("")) {
			permission = new Permission();
			customFilterInvocationSecurityMetadataSource.refreshRequestData();
		}
		else 
			permission = permissionService.findById(Long.parseLong(id));
		
		permission.setPermission(code);
		permission.setTitle(name);;
		permission.setUrl(url);
		permission.setPid(pid);
		permission.setIcon(icon);
		permission.setListorder(Long.parseLong(listorder));
		permission.setIsShow(Boolean.parseBoolean(isShow));

		permissionService.save(permission);
		
		System.out.println("Save Success");
		return redirect("/system/AuthPermission");

	}
	
}
