package du.cfs.controller.system.action.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import du.cfs.common.model.Role;
import lombok.Data;

@Data
public class AuthAccountVO {
	private long id;

	private String username;

	private String nickname;

	private Boolean status;
	private String ip;
	
	private Boolean isUsing2FA;
	private String secret;
	private String qrCode;

	private Date  createdAt;
	private Date  updateAt;
	
	
	private List<String> roles;
}
