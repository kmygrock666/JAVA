package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.security.UserPrinciple;
import com.spring.service.CommerceService;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.*;

@Slf4j
@Controller
@RequestMapping("/cm")
public class Core {

	@Autowired
	CommerceService commerceService;
	
	@GetMapping("/{action}")
	public String home() {
		String name = SecurityContextHolder.getContext().getAuthentication().getName();
		System.out.println(SecurityContextHolder.getContext().getAuthentication().getCredentials());
		System.out.println(SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString());
		System.out.println(SecurityContextHolder.getContext().getAuthentication().getPrincipal());
//		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//		UserPrinciple userPrincipal = (UserPrinciple) authentication.getPrincipal();
		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.info("当前登陆用户：" + name);
        System.out.println(name);
        System.out.println(userPrincipal.getAuthorities());
        System.out.println(userPrincipal.getCreated_at());
        System.out.println(userPrincipal.getUsername());
        System.out.println(userPrincipal.getPassword());
		return "index";
	}
	

	

}
