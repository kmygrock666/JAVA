package com.spring.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Service;

import com.spring.model.Permission;
import com.spring.model.Role;
import com.spring.repository.PermissionRepository;
import com.spring.repository.RoleRepository;
import com.spring.service.CommerceService;
import com.spring.service.PermissionService;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import lombok.extern.slf4j.Slf4j;
/**
 * 權限配置資源管理
 * @author RD00
 * @Description 
 * 實現FilterInvocationSecurityMetadataSource
 * 啟動時就去加載了所有權限列表
 * 判斷用戶訪問資源是否在保護的範圍內
 */
@Slf4j
@Service
public class CustomFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource{
	
	 @Autowired
	 private PermissionService permissionService;
	
	/**
	 * 儲存相關權限
	 */
	private HashMap<String, Collection<ConfigAttribute>> urlPerMap =null;
	private Map<RequestMatcher, Collection<ConfigAttribute>> requestMap;
	
	public void loadResourceDefine() {
		Map<RequestMatcher, Collection<ConfigAttribute>> map = new HashMap<>();
		
		Collection<ConfigAttribute> perList = new ArrayList<>();	
        //用来存储权限的容器
        ConfigAttribute cfg;
        //从数据库查询全部的权限信息
		List<Permission> permissions = permissionService.findAll();
//		
//		
		for(Permission permission : permissions) {
			AntPathRequestMatcher matcher = new AntPathRequestMatcher(permission.getUrl());
//            perList = new HashSet<>();
            cfg = new SecurityConfig(permission.getPermission());
            log.info("---------------------加载数据库中全部权限--------------------->>>-"+permission.getPermission());
            ArrayList<ConfigAttribute> configs = new ArrayList<>();
            configs.add(cfg);
            log.info("---------------------加载数据库中全部权限--------------------->>>-"+permission.getUrl());
            map.put(matcher, configs);

        }
		this.requestMap = map;
//        AntPathRequestMatcher matcher = new AntPathRequestMatcher("/home");
//        SecurityConfig config = new SecurityConfig("ROLE_ADMIN");
//        ArrayList<ConfigAttribute> configs = new ArrayList<>();
//        configs.add(config);
//        map.put(matcher,configs);
//        log.info("matcher---->"+matcher);
//        log.info("config---->"+config);
//
//        AntPathRequestMatcher matcher2 = new AntPathRequestMatcher("/");
//        SecurityConfig config2 = new SecurityConfig("ROLE_ADMIN");
//        ArrayList<ConfigAttribute> configs2 = new ArrayList<>();
//        configs2.add(config2);
//        map.put(matcher2,configs2);
//
//        this.requestMap = map;

	}
	
	@Override
	public Collection<ConfigAttribute> getAttributes(Object object) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		if(urlPerMap ==null){
            loadResourceDefine();
        }
		// object中包含用戶請求的請求信息
		HttpServletRequest request = ((FilterInvocation) object).getHttpRequest();
		AntPathRequestMatcher matcher;
        String resUrl;
        log.info("---------------------加载数据库中全部权限--------------------->>>getAttributes-");
//        for(Iterator<String> iter = urlPerMap.keySet().iterator(); iter.hasNext(); ) {
//        	log.info("---------------------加载数据库中全部权限--------------------->>>COMING-");
//            resUrl = iter.next();
//            //ant匹配规则的匹配路径，如果构造方法中至传入路径则需要完全匹配。
//            matcher = new AntPathRequestMatcher(resUrl);
//            //请求路径和urlPerMap中的路径进行匹配，成功了就从urlPerMap中获取对应路径的权限
//            if(matcher.matches(request)) {
//                return urlPerMap.get(resUrl);
//            }
//        }
        for (Map.Entry<RequestMatcher, Collection<ConfigAttribute>> entry : requestMap
                .entrySet()) {
        	log.info("---------------------加载数据库中全部权限--------------------->>>for-");
            if (entry.getKey().matches(request)) {
            	log.info("---------------------加载数据库中全部权限--------------------->>>for->if-"+entry.getValue());
            	log.info("---------------------加载数据库中全部权限--------------------->>>for->if-"+entry.getKey());
            	log.info("---------------------加载数据库中全部权限--------------------->>>for->if-"+request);
                return entry.getValue();
            }
        }

        return null;

	}

	@Override
	public Collection<ConfigAttribute> getAllConfigAttributes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return FilterInvocation.class.isAssignableFrom(clazz);
	}

}
