package com.spring.security.handel;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.spring.controller.Core;

import lombok.extern.slf4j.Slf4j;

/**
 * 全局控制器例外處理配置
 * @author RD00
 * @ExceptionHandler(用於全局控制器裡的異常)
 * @InitBinder(用於設置WebDataBinder),WebDataBinder是用來自動綁定前台請求參數到Model中
 * @ModelAttribute(用於綁定鍵值數據到Model中)
 */
@Slf4j
@ControllerAdvice
public class ControllerExceptionHandler {
	
	/**
	 * 異常處理
	 * addObject方法可以增加錯誤訊息在這方法在利用前台映射取出數值
	 * setViewName方法為要返回的錯誤頁面　記住！！　我們如果有使用thymeleaf就放置在對應的classpath底下
	 * @param request
	 * @param e
	 * @return
	 * @throws Exception 
	 */
	@ExceptionHandler({Exception.class})
//	@ExceptionHandler()
	public ModelAndView handleException(HttpServletRequest request, Exception e) throws Exception {
		
		log.error("Request URL : {}, E: {}",request.getRequestURI(),e.getMessage());
		
		if (AnnotationUtils.findAnnotation(e.getClass(), ResponseStatus.class) != null) {
			throw e;
		}
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("url", request.getRequestURI());
		mav.addObject("exception", e);
		mav.setViewName("error/error");
		
		return mav;
	}
	
	//如果我們要讓所有的@RequestMapping擁有此鍵值
	@ModelAttribute
	public void addAttribute(Model md){
		md.addAttribute("message","你可以設定一些錯誤訊息");
	}
}
