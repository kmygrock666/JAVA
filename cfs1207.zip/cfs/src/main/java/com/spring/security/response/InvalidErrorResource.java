package com.spring.security.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InvalidErrorResource {
	private String message;
	private Object errors;
}
