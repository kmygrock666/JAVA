package com.spring.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.spring.model.Commerce;
import com.spring.model.Menu;
import com.spring.model.SysConfig;


public interface SysConfigRepository extends JpaRepository<SysConfig, Long>{
	SysConfig findByToken(String token);
}
