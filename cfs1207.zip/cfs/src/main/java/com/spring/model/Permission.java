package com.spring.model;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Permission {
	@Id
	 @GeneratedValue
	 private Long id;
	 //权限名称
	 private String name;
	 //权限描述
	 private String permission;
	 //授权链接
	 private String url;
	 //顯示於menu
	 private int menu;
	//顯示於menu
	 private int menu_show;

//	 private String method;
}
