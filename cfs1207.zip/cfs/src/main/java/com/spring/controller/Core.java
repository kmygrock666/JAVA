package com.spring.controller;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.spring.controller.action.MenuOperate;
import com.spring.controller.action.index.Index;
import com.spring.repository.CommerceRepository.MenuPermission;
import com.spring.security.UserPrinciple;
import com.spring.service.CommerceService;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
@Controller
@RequestMapping("/cm")
public class Core {

	@Autowired
	CommerceService commerceService;
	
	@Autowired
	MenuOperate menu;
	
	@GetMapping("/{sub}/{action}")
	public String home(@PathVariable String sub,
						@PathVariable String action,
						HttpServletRequest request, 
						HttpServletResponse response,
						Model model){
	
		try {
			 //實體class
			 Class model_class = Class.forName("com.spring.controller.action." + sub + "." + action);
			 Object classObj = model_class.newInstance();
			

			 UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 Map<String,Object> data = new HashMap<>();
			 menu.getMenu(userPrincipal,model);
			 log.info("=============In Core Class============");
			 data.put("model", model);
			 data.put("request", request);
			 //產生method，並呼叫
			 Method setInit = model_class.getMethod("init", new Class[]{Map.class});
			 Object getInit = setInit.invoke(classObj, new Object[]{data});
			 //產生method，並呼叫 
			 Method setInfo = model_class.getMethod("execute", null);
			 Object getReturn = setInfo.invoke(classObj, null);

			 return (String) getReturn;
		} catch( ClassNotFoundException e ) {
			//my class isn't there!
			log.error("找不到檔案  catch : " + e.getMessage());
			throw new RuntimeException("找不到檔案  catch : " + e.getMessage());
			
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 A " + e.getMessage());
			throw new RuntimeException("初始化錯誤 A " + e.getMessage());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 B " + e.getMessage());
			throw new RuntimeException("初始化錯誤 B " + e.getMessage());
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 C " + e.getMessage());
			throw new RuntimeException("初始化錯誤 C " + e.getMessage());
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 D " + e.getMessage());
			throw new RuntimeException("初始化錯誤 D " + e.getMessage());
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 E " + e.getMessage());
			throw new RuntimeException("初始化錯誤 E " + e.getMessage());
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			log.error("初始化錯誤 F " + e.getMessage());
			throw new RuntimeException("初始化錯誤 F " + e.getMessage());
		}


		
		
		
//		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

//        log.info("当前登陆用户：" + userPrincipal.getUsername());
//        System.out.println(userPrincipal.getUsername());
//        System.out.println(userPrincipal.getAuthorities());
//        System.out.println(userPrincipal.getCreated_at());
//        System.out.println(userPrincipal.getUsername());
//        System.out.println(userPrincipal.getPassword());
//        System.out.println("NEW 成功");
//		Index model = new Index();
//		return model.execute();
        
//		return "index";
	}
	
	@GetMapping("/{action}/test")
	@PreAuthorize("hasRole('ROLE_USER')")
	public String TEST() {
		System.out.println("IN TEST FUNCTION");
		return "index";
	}
	
	@GetMapping("/test")
	public String TEST2(Model model) {
		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		System.out.println(SecurityContextHolder.getContext().getAuthentication() == null);
		System.out.println("IN TEST2  "+userPrincipal.getAuthorities().toString());
		System.out.println("IN TEST2 FUNCTION");
		Index a = new Index();
		Map<String,Object> data = new HashMap<>();
		data.put("model", model);
		a.init(data);
		return "test";
	}
	
	
	

}
