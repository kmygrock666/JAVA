package com.spring.service;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.model.Commerce;
import com.spring.model.RememberToken;
import com.spring.model.Role;
import com.spring.model.SysConfig;
import com.spring.repository.CommerceRepository;
import com.spring.repository.RememberTokenRepository;
import com.spring.repository.RoleRepository;
import com.spring.repository.SysConfigRepository;
import com.spring.repository.CommerceRepository.MenuPermission;

@Service
public class SysConfigService {
	@Autowired
    private SysConfigRepository sysConfigRepository;
	
	@Autowired
    private RoleRepository roleRepository;
	
	@Autowired
    private RememberTokenRepository rememberTokenRepository;
	
//	public Commerce GetUserByName(String name) {
//		return commerceRepository.findByUsername(name);
//	}
	/**
	 * 	建立TOKEN
	 * @param token
	 */
	public void save(RememberToken token) {
//		return rememberTokenRepository.insert(token.getToken(),token.getLast_used(),token.getSeries());
		 rememberTokenRepository.save(token);
	}
	/**
	 * 	更新TOKEN
	 * @param tokenValue
	 * @param lastUsed
	 * @param series
	 * @return
	 */
	public int updateByPK(String tokenValue, Date lastUsed, String series) {
		return rememberTokenRepository.updateByPK(tokenValue,lastUsed,series);
	}
	
	public SysConfig findByToken(String token){
		return sysConfigRepository.findByToken(token);
	}
	
	

	
	
}
