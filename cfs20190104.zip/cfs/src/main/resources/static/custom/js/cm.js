function logout(){
	parent.location.href = "/logout";
}

function getLoad(url){
	$("#container").load(url);
}

//var model = new Vue({
//	el: "#modelshow",
//	data : {
//		modalShow: false
//	},
//	methods:{
//		show(){
//			this.show = true;
//		}
//	}
//}); 
//
//function show(){
//	this.model.modalShow = true;
////	$('#myModal').modal('show');
//}

