package du.cfs.global.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Repository.GateListRechargeRepository;
import du.cfs.global.Repository.KernRepository;
import du.cfs.global.Unit.OrderCode;
import du.cfs.global.Unit.iRandom;
import du.cfs.global.db.GateListRecharge;
import du.cfs.global.db.Kern;
@Service
public class GateListRechargeServiceImpl implements GateListRechargeService {

	@Autowired
	GateListRechargeRepository repository;



	@Override
	public GateListRecharge GetGateListRecharge(String name) {
		Optional<GateListRecharge> optional = repository.findByname(name);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public GateListRecharge save(GateListRecharge gateListRecharge) {
		return repository.save(gateListRecharge);
	}



}
