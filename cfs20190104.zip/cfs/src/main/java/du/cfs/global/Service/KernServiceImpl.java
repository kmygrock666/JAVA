package du.cfs.global.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import du.cfs.global.Repository.KernRepository;
import du.cfs.global.Unit.OrderCode;
import du.cfs.global.Unit.iRandom;
import du.cfs.global.db.Kern;
@Service
public class KernServiceImpl implements KernService {

	@Autowired
	KernRepository repository;

	public Kern GetKernInfo(String kernCode) {
		Optional<Kern> optional = repository.findByKernCode(kernCode);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
	
	private static String codeMap = "vwA0xyBzWXDZQbUcMOd7Eqrst1SunH2PoL6eTY4i3GkIfgRJKjChlmNVa5p";
	private static String codeKey = "F";

	public Kern save(Kern kern) {
		kern.setKernCode(iRandom.GetUUID());
		kern =  repository.save(kern);
		String code = OrderCode.IntToCodeString(codeMap, codeKey, kern.getId(), 10);
		kern.setKernCode(code);
		kern =  repository.save(kern);
		return kern;
	}
	
}
