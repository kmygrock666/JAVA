package du.cfs.global.db;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

//通道類型
@Entity
public class MerGateInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	// 通道英文名稱
	@Column(length = 20, nullable = false)
	private String E_name;
	
	@Column( length = 50, nullable = false)
	private String kernCode;

	@Column(length = 50, nullable = false)
	private String gatIp;
	
	@OneToMany(mappedBy = "merGateInfo", cascade = { CascadeType.PERSIST}, fetch = FetchType.EAGER)
	private List<MerGateList> merGateList = new ArrayList<MerGateList>();
	public MerGateInfo() {

	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getE_name() {
		return E_name;
	}
	public void setE_name(String e_name) {
		E_name = e_name;
	}




	public String getKernCode() {
		return kernCode;
	}
	public void setKernCode(String kernCode) {
		this.kernCode = kernCode;
	}
	public List<MerGateList> getMerGateList() {
		return merGateList;
	}
	public void setMerGateList(List<MerGateList> merGateList) {
		this.merGateList = merGateList;
	}
	public String getGatIp() {
		return gatIp;
	}
	public void setGatIp(String gatIp) {
		this.gatIp = gatIp;
	}


	

/*
	public String TransformBankid(BankType bankType) {
		String id = bankTypeMap.get(bankType);
		if(id==null)
			return bankType.toString();
		return id;

	}
	Map<BankType, String> bankTypeMap = new EnumMap<BankType, String>(BankType.class);
	public Gate_type() {
		bankTypeMap.put(BankType.ABC, "ABC");
		bankTypeMap.put(BankType.BCOM, "BCOM");
	}
	*/
	
	



}
