package du.cfs.global.Service;

import du.cfs.global.db.MerGateInfo;

public interface MerGateInfoService {
	MerGateInfo getMerGateInfo(int id);
	MerGateInfo save(MerGateInfo gateType);
}
