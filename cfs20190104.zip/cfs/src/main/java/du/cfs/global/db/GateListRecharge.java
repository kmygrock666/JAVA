package du.cfs.global.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "className" ,"gate_mercode" }) })
public class GateListRecharge {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	// 通道英文名稱
	@Column(length = 20, nullable = false)
	private String name;
		
	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	
	// 通道英文名稱
	@Column(length = 20, nullable = false)
	private String className;
	
	
	@Column(length = 20, nullable = false)
	private String gate_mercode;
		
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getGate_mercode() {
		return gate_mercode;
	}

	public void setGate_mercode(String gate_mercode) {
		this.gate_mercode = gate_mercode;
	}

	
	

}
