package du.cfs.global.db;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RechargeOrder_feedback {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;

	private String mer_code;
	private String mer_order_number;
	private int mer_amount;
	private String mer_phone;
	private String mer_account;
	private int mer_bank_id;
	private int mer_status;
	
	private String cfs_code;
	private String cfs_order_number;


	
	private String gate_code;
	private String gate_order_number;
	private int gate_bank_id;
	private int gate_status;

	//Paying Agent
	public RechargeOrder_feedback() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMer_code() {
		return mer_code;
	}

	public void setMer_code(String mer_code) {
		this.mer_code = mer_code;
	}

	public String getMer_order_number() {
		return mer_order_number;
	}

	public void setMer_order_number(String mer_order_number) {
		this.mer_order_number = mer_order_number;
	}

	public int getMer_amount() {
		return mer_amount;
	}

	public void setMer_amount(int mer_amount) {
		this.mer_amount = mer_amount;
	}

	public String getMer_phone() {
		return mer_phone;
	}

	public void setMer_phone(String mer_phone) {
		this.mer_phone = mer_phone;
	}

	public String getMer_account() {
		return mer_account;
	}

	public void setMer_account(String mer_account) {
		this.mer_account = mer_account;
	}

	public int getMer_bank_id() {
		return mer_bank_id;
	}

	public void setMer_bank_id(int mer_bank_id) {
		this.mer_bank_id = mer_bank_id;
	}

	public int getMer_status() {
		return mer_status;
	}

	public void setMer_status(int mer_status) {
		this.mer_status = mer_status;
	}

	public String getCfs_code() {
		return cfs_code;
	}

	public void setCfs_code(String cfs_code) {
		this.cfs_code = cfs_code;
	}

	public String getCfs_order_number() {
		return cfs_order_number;
	}

	public void setCfs_order_number(String cfs_order_number) {
		this.cfs_order_number = cfs_order_number;
	}

	public String getGate_code() {
		return gate_code;
	}

	public void setGate_code(String gate_code) {
		this.gate_code = gate_code;
	}

	public String getGate_order_number() {
		return gate_order_number;
	}

	public void setGate_order_number(String gate_order_number) {
		this.gate_order_number = gate_order_number;
	}

	public int getGate_bank_id() {
		return gate_bank_id;
	}

	public void setGate_bank_id(int gate_bank_id) {
		this.gate_bank_id = gate_bank_id;
	}

	public int getGate_status() {
		return gate_status;
	}

	public void setGate_status(int gate_status) {
		this.gate_status = gate_status;
	}
	
	
	
}
