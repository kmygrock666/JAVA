package du.cfs.global.db.Seed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import du.cfs.global.Service.GateListRechargeService;
import du.cfs.global.Service.KernService;
import du.cfs.global.db.GateListRecharge;
import du.cfs.global.db.Kern;


@Configuration
public class DataSeed_gate {


	@Autowired
	KernService kernService;
	@Autowired
	GateListRechargeService gateListRechargeService;
	
	public GateListRecharge SetGateListRecharge() {
		GateListRecharge gateListRecharge = new GateListRecharge();
		gateListRecharge.setClassName("XPPAY");
		gateListRecharge.setEnable(true);
		gateListRecharge.setName("XPPAY_6010");
		gateListRecharge.setGate_mercode("200025066010");
		return gateListRechargeService.save(gateListRecharge);
	}
	
	public String SetKern() {
		Kern kern = new Kern();
		kern.setApiIp("0:0:0:0:0:0:0:1");
		kern.setEnable(true);
		kern.setMd5Key("jLl8pWoMLOS9sEe1aXW8mblYaqn4bVW5");
		kern.setRsaKey("jLl8pWoMLOS9sEe1aXW8mblYaqn4bVW5");
		kern = kernService.save(kern);
		return kern.getKernCode();
	}
}
