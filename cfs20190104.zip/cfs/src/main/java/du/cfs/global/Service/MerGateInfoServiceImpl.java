package du.cfs.global.Service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import du.cfs.global.Repository.MerGateInfoRepository;
import du.cfs.global.db.MerGateInfo;
@Service
public class MerGateInfoServiceImpl implements MerGateInfoService {

	@Autowired
	MerGateInfoRepository repository;

	public MerGateInfo getMerGateInfo(int id) {
		Optional<MerGateInfo> optional = repository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Transactional
	public MerGateInfo save(MerGateInfo gateType) {
		return repository.save(gateType);
	}

}
