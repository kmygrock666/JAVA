package du.cfs.global.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Enums.PayType;



//商戶通道設定
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merchant_id", "payType" }) })
public class MerGateConfig {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	


	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;
	
	//為了再次確認
	@Column(updatable = false, nullable = false)
	PayType payType = PayType.UNSET;
	
	/*
	 * Caused by: org.hibernate.AnnotationException: Unable to create unique key constraint (merCode, merConfig) on table mer_gate_config: 
	 * database column 'merConfig' not found. Make sure that you use the correct column name which depends on the naming strategy in use 
	 * (it may not be the same as the property name in the entity, especially for relational types)

	 * */
	@ManyToOne
	private Merchant merchant;
	
	@ManyToOne
	private MerGateList merGateList;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}


	public boolean isEnable() {
		return enable;
	}
	public void setEnable(boolean enable) {
		this.enable = enable;
	}


	public MerGateList getMerGateList() {
		return merGateList;
	}
	public void setMerGateList(MerGateList merGateList) {
		this.merGateList = merGateList;
	}
	public PayType getPayType() {
		return payType;
	}
	public void setPayType(PayType payType) {
		this.payType = payType;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}


	
	
	
}
