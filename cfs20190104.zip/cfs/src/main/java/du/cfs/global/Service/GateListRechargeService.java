package du.cfs.global.Service;


import du.cfs.global.db.GateListRecharge;


public interface GateListRechargeService {
	GateListRecharge GetGateListRecharge(String name);
	GateListRecharge save(GateListRecharge gateListRecharge);
}
