package du.cfs.global.db;

import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Enums.PayType;
import du.cfs.global.Enums.StatusType;

// 充值訂單
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merchant_id", "merOrderNumber" }) })
public class RechargeOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
	@ManyToOne
	private Merchant merchant;
	@Column(length = 50, updatable = false, nullable = false)
	private String merOrderNumber;
	@Column(updatable = false, nullable = false)
	private int merAmount;
	@Column(updatable = false, nullable = false)
	private PayType merPayType = PayType.UNSET;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(updatable = false, nullable = false)
	private Date merTransDate;
	@Column(length = 200, updatable = false, nullable = false)
	private String merSyncNotifyUrl;
	@Column(length = 200, updatable = false, nullable = false)
	private String merUnsyncNotifyUrl;
	@Column(length = 200, updatable = false, nullable = false)
	private String merDesc;
	@Column(columnDefinition = "TINYINT(1)")
	private StatusType merStatus;
	@Column(length = 50)
	private String cfsOrderNumber;

	@OneToOne(cascade = { CascadeType.PERSIST, CascadeType.REMOVE }, optional = true, fetch = FetchType.EAGER)
	RechargeOrderSubInfo rechargeOrderSubInfo;
	@ManyToOne
	private MerGateList merGateList;

	// 通道訂單號
	@Column(length = 50)
	private String gateOrderNumber;

	@Temporal(TemporalType.TIMESTAMP)
	private Date gatePayTime;
	// 通道訂單狀態
	@Column(columnDefinition = "TINYINT(1)")
	private StatusType gateStatus;
	@Transient
	private int not_to_db;

	public RechargeOrder() {
	}

	// ----------------------------------------------------------

	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
		this.gateStatus = StatusType.UNPAY;
		this.merStatus = StatusType.UNPAY;
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------

	// ----------------------------------------------------------

	public RechargeOrderSubInfo getRechargeOrderSubInfo() {
		return rechargeOrderSubInfo;
	}

	public StatusType getMerStatus() {
		return merStatus;
	}

	public void setMerStatus(StatusType merStatus) {
		this.merStatus = merStatus;
	}

	public StatusType getGateStatus() {
		return gateStatus;
	}

	public void setGateStatus(StatusType gateStatus) {
		this.gateStatus = gateStatus;
	}

	public void setRechargeOrderSubInfo(RechargeOrderSubInfo rechargeOrderSubInfo) {
		this.rechargeOrderSubInfo = rechargeOrderSubInfo;
	}

	public PayType getMerPayType() {
		return merPayType;
	}

	public void setMerPayType(PayType merPayType) {
		this.merPayType = merPayType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public String getMerOrderNumber() {
		return merOrderNumber;
	}

	public void setMerOrderNumber(String merOrderNumber) {
		this.merOrderNumber = merOrderNumber;
	}

	public int getMerAmount() {
		return merAmount;
	}

	public void setMerAmount(int merAmount) {
		this.merAmount = merAmount;
	}

	public String getCfsOrderNumber() {
		return cfsOrderNumber;
	}

	public void setCfsOrderNumber(String cfsOrderNumber) {
		this.cfsOrderNumber = cfsOrderNumber;
	}




	public MerGateList getMerGateList() {
		return merGateList;
	}

	public void setMerGateList(MerGateList merGateList) {
		this.merGateList = merGateList;
	}

	public String getGateOrderNumber() {
		return gateOrderNumber;
	}

	public void setGateOrderNumber(String gateOrderNumber) {
		this.gateOrderNumber = gateOrderNumber;
	}

	public Date getGatePayTime() {
		return gatePayTime;
	}

	public void setGatePayTime(Date gatePayTime) {
		this.gatePayTime = gatePayTime;
	}

	public int getNot_to_db() {
		return not_to_db;
	}

	public void setNot_to_db(int not_to_db) {
		this.not_to_db = not_to_db;
	}

	public Date getMerTransDate() {
		return merTransDate;
	}

	public void setMerTransDate(Date merTransDate) {
		this.merTransDate = merTransDate;
	}

	public String getMerSyncNotifyUrl() {
		return merSyncNotifyUrl;
	}

	public void setMerSyncNotifyUrl(String merSyncNotifyUrl) {
		this.merSyncNotifyUrl = merSyncNotifyUrl;
	}

	public String getMerUnsyncNotifyUrl() {
		return merUnsyncNotifyUrl;
	}

	public void setMerUnsyncNotifyUrl(String merUnsyncNotifyUrl) {
		this.merUnsyncNotifyUrl = merUnsyncNotifyUrl;
	}

	public String getMerDesc() {
		return merDesc;
	}

	public void setMerDesc(String merDesc) {
		this.merDesc = merDesc;
	}

	
}
