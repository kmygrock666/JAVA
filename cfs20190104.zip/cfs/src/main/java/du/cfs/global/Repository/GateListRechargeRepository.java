package du.cfs.global.Repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import du.cfs.global.db.GateListRecharge;

public interface GateListRechargeRepository extends JpaRepository<GateListRecharge, Integer> {

	Page<GateListRecharge> findAll(Pageable pageable);

	Optional<GateListRecharge> findByname(String name);
	

	
}
