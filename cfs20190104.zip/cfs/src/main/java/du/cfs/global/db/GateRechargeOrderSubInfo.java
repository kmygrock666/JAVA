package du.cfs.global.db;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
// 充值訂單
import javax.persistence.OneToOne;

import du.cfs.global.Enums.BankType;


@Entity
public class GateRechargeOrderSubInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	// 訂單資訊-手機號
	@Column(length = 20, updatable = false)
	private String merPhone;
	// 訂單資訊-銀行帳戶
	@Column(length = 20, updatable = false)
	private String merAccount;
	@Column(length = 20, updatable = false)
	private String merAccountName;
	// 訂單資訊-銀行編號
	@Column(updatable = false)
	private BankType merBankId;
	
	@OneToOne(mappedBy = "rechargeOrderSubInfo")
	private GateRechargeOrder rechargeOrder;
	
	

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMerPhone() {
		return merPhone;
	}

	public void setMerPhone(String merPhone) {
		this.merPhone = merPhone;
	}

	public String getMerAccount() {
		return merAccount;
	}

	public void setMerAccount(String merAccount) {
		this.merAccount = merAccount;
	}

	public String getMerAccountName() {
		return merAccountName;
	}

	public void setMerAccountName(String merAccountName) {
		this.merAccountName = merAccountName;
	}

	public BankType getMerBankId() {
		return merBankId;
	}

	public void setMerBankId(BankType merBankId2) {
		this.merBankId = merBankId2;
	}

	public GateRechargeOrder getRechargeOrder() {
		return rechargeOrder;
	}

	public void setRechargeOrder(GateRechargeOrder rechargeOrder) {
		this.rechargeOrder = rechargeOrder;
	}
	
	
	
		 
}
