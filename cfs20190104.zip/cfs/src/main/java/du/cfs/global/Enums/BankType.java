package du.cfs.global.Enums;

public enum BankType {
	ABC(0),ICBC(1),CCB(2),BCOM(3),BOC(4),CMB(5) 
	//农业银行, 工商银行,建设银行,交通银行,中国银行,招商银行
	,CMBC(6),CEBB(7),BOB(8),CIB(9),PSBC(10) 
	//民生银行,光大银行,北京银行,兴业银行,中国邮政银行"			
	,SPDB(11),ECITIC(12),HZB(13),GDB(14),SHB(15)
	//浦发银行,中信银行,杭州银行,广发银行,上海银行 					
	,NBB(16),HXB(17),SPABANK(18); 
	//宁波银行  华夏银行 平安银行 
	private final int id; 
	BankType(int id) {
		this.id = id;
	}
	public int getValue() {	return id;}
}