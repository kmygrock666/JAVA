package du.cfs.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.SecurityMetadataSource;
import org.springframework.security.access.intercept.AbstractSecurityInterceptor;
import org.springframework.security.access.intercept.InterceptorStatusToken;
import org.springframework.security.web.FilterInvocation;
import org.springframework.stereotype.Service;
import java.io.IOException;

/**
 * 權限攔截過濾
 * @author RD00
 * @Description : 通過spring 著名IOC生成securityMetadataSource
 * securityMetadataSource相當於自訂義CustomFilterInvocationSecurityMetadataSource
 * CustomFilterInvocationSecurityMetadataSource的作用從數據庫取權限和資源，新增到HASHMAP中
 * 供Spring Security使用
 */
@Service
public class CustomFilterSecurityInterceptor extends AbstractSecurityInterceptor implements Filter{
	/**
	 * 權限配置資源管理
	 */
	@Autowired
    private CustomFilterInvocationSecurityMetadataSource customFilterInvocationSecurityMetadataSource;
	
	@Autowired
    public void setMyAccessDecisionManager(CustomAccessDecisionManager customAccessDecisionManager) {
        super.setAccessDecisionManager(customAccessDecisionManager);
    }
	
	@Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }
	
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		FilterInvocation fi = new FilterInvocation(request, response, chain);
        invoke(fi);
		
	}

	private void invoke(FilterInvocation fi) throws IOException, ServletException {
		/**
		 * fi裡面有一個被攔截的URL
		 * 調用CustomFilterInvocationSecurityMetadataSource的getAttributes(Object object)這個方法獲取fi對應的所有權限
		 * 再調用CustomAccessDecisionManager的decide方法來驗證用戶的權限
		 */
		 InterceptorStatusToken token = super.beforeInvocation(fi);
	        try {
	            //执行下一个拦截器
	            fi.getChain().doFilter(fi.getRequest(), fi.getResponse());
	        }finally {
	            super.afterInvocation(token, null);
	        }
		
	}
	
	@Override
    public void destroy() {

    }

	@Override
	public Class<?> getSecureObjectClass() {
		// TODO Auto-generated method stub
		return FilterInvocation.class;
//		return null;
	}

	@Override
	public SecurityMetadataSource obtainSecurityMetadataSource() {
		// TODO Auto-generated method stub
		return this.customFilterInvocationSecurityMetadataSource;
//		return null;
	}

}
