package du.cfs.security.handel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.data.redis.RedisOperationsSessionRepository;
import org.springframework.stereotype.Component;

import du.cfs.config.SystemConfig;
import du.cfs.security.UserPrinciple;
import du.cfs.util.RemoveUser;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomizeAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler  {
	
	@Autowired
    private RedisTemplate redisTemplate;
	
	@Autowired
	SystemConfig conf;
	
	public static HashMap<String, HttpSession> sessionMap = new HashMap<String, HttpSession>();
	
	@Autowired
	// @Qualifier("sessionRegistry")
	private SessionRegistry sessionRegistry;

    @Autowired
    FindByIndexNameSessionRepository<? extends Session> sessionRepository;
    
    @Autowired
    RedisOperationsSessionRepository redisOperationsSessionRepository;
    
    @Autowired
    RemoveUser session;
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		// TODO Auto-generated method stub
//		Cookie[] cookies = request.getCookies();
//    	String token = "";
//
//    	for(Cookie cookiel : cookies){
//    		System.out.println("cookies 的 key 為 "+cookiel.getName()+"  值為 "+cookiel.getValue());
//    		if(cookiel.getName().equals(conf.getCookies())) {
//    			token = cookiel.getValue();
//    			break;
//    		}
//        }
		List<Object> principals = sessionRegistry.getAllPrincipals();
  		log.info("78已經認證通過的使用者數:"+principals.size()+"，     已經認證通過使用者："+principals.toString());
  		
		log.info("認證成功==> CustomizeAuthenticationSuccessHandler");
		HttpSession sessionId = request.getSession();
		String token = sessionId.getId();
		UserPrinciple userPrincipal = (UserPrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String indexName = userPrincipal.getUsername();
		//剔除前一個登入使用者
		session.removeFrontUser(indexName,token);
//        // 查詢使用者的 Session 資訊，返回值 key 為 sessionId
//        Map<String, ? extends Session> userSessions = sessionRepository.findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, indexName);
//        // 移除使用者的 session 資訊
//        List<String> sessionIds = new ArrayList<>(userSessions.keySet());
//        System.out.println("操作者的session  ； "+token);
//        for (String session : sessionIds) {
//        	System.out.println("找到的ＳＥＳＳＩＯＮ  ； "+session);
//        	if(!token.equals(session)) {
//        		System.out.println("進入刪除動作 ； "+session);
//	        	redisOperationsSessionRepository.deleteById(session);
//	        	System.out.println("session redis 已刪除 ； "+session);
//	        	redisTemplate.delete("user:"+session);
//	        	sessionRegistry.removeSessionInformation(session);
//	        	System.out.println("成功刪除ＳＥＳＳＩＯＮ  為； "+session);
//        	}
//        }
        
		principals = sessionRegistry.getAllPrincipals();
  		log.info("104已經認證通過的使用者數:"+principals.size()+"，     已經認證通過使用者："+principals.toString());
			
//		long loginTime = System.currentTimeMillis();
//		Map<String,Object> userAll = redisTemplate.opsForHash().keys("user");
//		Cursor<Map.Entry<Object, Object>> curosr = redisTemplate.opsForHash().scan("redisHash", ScanOptions.ScanOptions.NONE);
//	      while(curosr.hasNext()){
//	          Map.Entry<Object, Object> entry = curosr.next();
//	          System.out.println(entry.getKey()+":"+entry.getValue());
//	      }
//  		 Map<String, ? extends Session> userSessions = sessionRepository.findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, indexName);
//         // 移除用户的 session 信息
//         List<String> sessionIds = new ArrayList<>(userSessions.keySet());
//         for (String session : sessionIds) {
//             redisOperationsSessionRepository.deleteById(session);
//         }
//         return ResponseBean.success(userSessions);
//
// --------------------- 
// 作者：十步杀一人_千里不留行 
// 来源：CSDN 
// 原文：https://blog.csdn.net/m0_37609579/article/details/80013991 
// 版权声明：本文为博主原创文章，转载请附上博文链接！


//		
		Map<String,Object> testMap = new HashMap();
        testMap.put("account",userPrincipal.getUsername());
        testMap.put("username",userPrincipal.getName());
        testMap.put("role",userPrincipal.getRole().toString());
//        testMap.put("loginTime",loginTime);
        redisTemplate.opsForHash().putAll("user:"+token,testMap);
		log.info("登入成功------------------------- "+token);
		response.sendRedirect("/cm");
	}

}
