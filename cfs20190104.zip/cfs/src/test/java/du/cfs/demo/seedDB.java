package du.cfs.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.setMaxElementsForPrinting;
import static org.junit.Assume.assumeTrue;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import du.cfs.Application;
import du.cfs.database.DBContextHolder;
import du.cfs.global.Unit.CURL;
import du.cfs.global.Unit.HttpCurl;
import du.cfs.model.Account;
import du.cfs.model.Account;
import du.cfs.model.Menu;
import du.cfs.model.Permission;
import du.cfs.model.Role;
import du.cfs.repository.AccountRepository;
import du.cfs.repository.AccountRepository.MenuPermission;
import du.cfs.service.CommerceService;
import du.cfs.service.MenuService;
import du.cfs.service.PermissionService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class seedDB {
	@Autowired
    private CommerceService commerceService;
	
	@Autowired
    private PermissionService permissionService;
	
	@Autowired
    private MenuService menuService;
	
	
//	@Test
//	public void TestDataSourceTwo() throws Exception{
//		DBContextHolder.setDbType(DBContextHolder.DB_TYPE_SECONDARY);
//		List<Account> user = accountRepository.findAll();
//		assertThat(user).isNotNull();
//		assertThat(user.get(0).getName()).isEqualTo("BBB");
//		System.out.println("======================TWO");
//		System.out.println(user.get(0).getName());
//		System.out.println(user.size());
//		
//	}
	
	@Test
	public void curlTest() throws IOException{
//		URL url = new URL("http://localhost2/pYq4gwyNjZN0iZi0zazCJDC1/En.php");
//		HttpURLConnection con = (HttpURLConnection) url.openConnection();
//		con.setRequestMethod("GET");
//		
//		con.connect();
//		System.out.println(new Date());
		RestTemplate restTemplate = new RestTemplate();
		String fooResourceUrl  = "http://localhost2/pYq4gwyNjZN0iZi0zazCJDC1/En.php";
//		ResponseEntity<String> response
//		  = restTemplate.getForEntity(fooResourceUrl + "?a=1", String.class);
////		System.out.print(JSON.toJSONString(response,true));
//		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
//		ObjectMapper mapper = new ObjectMapper();
//		JsonNode root = mapper.readTree(response.getBody());
//		JsonNode name = root.path("name");
//		assertThat(name.asText()).isNotNull();
//		
//		String foo = restTemplate
//				  .getForObject(fooResourceUrl + "/1", String.class);
//		
//		System.out.print(JSON.toJSONString(foo,true));
		
//		HttpCurl.get(fooResourceUrl);
	
		MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();     
//
		body.add("book", "value");
//
//		// Note the body object as first parameter!
//		HttpHeaders requestHeaders = new HttpHeaders();
//		HttpEntity<?> httpEntity = new HttpEntity<Object>(body, requestHeaders);
//
//		ResponseEntity<String> model = restTemplate.exchange(fooResourceUrl, HttpMethod.POST, httpEntity, String.class);
//System.out.println(JSON.toJSONString(model.getBody(),true));
//		Map<String, String> test = new HashMap<>();
//		test.put("p", "0080");
		HttpCurl.post(body, fooResourceUrl);
//		CURL.doPost(fooResourceUrl, "p=post0800aasd", "UTF-8");
	}
	
	@Test
	public void menuTest() {
		
	}
	
	
}
