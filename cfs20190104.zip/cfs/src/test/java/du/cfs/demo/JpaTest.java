package du.cfs.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import du.cfs.Application;
import du.cfs.database.DBContextHolder;
import du.cfs.model.Account;
import du.cfs.model.Account;
import du.cfs.repository.AccountRepository;
import du.cfs.service.CommerceService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class JpaTest {
	@Autowired
    private CommerceService commerceService;
	
	@Autowired
    private AccountRepository accountRepository;
	
	@Test
	public void TestFindByUsername() throws Exception{
		DBContextHolder.setDbType(DBContextHolder.DB_TYPE_PRIMARY);
		Optional<Account> user = commerceService.findByUsername("rdian");

		System.out.println("FIND SUCCESS");
		assertThat(user).isNotNull();
		System.out.println("IS NOT NULL");
		assertThat(user.get().getUsername()).isEqualTo("rdian");
		System.out.println("IS USERNAME");
		System.out.println("======================ONE");
		System.out.println(user.get().getUsername());
		
//		DBContextHolder.setDbType(DBContextHolder.DB_TYPE_SECONDARY);
//		List<Account> user2 = accountRepository.findAll();
//		assertThat(user2).isNotNull();
//		assertThat(user2.get(0).getName()).isEqualTo("BBB");
//		System.out.println("======================TWO");
//		System.out.println(user2.get(0).getName());
//		System.out.println(user2.size());
	}
	
//	@Test
//	public void TestDataSourceTwo() throws Exception{
//		DBContextHolder.setDbType(DBContextHolder.DB_TYPE_SECONDARY);
//		List<Account> user = accountRepository.findAll();
//		assertThat(user).isNotNull();
//		assertThat(user.get(0).getName()).isEqualTo("BBB");
//		System.out.println("======================TWO");
//		System.out.println(user.get(0).getName());
//		System.out.println(user.size());
//		
//	}
}
