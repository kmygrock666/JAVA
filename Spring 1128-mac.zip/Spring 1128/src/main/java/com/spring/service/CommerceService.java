package com.spring.service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.model.Commerce;
import com.spring.model.RememberToken;
import com.spring.model.Role;
import com.spring.repository.CommerceRepository;
import com.spring.repository.RememberTokenRepository;
import com.spring.repository.RoleRepository;

@Service
public class CommerceService {
	@Autowired
    private CommerceRepository commerceRepository;
	
//	@Autowired
//    private RoleRepository roleRepository;
	
	@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
    private RememberTokenRepository rememberTokenRepository;
	
//	public Commerce GetUserByName(String name) {
//		return commerceRepository.findByUsername(name);
//	}
	/**
	 * 	建立TOKEN
	 * @param token
	 */
	public void save(RememberToken token) {
//		return rememberTokenRepository.insert(token.getToken(),token.getLast_used(),token.getSeries());
		 rememberTokenRepository.save(token);
	}
	/**
	 * 	更新TOKEN
	 * @param tokenValue
	 * @param lastUsed
	 * @param series
	 * @return
	 */
	public int updateByPK(String tokenValue, Date lastUsed, String series) {
		return rememberTokenRepository.updateByPK(tokenValue,lastUsed,series);
	}
	
	public RememberToken findBySeries(String series) {
		return rememberTokenRepository.findBySeries(series);
	}
	
	public Commerce save(Commerce user){
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		user.setCreated_at(LocalDateTime.now());
		return commerceRepository.save(user);
	}
	
	public Optional<Commerce> findByUsername(String name) {
		return commerceRepository.findByUsername(name);
	}
	
	/**
	 * 測試事務操作方法
	 * @param id
	 * @param role_id
	 * @param uid
	 * @return
	 */
	@Transactional
	public int deleteAndUpdate(int id,int role_id,int uid) {
		int dcount =  commerceRepository.deleteByJPQL(id);

		int ucount = commerceRepository.updateByJPQL(role_id, uid);
		
		return dcount+ucount;
	}
	
	public int updateInfo(String password,int role_id,String com04,int id) {
		password = bCryptPasswordEncoder.encode(password);
		return commerceRepository.updateInfoByJPQL(password, role_id, com04, id);
	}
	

//	public List<Role> findRoleInfoByRole(String role) {
//		// TODO Auto-generated method stub
//		return roleRepository.findByRole(role);
//	}
	

	
	
}
