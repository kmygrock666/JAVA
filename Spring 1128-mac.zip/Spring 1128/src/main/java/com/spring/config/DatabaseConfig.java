package com.spring.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:/config/db.properties")
@ConfigurationProperties(prefix = "db")
public class DatabaseConfig {
	private String driverClassName;
	
	
}
