package com.spring.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.spring.model.Commerce;


public interface CommerceRepository extends JpaRepository<Commerce, Long>{
//	Commerce findByUsername(String username);
	
	Optional<Commerce> findByUsername(String username);
	
	
	
	@Modifying
	@Transactional
	@Query("update Commerce c set c.role_id = ?1 where id = ?2")
	int updateByJPQL(int role_id,int id);
	
	@Modifying
	@Transactional
	@Query("delete from Commerce c where c.id = ?1")
	int deleteByJPQL(int id);
	
	@Modifying
	@Transactional
	@Query("update from Commerce c set c.password = ?1 ,c.role_id = ?2,c.com04 = ?3 where c.id = ?4")
	int updateInfoByJPQL(String password,int role_id,String com04,int id);
}
