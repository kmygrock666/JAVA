package du.cfs.controller.action.system;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.controller.action.BaseAction;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;


public class AuthPermissionSave extends BaseAction{
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	PermissionService permissionService;
	

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		String id =  getParam("p_id");
		String code =  getParam("p_code");
		String name =  getParam("p_title");
		String url =  getParam("p_url");
		Long pid =  Long.parseLong(getParam("p_parent"));
		
		Permission permission;
		
		if(id == null || id.equals(""))
			 permission = permissionService.findByPermission(code);
		else 
			permission = permissionService.findById(Long.parseLong(id));

		if(permission == null)
			permission = new Permission();
		permission.setPermission(code);
		permission.setTitle(name);;
		permission.setUrl(url);
		permission.setPid(pid);

		permissionService.save(permission);
		
		System.out.println("Save Success");
		return redirect("/system/AuthPermission");

	}
	
}
