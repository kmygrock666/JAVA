package du.cfs.global.db.KERN;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Gen.cfsEnum.PayType;
import du.cfs.global.Gen.cfsEnum.RechargeOrderStatus;
import du.cfs.global.Gen.converBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merchant_id", "merOrderNumber" }) })
@Entity
public class MerRechargeOrder extends converBase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
	@ManyToOne
	private Merchant merchant;
	@Column(length = 50, updatable = false, nullable = false)
	private String merOrderNumber;
	@Column(updatable = false, nullable = false)
	private int merAmount;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date merTransDate;
	@Column(updatable = false, nullable = false)
	private PayType merPayType = PayType.UNSET;
	// ---------------------------------------------------

	// ---------------------------------------------------
	@Column(columnDefinition = "TINYINT(1)")
	private RechargeOrderStatus orderStatus;
	// ---------------------------------------------------

	// ---------------------------------------------------
	@Column(length = 50)
	private String kernOrderNumber;
	@Column(length = 50)
	private String gateOrderNumber;
	@Column(length = 50)
	private String gateBN;
	// ---------------------------------------------------

	public MerRechargeOrder() {
	}

	// ----------------------------------------------------------

	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
		this.orderStatus = RechargeOrderStatus.UNPAY;
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------

	// ----------------------------------------------------------

}
