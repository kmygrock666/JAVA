package du.cfs.global.db.GM;

public interface GmMerGateMapService {

	GmMerGateMap GetGmMerGateMap(int id);
	GmMerGateMap GetGmMerGateMap(String merCode);

	GmMerGateMap save(GmMerGateMap r);




}
