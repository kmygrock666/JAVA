package du.cfs.global.db.GM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Gen.cfsEnum.PayType;
import lombok.Data;

@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "mer_id", "merPayType" }) })
public class GmMerGateMap {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(columnDefinition = "TINYINT(1)")
	private boolean enable;


	@ManyToOne
	private GmMerchant mer;

	@ManyToOne
	private GmGate gmGate;
	@Column(updatable = false, nullable = false)
	private PayType merPayType = PayType.UNSET;
}

