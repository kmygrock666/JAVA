package du.cfs.global.db.GATE;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import du.cfs.global.Gen.cfsEnum.BankType;
import du.cfs.global.Gen.cfsEnum.PayType;
import du.cfs.global.Gen.cfsEnum.RechargeOrderStatus;
import du.cfs.global.Gen.converBase;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = false)
@Data
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(columnNames = { "merCode", "merOrderNumber" }) })
public class GateRechargeOrder extends converBase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
	@Column(length = 50, updatable = false, nullable = false)
	private String merCode;
	@Column(length = 50, updatable = false, nullable = false)
	private String merOrderNumber;
	@Column(updatable = false, nullable = false)
	private int merAmount;
	@Column(updatable = false, nullable = false)
	private PayType merPayType = PayType.UNSET;
	// ---------------------------------------------------
	@Column(columnDefinition = "TINYINT(1)")
	private RechargeOrderStatus orderStatus;
	// ---------------------------------------------------
	@Column(length = 50)
	private String kernOrderNumber;
	@Column(length = 50)
	private String gateCode;
	@Column(length = 50)
	private String gateOrderNumber;

	// ------------- --------------------------------------

	@Column(length = 200, updatable = false, nullable = false)
	private String merSyncNotifyUrl;
	@Column(length = 200, updatable = false, nullable = false)
	private String merUnsyncNotifyUrl;
	@Column(length = 200, updatable = false, nullable = false)
	private String merDesc;

	@Column(length = 20, updatable = false)
	private String merPhone;
	// 訂單資訊-銀行帳戶
	@Column(length = 20, updatable = false)
	private String merAccount;
	@Column(length = 20, updatable = false)
	private String merAccountName;
	// 訂單資訊-銀行編號
	@Column(updatable = false)
	private BankType merBankId;
	// ---------------------------------------------------
	@OneToOne
	GateRechargeProcResult gateRechargeProcResult;
	// ---------------------------------------------------

	@Temporal(TemporalType.TIMESTAMP)
	private Date thirdTranDate;
	@Column(length = 50)
	private String thirdOrderNumber;
	// ---------------------------------------------------
	// ---------------------------------------------------

	public GateRechargeOrder() {
	}

	// ----------------------------------------------------------
	@PrePersist
	void createdAt() {
		this.createdAt = this.updatedAt = new Date();
		this.orderStatus = RechargeOrderStatus.UNPAY;
	}

	@PreUpdate
	void updatedAt() {
		this.updatedAt = new Date();
	}
	// ----------------------------------------------------------

}
