package du.cfs.global.Unit;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;

import java.net.URL;

import lombok.Cleanup;

public class CURL {

	// private final Logger logger =
	// LoggerFactory.getLogger(ControllerExceptionHandler.class);

	public static String doPost(String sURL, String data, String charset) {
		RequestData requestData = new RequestData("POST", charset);
		requestData.setData(data);
		return requestData.connect(sURL);
	}

	public static String doGet(String sURL, String charset) {
		RequestData requestData = new RequestData("GET", charset);
		return requestData.connect(sURL);
	}

	
	public static class RequestData {
		String method = "GET";

		String userAgent = "Mozilla/5.0 (Windows; U; Windows NT 6.0; zh-TW; rv:1.9.1.2) " + "Gecko/20090729 Firefox/3.5.2 GTB5 (.NET CLR 3.5.30729)";
		String accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
		String acceptLanguage = "zh-tw,en-us;q=0.7,en;q=0.3";
		String acceptCharse = "Big5,utf-8;q=0.7,*;q=0.7";
		String contentType = "application/x-www-form-urlencoded";
		String referer;
		String cookie;
		String data;
		String charset = "UTF8";

		HttpURLConnection URLConn;

		public RequestData(String method, String charset) {
			super();
			this.method = method;
			this.charset = charset;
		}

		public String connect(String sURL) {
			String sOut = "";

			try {
				URL url = new URL(sURL);
				URLConn = (HttpURLConnection) url.openConnection();
				URLConn.setDoOutput(true);
				URLConn.setDoInput(true);
				((HttpURLConnection) URLConn).setRequestMethod(this.method);
				URLConn.setUseCaches(false);
				URLConn.setAllowUserInteraction(true);
				HttpURLConnection.setFollowRedirects(true);
				URLConn.setInstanceFollowRedirects(true);
				URLConn.setRequestProperty("User-agent", this.userAgent);
				URLConn.setRequestProperty("Accept", this.accept);
				URLConn.setRequestProperty("Accept-Language", this.acceptLanguage);
				URLConn.setRequestProperty("Accept-Charse", this.acceptCharse);

				if (cookie != null)
					URLConn.setRequestProperty("Cookie", cookie);
				if (referer != null)
					URLConn.setRequestProperty("Referer", referer);

				// URLConn.connect();

				if (method.equals("POST") && data != null && charset != null) {
					URLConn.setRequestProperty("Content-Type", this.contentType);
					URLConn.setRequestProperty("Content-Length", String.valueOf(data.getBytes().length));
					@Cleanup
					DataOutputStream dos = new DataOutputStream(URLConn.getOutputStream());
					dos.writeBytes(data);
				}
				@Cleanup
				BufferedReader in = new BufferedReader(new InputStreamReader(URLConn.getInputStream(), charset));
				String line;
				while ((line = in.readLine()) != null) {
					sOut += line;
				}
			} catch (IOException e) {
				System.out.println(e.toString());
			}
			return sOut;
		}

		public String getUserAgent() {
			return userAgent;
		}

		public void setUserAgent(String userAgent) {
			this.userAgent = userAgent;
		}

		public String getAccept() {
			return accept;
		}

		public void setAccept(String accept) {
			this.accept = accept;
		}

		public String getAcceptLanguage() {
			return acceptLanguage;
		}

		public void setAcceptLanguage(String acceptLanguage) {
			this.acceptLanguage = acceptLanguage;
		}

		public String getAcceptCharse() {
			return acceptCharse;
		}

		public void setAcceptCharse(String acceptCharse) {
			this.acceptCharse = acceptCharse;
		}

		public String getReferer() {
			return referer;
		}

		public void setReferer(String referer) {
			this.referer = referer;
		}

		public String getCookie() {
			return cookie;
		}

		public void setCookie(String cookie) {
			this.cookie = cookie;
		}

		public String getData() {
			return data;
		}

		public void setData(String data) {
			this.data = data;
		}

		public String getContentType() {
			return contentType;
		}

		public void setContentType(String contentType) {
			this.contentType = contentType;
		}

	}

}
