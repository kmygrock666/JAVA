package du.cfs.global.Gen;

import java.util.Map;
import java.util.TreeMap;

import com.fasterxml.jackson.databind.ObjectMapper;

import du.cfs.global.Gen.cfsEnum.EchoType;
import du.cfs.global.Gen.cfsEnum.RechargeOrderStatus;
import du.cfs.global.Unit.EncryptAndDecrypt;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Builder
@EqualsAndHashCode(callSuper = false)
@Data
public class Struce_RechargeNotify extends converBase {
	private EchoType resultCode;
	private String resultMsg;
	private String merCode;
	private int merAmount;
	private String merOrderNumber;
	private String sign;
	private RechargeOrderStatus orderStatus;


	@Override
	public String toString() {
		ObjectMapper oMapper = new ObjectMapper();
		@SuppressWarnings("unchecked")
		TreeMap<String, String> map = oMapper.convertValue(this, TreeMap.class);
		String smd5strString = "";
		for (Map.Entry<String, String> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if (!key.equals("sign") && value != null)
				smd5strString += key + "=" + value + "&";
		}
		smd5strString = smd5strString.replaceAll("&$", "");
		return smd5strString;
	}

	public Boolean CheckMd5Sign(String key) {
		if (sign == null)
			return false;
		String smd5strString = this.toString();
		return EncryptAndDecrypt.Md5Check(smd5strString + key, sign);
	}

	public String GetMd5Sign(String key) {
		return EncryptAndDecrypt.Md5(this.toString() + key);
	}

	public void SetMd5Sign(String key) {
		sign = EncryptAndDecrypt.Md5(this.toString() + key);
	}
}
