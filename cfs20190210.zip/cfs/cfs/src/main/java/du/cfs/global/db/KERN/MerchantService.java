package du.cfs.global.db.KERN;

public interface MerchantService {
	Merchant getMerchant(String merCode);
	Merchant update(Merchant merConfig);
	Merchant create(Merchant merConfig);
}
