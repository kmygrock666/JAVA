package du.cfs.global.db.KERN;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSeed_mer {
	@Autowired
	MerRechargeOrderService rechargeService;

	@Autowired
	MerchantService merchantService;

	@Bean
	public DataSeed_mer GetDataSeed() {
		return new DataSeed_mer();
	}

	
	private String gmIp = "localhost:8082";


	public Merchant SetMerchant(String merCode) {
		Merchant mc = new Merchant();
		mc.setEnable(true);
		mc.setMd5Key("jLl8pWoMLOS9sEe1aXW8mblYaqn4bVW4");
		mc.setRsaKey("jLl8pWoMLOS9sEe1aXW8mblYaqn4bVW4");
		mc.setApiIp("127.0.0.1");
		mc.setBackstageIp("0:0:0:0:0:0:0:1");
		mc.setGmIp(gmIp);
		mc.setMerCode(merCode);
		return merchantService.create(mc);
	}




}
