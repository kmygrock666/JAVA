package du.cfs.global.db.GATE;

public interface GateRechargeProcResultService {

	GateRechargeProcResult GetGateRechargeProcResult(int id);

	GateRechargeProcResult saveNuAutoOrderNumber(GateRechargeProcResult gateRechargeProcResult);

}
