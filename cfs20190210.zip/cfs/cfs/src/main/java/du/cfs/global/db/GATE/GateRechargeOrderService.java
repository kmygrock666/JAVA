package du.cfs.global.db.GATE;

public interface GateRechargeOrderService {


	GateRechargeOrder GetRechargeOrder(String gateCode, String orderCode);

	
	GateRechargeOrder save(GateRechargeOrder r);

	GateRechargeOrder InsertOrder(GateRechargeOrder rechargeOrder);


}
