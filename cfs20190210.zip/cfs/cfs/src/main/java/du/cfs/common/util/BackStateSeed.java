package du.cfs.common.util;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;


import du.cfs.common.model.Permission;
import du.cfs.common.model.Role;
import du.cfs.common.service.PermissionService;
import du.cfs.common.service.RoleService;
import du.cfs.db.ADM.Account;
import du.cfs.db.ADM.AccountService;

@Component
@Profile("dev")
public class BackStateSeed {
	@Autowired
    private AccountService accountService;
	
	@Autowired
    private RoleService roleService;
	
	@Autowired
    private PermissionService permissionService;
	
	@Autowired
	@Lazy //TODO 解決 Requested bean is currently in creation: Is there an unresolvable circular reference 問題 
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	public void AddAccount(){
		System.out.println("---------------新增帳號----------------------");
		Account user1 = new Account();
		user1.setUsername("rdian");
		user1.setPassword(bCryptPasswordEncoder.encode("123"));
		user1.setNickname("rdian");
		user1.setStatus(true);
//		Role WhatRole1 = roleService.findByName("ROLE_ADMIN")
//                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
		Role WhatRole1 = roleService.findByName("ROLE_ADMIN");
		
//		System.out.println(JSON.toJSONString(WhatRole,true));
		user1.addRole(WhatRole1);
		accountService.save(user1);
		
		Account user = new Account();
		user.setUsername("ian");
		user.setPassword(bCryptPasswordEncoder.encode("123"));
		user.setNickname("ian");
		user.setStatus(true);
//		Role WhatRole = roleService.findByName("ROLE_USER")
//                .orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
		Role WhatRole = roleService.findByName("ROLE_USER");
		
//		System.out.println(JSON.toJSONString(WhatRole,true));
		user.addRole(WhatRole);
		accountService.save(user);
	}
	
	//權限
	public void addPermission() {
		System.out.println("---------------權限----------------------");
//		System.out.println(JSON.toJSONString(menus,true));
		
		Permission m = new Permission();
		m.setPid(0L);
		m.setTitle("系統管理");
		m.setPermission("system");
		m.setIcon("fa fa-gear");
		m.setListorder(0L);
		permissionService.save(m);
		
		Permission m1 = new Permission();
		m1.setPid(0L);
		m1.setTitle("代收管理");
		m1.setPermission("agent");
		m1.setIcon("fa fa-align-left");
		m1.setListorder(1L);
		permissionService.save(m1);
		
//		Permission m2 = new Permission();
//		m2.setPid(0L);
//		m2.setTitle("無");
//		m2.setPermission("none");
//		m2.setIcon("fa fa-align-left");
//		m2.setListorder(2L);
//		permissionService.save(m2);
		
		Permission p = new Permission();
		p.setPid(4L);
		p.setTitle("首頁");
		p.setPermission("Index");
		p.setUrl("/index/Index");
		p.setListorder(999L);
		permissionService.save(p);
		
		Permission p1 = new Permission();
		p1.setPid(4L);
		p1.setTitle("首頁");
		p1.setPermission("Index");
		p1.setUrl("/cm");
		p1.setListorder(999L);
		permissionService.save(p1);
		
		Permission p2 = new Permission();
		p2.setPid(1L);
		p2.setTitle("控端管理");
		p2.setPermission("Authaccount");
		p2.setUrl("/system/AuthAccount");
		p2.setListorder(900L);
		permissionService.save(p2);
		
		Permission p21 = new Permission();
		p21.setPid(1L);
		p21.setTitle("權限管理");
		p21.setPermission("AuthPermission");
		p21.setUrl("/system/AuthPermission");
		p21.setListorder(902L);
		permissionService.save(p21);
		
		Permission p22 = new Permission();
		p22.setPid(1L);
		p22.setTitle("角色管理");
		p22.setPermission("AuthRole");
		p22.setUrl("/system/AuthRole");
		p22.setListorder(901L);
		permissionService.save(p22);
		
		Permission p3 = new Permission();
		p3.setPid(2L);
		p3.setTitle("代收查詢");
		p3.setPermission("OrderList");
		p3.setUrl("/order/OrderList");
		p3.setListorder(999L);
		permissionService.save(p3);
	}
	//角色
	public void AddRole() {
		System.out.println("---------------新增角色----------------------");
		List<Permission> permissions = permissionService.findAll();
		Role role = new Role();
		role.setName("ROLE_ADMIN");
		role.setDescription("管理者");
		role.setPermissions(permissions);
		roleService.saveRole(role);
		
		List<Permission> permissions2 = new ArrayList();
		permissions2.add(permissions.get(0));
		permissions2.add(permissions.get(4));
		
		Role role2 = new Role();
		role2.setName("ROLE_USER");
		role2.setDescription("使用者");
		role2.setPermissions(permissions2);
		roleService.saveRole(role2);
	}
	
}
