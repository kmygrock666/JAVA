package du.cfs.global.Gen;

import lombok.Data;

// 充值訂單
@Data
public class Struce_Input_UserJump {
	private String ip;
	private String OrderCode;
}
