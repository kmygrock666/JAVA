package du.cfs.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import du.cfs.db.MER.MerchantMember;
import du.cfs.db.MER.MerchantMemberService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Profile("mer")
public class MerCustomUserDetailsServiceImp implements UserDetailsService {
 
    @Autowired
    MerchantMemberService merchantMemberService;
    
    @Override
    @Transactional
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

    	MerchantMember user = merchantMemberService.findByUsername(username)
                	.orElseThrow(() -> 
                        new UsernameNotFoundException("User Not Found with -> username or email : " + username)
        );
        
        user.getRoles();
        log.info("come in UserDetailsService");
        
        return MerUserPrinciple.build(user);
    }
}
