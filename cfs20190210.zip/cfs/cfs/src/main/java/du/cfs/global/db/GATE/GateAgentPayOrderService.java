package du.cfs.global.db.GATE;

import java.util.List;

import du.cfs.global.Gen.cfsEnum.ProcResultState;

public interface GateAgentPayOrderService {

	GateAgentPayOrder GetRechargeOrder(int id);

	GateAgentPayOrder save(GateAgentPayOrder merAgentPayOrder);

	GateAgentPayOrder InsertOrder(GateAgentPayOrder merAgentPayOrder);

	GateAgentPayOrder GetRechargeOrder(String kernOrderNumber);

	List<GateAgentPayOrder> findBygateCodeAndProcResultState(String gateCode, ProcResultState procResultState);
}
