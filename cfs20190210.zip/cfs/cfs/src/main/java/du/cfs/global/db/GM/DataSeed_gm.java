package du.cfs.global.db.GM;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import du.cfs.global.Gen.cfsEnum.PayType;

@Configuration
public class DataSeed_gm {

	@Autowired
	GmKernService kernService;
	@Autowired
	GmGateService gmGateService;
	@Autowired
	GmMerGateMapService gmMerGateMapService;
	@Autowired
	GmMerchantService gmMerchantService;

	public GmKern SetGmKern(String md5Key) {
		GmKern kern = new GmKern();
		kern.setApiIp("127.0.0.1");
		kern.setApiPort("8082");
		kern.setEnable(true);
		kern.setMd5Key(md5Key);
		kern.setRsaKey(md5Key);
		return kernService.create(kern);
	}

	public GmGate SetGmGate() {
		GmGate gmGate = new GmGate();
		gmGate.setEnable(true);
		gmGate.setGateBn("XPPAY");
		gmGate.setGateIp("127.0.0.1");
		gmGate.setGatePort("8082");
		gmGate.setMd5Key("GmSetMd5Key");
		return gmGateService.create(gmGate);
	}
	
	public GmMerchant setGmMerchant(String merMd5,GmKern gmKern) {
		GmMerchant mer = new GmMerchant();
		//mer.setMd5Key(merMd5);
		mer.setSttledAmount(0);
		// mer.setTotalAmount(0);
		mer.setGmKern(gmKern);
		return gmMerchantService.create(mer);
	}
	
	public GmMerGateMap SetGmMerGateMap(GmMerchant mer, GmGate gg) {
		
		
		
		
		GmMerGateMap gmMerGateMap = new GmMerGateMap();
		gmMerGateMap.setEnable(true);
		gmMerGateMap.setMer(mer);
		gmMerGateMap.setMerPayType(PayType.UNIONPAY);
		gmMerGateMap.setGmGate(gg);

		return gmMerGateMapService.save(gmMerGateMap);
	}

}

