package du.cfs.controller.action.index;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import du.cfs.controller.action.BaseAction;
import du.cfs.controller.action.BaseCore;
import du.cfs.controller.action.MenuOperate;
import du.cfs.controller.action.system.vo.AuthRolePermissionVO;
import du.cfs.security.AdmUserPrinciple;


public class Index extends BaseAction{
	
	@Autowired
	BaseCore baseCore;
	
	@Autowired
	MenuOperate menu;
	
	@Override
	public String execute() {
		
		AdmUserPrinciple userInfo = getUserInfo();
		System.out.println("-------------in Index Class-------------");
		baseCore.name();
		
		List<AuthRolePermissionVO> menus = menu.getMenu(userInfo);
		String paths = "view/index/Index";
		assign("path", paths);
		assign("username", userInfo.getUsername());
		assign("menus", menus);

//		System.out.println("-------------使用者名稱-------------"+userInfo.getUsername());
//		System.out.println("-------------使用者暱稱-------------"+userInfo.getName());
//		System.out.println("-------------使用者權限-------------"+userInfo.getAuthorities().toString());
		return "main/makeUp";
	}
}
